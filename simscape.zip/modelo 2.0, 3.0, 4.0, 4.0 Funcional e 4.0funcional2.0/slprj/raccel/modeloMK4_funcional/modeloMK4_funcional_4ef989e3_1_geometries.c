/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'modeloMK4_funcional/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

const sm_core_compiler_Brick *modeloMK4_funcional_4ef989e3_1_geometry_0(const
  RuntimeDerivedValuesBundle *rtdv)
{
  static const sm_core_compiler_Brick brick = { 0.08, 0.01, 0.04 };

  (void) rtdv;
  return &brick;
}

const sm_core_compiler_Plane *modeloMK4_funcional_4ef989e3_1_geometry_1(const
  RuntimeDerivedValuesBundle *rtdv)
{
  static const sm_core_compiler_Plane plane = { 0 };

  (void) rtdv;
  return &plane;
}

const sm_core_compiler_Sphere *modeloMK4_funcional_4ef989e3_1_geometry_2(const
  RuntimeDerivedValuesBundle *rtdv)
{
  static const sm_core_compiler_Sphere sphere = { 0.01 };

  (void) rtdv;
  return &sphere;
}

void modeloMK4_funcional_4ef989e3_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv)
{
  modeloMK4_funcional_4ef989e3_1_geometry_0(rtdv);
  modeloMK4_funcional_4ef989e3_1_geometry_1(rtdv);
  modeloMK4_funcional_4ef989e3_1_geometry_2(rtdv);
}
