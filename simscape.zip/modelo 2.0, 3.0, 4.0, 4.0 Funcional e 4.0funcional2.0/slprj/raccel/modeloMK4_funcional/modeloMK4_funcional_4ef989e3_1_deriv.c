/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'modeloMK4_funcional/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "modeloMK4_funcional_4ef989e3_1_geometries.h"

PmfMessageId modeloMK4_funcional_4ef989e3_1_compDerivs(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *deriv, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  boolean_T bb[1];
  int ii[1];
  double xx[421];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  xx[4] = state[10];
  xx[5] = state[11];
  xx[6] = state[12];
  pm_math_Quaternion_compDeriv_ra(xx + 0, xx + 4, xx + 7);
  xx[0] = 0.7071067811865476;
  xx[1] = 0.9999999970531803;
  xx[2] = 7.677004418860416e-5;
  xx[3] = xx[1] * state[3] + xx[2] * state[6];
  xx[4] = xx[0] * xx[3];
  xx[5] = xx[2] * state[5] - xx[1] * state[4];
  xx[6] = xx[0] * xx[5];
  xx[11] = xx[4] + xx[6];
  xx[12] = xx[11] * xx[11];
  xx[13] = xx[4] - xx[6];
  xx[4] = xx[13] * xx[13];
  xx[6] = 2.0;
  xx[14] = 1.0;
  xx[15] = (xx[12] + xx[4]) * xx[6] - xx[14];
  xx[16] = xx[2] * state[3] - xx[1] * state[6];
  xx[17] = xx[0] * xx[16];
  xx[18] = xx[1] * state[5] + xx[2] * state[4];
  xx[19] = xx[18] * xx[0];
  xx[20] = xx[17] + xx[19];
  xx[21] = xx[20] * xx[13];
  xx[22] = xx[17] - xx[19];
  xx[17] = xx[22] * xx[11];
  xx[19] = (xx[21] + xx[17]) * xx[6];
  xx[23] = xx[11] * xx[20];
  xx[24] = xx[22] * xx[13];
  xx[25] = xx[6] * (xx[23] - xx[24]);
  xx[26] = xx[15];
  xx[27] = xx[19];
  xx[28] = xx[25];
  xx[29] = 0.1354557519189488;
  xx[30] = 0.01797123889803847;
  xx[31] = 0.01671460183660255;
  xx[32] = 0.5;
  xx[33] = xx[32] * input[3];
  xx[34] = cos(xx[33]);
  xx[35] = xx[6] * xx[34] * xx[34] - xx[14];
  xx[36] = xx[31] * xx[35];
  xx[37] = sin(xx[33]);
  xx[33] = xx[6] * xx[34] * xx[37];
  xx[38] = xx[31] * xx[33];
  xx[39] = xx[38] * xx[33];
  xx[40] = xx[36] * xx[35] + xx[39];
  xx[41] = xx[30] + xx[40];
  xx[42] = xx[32] * input[6];
  xx[43] = cos(xx[42]);
  xx[44] = sin(xx[42]);
  xx[42] = xx[1] * xx[43] + xx[2] * xx[44];
  xx[45] = xx[42] * xx[42];
  xx[46] = xx[6] * xx[45] - xx[14];
  xx[47] = xx[6] * xx[37] * xx[37] - xx[14];
  xx[48] = xx[31] * xx[47];
  xx[49] = xx[38] * xx[35] + xx[48] * xx[33];
  xx[50] = xx[1] * xx[44] - xx[2] * xx[43];
  xx[43] = xx[6] * xx[42] * xx[50];
  xx[44] = xx[41] * xx[46] - xx[49] * xx[43];
  xx[51] = xx[36] * xx[33] + xx[38] * xx[47];
  xx[36] = xx[39] + xx[48] * xx[47];
  xx[38] = xx[30] + xx[36];
  xx[39] = xx[51] * xx[46] - xx[38] * xx[43];
  xx[48] = xx[44] * xx[46] - xx[39] * xx[43];
  xx[52] = xx[32] * input[2];
  xx[53] = cos(xx[52]);
  xx[54] = xx[6] * xx[53] * xx[53] - xx[14];
  xx[55] = xx[31] * xx[54];
  xx[56] = sin(xx[52]);
  xx[52] = xx[6] * xx[53] * xx[56];
  xx[57] = xx[31] * xx[52];
  xx[58] = xx[57] * xx[52];
  xx[59] = xx[55] * xx[54] + xx[58];
  xx[60] = xx[30] + xx[59];
  xx[61] = xx[32] * input[4];
  xx[62] = cos(xx[61]);
  xx[63] = sin(xx[61]);
  xx[61] = xx[1] * xx[62] + xx[2] * xx[63];
  xx[64] = xx[61] * xx[61];
  xx[65] = xx[6] * xx[64] - xx[14];
  xx[66] = xx[6] * xx[56] * xx[56] - xx[14];
  xx[67] = xx[31] * xx[66];
  xx[68] = xx[57] * xx[54] + xx[67] * xx[52];
  xx[69] = xx[1] * xx[63] - xx[2] * xx[62];
  xx[62] = xx[6] * xx[61] * xx[69];
  xx[63] = xx[60] * xx[65] - xx[68] * xx[62];
  xx[70] = xx[55] * xx[52] + xx[57] * xx[66];
  xx[55] = xx[58] + xx[67] * xx[66];
  xx[57] = xx[30] + xx[55];
  xx[58] = xx[70] * xx[65] - xx[57] * xx[62];
  xx[67] = xx[63] * xx[65] - xx[58] * xx[62];
  xx[71] = xx[32] * input[1];
  xx[72] = cos(xx[71]);
  xx[73] = xx[6] * xx[72] * xx[72] - xx[14];
  xx[74] = xx[31] * xx[73];
  xx[75] = sin(xx[71]);
  xx[71] = xx[6] * xx[72] * xx[75];
  xx[76] = xx[31] * xx[71];
  xx[77] = xx[76] * xx[71];
  xx[78] = xx[74] * xx[73] + xx[77];
  xx[79] = xx[30] + xx[78];
  xx[80] = xx[32] * input[7];
  xx[81] = cos(xx[80]);
  xx[82] = sin(xx[80]);
  xx[80] = xx[1] * xx[81] + xx[2] * xx[82];
  xx[83] = xx[80] * xx[80];
  xx[84] = xx[6] * xx[83] - xx[14];
  xx[85] = xx[6] * xx[75] * xx[75] - xx[14];
  xx[86] = xx[31] * xx[85];
  xx[87] = xx[76] * xx[73] + xx[86] * xx[71];
  xx[88] = xx[1] * xx[82] - xx[2] * xx[81];
  xx[81] = xx[6] * xx[80] * xx[88];
  xx[82] = xx[79] * xx[84] - xx[87] * xx[81];
  xx[89] = xx[74] * xx[71] + xx[76] * xx[85];
  xx[74] = xx[77] + xx[86] * xx[85];
  xx[76] = xx[30] + xx[74];
  xx[77] = xx[89] * xx[84] - xx[76] * xx[81];
  xx[86] = xx[82] * xx[84] - xx[77] * xx[81];
  xx[90] = xx[32] * input[0];
  xx[91] = cos(xx[90]);
  xx[92] = xx[6] * xx[91] * xx[91] - xx[14];
  xx[93] = xx[31] * xx[92];
  xx[94] = sin(xx[90]);
  xx[90] = xx[6] * xx[91] * xx[94];
  xx[95] = xx[31] * xx[90];
  xx[96] = xx[95] * xx[90];
  xx[97] = xx[93] * xx[92] + xx[96];
  xx[98] = xx[30] + xx[97];
  xx[99] = xx[32] * input[5];
  xx[32] = cos(xx[99]);
  xx[100] = sin(xx[99]);
  xx[99] = xx[1] * xx[32] + xx[2] * xx[100];
  xx[101] = xx[99] * xx[99];
  xx[102] = xx[6] * xx[101] - xx[14];
  xx[103] = xx[6] * xx[94] * xx[94] - xx[14];
  xx[104] = xx[31] * xx[103];
  xx[105] = xx[95] * xx[92] + xx[104] * xx[90];
  xx[106] = xx[1] * xx[100] - xx[2] * xx[32];
  xx[32] = xx[6] * xx[99] * xx[106];
  xx[100] = xx[98] * xx[102] - xx[105] * xx[32];
  xx[107] = xx[93] * xx[90] + xx[95] * xx[103];
  xx[93] = xx[96] + xx[104] * xx[103];
  xx[95] = xx[30] + xx[93];
  xx[30] = xx[107] * xx[102] - xx[95] * xx[32];
  xx[96] = xx[100] * xx[102] - xx[30] * xx[32];
  xx[104] = xx[29] + xx[48] + xx[67] + xx[86] + xx[96];
  xx[108] = xx[38] * xx[46] + xx[51] * xx[43];
  xx[109] = xx[41] * xx[43] + xx[49] * xx[46];
  xx[110] = xx[43] * xx[108] - xx[109] * xx[46];
  xx[111] = xx[57] * xx[65] + xx[70] * xx[62];
  xx[112] = xx[60] * xx[62] + xx[68] * xx[65];
  xx[113] = xx[62] * xx[111] - xx[112] * xx[65];
  xx[114] = xx[76] * xx[84] + xx[89] * xx[81];
  xx[115] = xx[79] * xx[81] + xx[87] * xx[84];
  xx[116] = xx[81] * xx[114] - xx[115] * xx[84];
  xx[117] = xx[95] * xx[102] + xx[107] * xx[32];
  xx[118] = xx[98] * xx[32] + xx[105] * xx[102];
  xx[119] = xx[32] * xx[117] - xx[118] * xx[102];
  xx[120] = xx[110] + xx[113] + xx[116] + xx[119];
  xx[121] = xx[104] * xx[15] + xx[120] * xx[19];
  xx[122] = xx[43] * xx[109] + xx[108] * xx[46];
  xx[108] = xx[62] * xx[112] + xx[111] * xx[65];
  xx[109] = xx[81] * xx[115] + xx[114] * xx[84];
  xx[111] = xx[32] * xx[118] + xx[117] * xx[102];
  xx[112] = xx[29] + xx[122] + xx[108] + xx[109] + xx[111];
  xx[114] = xx[44] * xx[43] + xx[39] * xx[46];
  xx[39] = xx[63] * xx[62] + xx[58] * xx[65];
  xx[44] = xx[82] * xx[81] + xx[77] * xx[84];
  xx[58] = xx[100] * xx[32] + xx[30] * xx[102];
  xx[30] = xx[114] + xx[39] + xx[44] + xx[58];
  xx[63] = xx[112] * xx[19] - xx[30] * xx[15];
  xx[77] = 0.03468584073464102;
  xx[82] = (xx[45] + xx[50] * xx[50]) * xx[6] - xx[14];
  xx[45] = xx[77] * xx[82] * xx[82];
  xx[100] = (xx[64] + xx[69] * xx[69]) * xx[6] - xx[14];
  xx[64] = xx[77] * xx[100] * xx[100];
  xx[115] = (xx[83] + xx[88] * xx[88]) * xx[6] - xx[14];
  xx[83] = xx[77] * xx[115] * xx[115];
  xx[117] = (xx[101] + xx[106] * xx[106]) * xx[6] - xx[14];
  xx[101] = xx[77] * xx[117] * xx[117];
  xx[118] = xx[29] + xx[45] + xx[64] + xx[83] + xx[101];
  xx[29] = xx[118] * xx[25];
  xx[123] = xx[121];
  xx[124] = xx[63];
  xx[125] = xx[29];
  xx[126] = xx[11] * xx[13];
  xx[127] = xx[22] * xx[20];
  xx[128] = xx[6] * (xx[126] - xx[127]);
  xx[129] = (xx[23] + xx[24]) * xx[6];
  xx[23] = xx[120] * xx[128] - xx[104] * xx[129];
  xx[24] = xx[112] * xx[128] + xx[30] * xx[129];
  xx[130] = xx[22] * xx[22];
  xx[131] = (xx[130] + xx[12]) * xx[6] - xx[14];
  xx[12] = xx[118] * xx[131];
  xx[132] = xx[23];
  xx[133] = xx[24];
  xx[134] = xx[12];
  xx[135] = pm_math_Vector3_dot_ra(xx + 26, xx + 132);
  xx[136] = xx[6] * (xx[17] - xx[21]);
  xx[17] = (xx[4] + xx[130]) * xx[6] - xx[14];
  xx[4] = xx[104] * xx[136] + xx[120] * xx[17];
  xx[21] = xx[112] * xx[17] - xx[30] * xx[136];
  xx[130] = (xx[127] + xx[126]) * xx[6];
  xx[126] = xx[118] * xx[130];
  xx[137] = xx[4];
  xx[138] = xx[21];
  xx[139] = xx[126];
  xx[127] = pm_math_Vector3_dot_ra(xx + 26, xx + 137);
  xx[140] = 0.013;
  xx[141] = 2.999999999999993e-3;
  xx[142] = xx[140] - ((xx[34] * xx[141] * xx[34] + xx[141] * xx[37] * xx[37]) *
                       xx[6] - xx[141]);
  xx[143] = xx[49] * xx[142];
  xx[144] = xx[36] * xx[142];
  xx[145] = xx[143] * xx[46] - xx[144] * xx[43];
  xx[146] = xx[40] * xx[142];
  xx[147] = xx[51] * xx[142];
  xx[148] = xx[146] * xx[46] - xx[147] * xx[43];
  xx[149] = xx[145] * xx[46] + xx[148] * xx[43];
  xx[150] = 0.03000000000000002;
  xx[151] = xx[150] * xx[110];
  xx[152] = xx[140] - ((xx[53] * xx[141] * xx[53] + xx[141] * xx[56] * xx[56]) *
                       xx[6] - xx[141]);
  xx[140] = xx[68] * xx[152];
  xx[141] = xx[55] * xx[152];
  xx[153] = xx[140] * xx[65] - xx[141] * xx[62];
  xx[154] = xx[59] * xx[152];
  xx[155] = xx[70] * xx[152];
  xx[156] = xx[154] * xx[65] - xx[155] * xx[62];
  xx[157] = xx[153] * xx[65] + xx[156] * xx[62];
  xx[158] = 0.03000000000000003;
  xx[159] = xx[158] * xx[113];
  xx[160] = 0.013;
  xx[161] = 0.023;
  xx[162] = xx[160] - ((xx[72] * xx[161] * xx[72] + xx[161] * xx[75] * xx[75]) *
                       xx[6] - xx[161]);
  xx[161] = xx[87] * xx[162];
  xx[163] = xx[74] * xx[162];
  xx[164] = xx[161] * xx[84] - xx[163] * xx[81];
  xx[165] = xx[78] * xx[162];
  xx[166] = xx[89] * xx[162];
  xx[167] = xx[165] * xx[84] - xx[166] * xx[81];
  xx[168] = xx[164] * xx[84] + xx[167] * xx[81];
  xx[169] = 0.03;
  xx[170] = xx[169] * xx[116];
  xx[171] = 0.02299999999999999;
  xx[172] = xx[160] - ((xx[91] * xx[171] * xx[91] + xx[171] * xx[94] * xx[94]) *
                       xx[6] - xx[171]);
  xx[160] = xx[105] * xx[172];
  xx[171] = xx[93] * xx[172];
  xx[173] = xx[160] * xx[102] - xx[171] * xx[32];
  xx[174] = xx[97] * xx[172];
  xx[175] = xx[107] * xx[172];
  xx[176] = xx[174] * xx[102] - xx[175] * xx[32];
  xx[177] = xx[173] * xx[102] + xx[176] * xx[32];
  xx[178] = xx[150] * xx[119];
  xx[179] = xx[149] - xx[151] + xx[157] - xx[159] + xx[168] + xx[170] + xx[177]
    + xx[178];
  xx[180] = 0.9999999882127206;
  xx[181] = xx[148] * xx[46] - xx[145] * xx[43];
  xx[145] = xx[48] * xx[150];
  xx[148] = xx[156] * xx[65] - xx[153] * xx[62];
  xx[153] = xx[67] * xx[158];
  xx[156] = xx[167] * xx[84] - xx[164] * xx[81];
  xx[164] = xx[86] * xx[169];
  xx[167] = xx[176] * xx[102] - xx[173] * xx[32];
  xx[173] = xx[96] * xx[150];
  xx[176] = xx[181] + xx[145] + xx[148] + xx[153] + xx[156] - xx[164] + xx[167]
    - xx[173];
  xx[182] = 1.535400879247534e-4;
  xx[183] = xx[179] * xx[180] + xx[176] * xx[182];
  xx[184] = xx[109] * xx[169];
  xx[185] = xx[161] * xx[81] + xx[163] * xx[84];
  xx[186] = xx[165] * xx[81] + xx[166] * xx[84];
  xx[187] = xx[84] * xx[185] + xx[81] * xx[186];
  xx[188] = xx[143] * xx[43] + xx[144] * xx[46];
  xx[189] = xx[146] * xx[43] + xx[147] * xx[46];
  xx[190] = xx[46] * xx[188] + xx[43] * xx[189];
  xx[191] = xx[122] * xx[150];
  xx[192] = xx[140] * xx[62] + xx[141] * xx[65];
  xx[193] = xx[154] * xx[62] + xx[155] * xx[65];
  xx[194] = xx[65] * xx[192] + xx[62] * xx[193];
  xx[195] = xx[108] * xx[158];
  xx[196] = xx[111] * xx[150];
  xx[197] = xx[160] * xx[32] + xx[171] * xx[102];
  xx[198] = xx[174] * xx[32] + xx[175] * xx[102];
  xx[199] = xx[102] * xx[197] + xx[32] * xx[198];
  xx[200] = xx[184] - xx[187] - (xx[190] + xx[191] + xx[194] + xx[195]) + xx[196]
    - xx[199];
  xx[201] = xx[43] * xx[188] - xx[46] * xx[189];
  xx[188] = xx[150] * xx[114];
  xx[189] = xx[62] * xx[192] - xx[65] * xx[193];
  xx[192] = xx[158] * xx[39];
  xx[193] = xx[81] * xx[185] - xx[84] * xx[186];
  xx[185] = xx[169] * xx[44];
  xx[186] = xx[32] * xx[197] - xx[102] * xx[198];
  xx[197] = xx[150] * xx[58];
  xx[198] = xx[201] - xx[188] + xx[189] - xx[192] + xx[193] + xx[185] + xx[186]
    + xx[197];
  xx[202] = xx[200] * xx[180] + xx[198] * xx[182];
  xx[203] = 0.02284321658378479;
  xx[204] = xx[203] * xx[34];
  xx[205] = xx[6] * xx[204] * xx[37];
  xx[206] = xx[31] * xx[205];
  xx[207] = xx[206] * xx[82];
  xx[208] = 0.02304567302527693;
  xx[209] = xx[208] + xx[6] * xx[34] * xx[204] - xx[203];
  xx[204] = xx[31] * xx[209];
  xx[210] = xx[204] * xx[82];
  xx[211] = xx[43] * xx[207] - xx[210] * xx[46];
  xx[212] = 4.883471714082711e-5;
  xx[213] = 0.02895432697472308;
  xx[214] = xx[213] * xx[50];
  xx[215] = xx[212] + xx[213] - xx[6] * xx[214] * xx[50];
  xx[216] = xx[45] * xx[215];
  xx[217] = 0.0228432165837848;
  xx[218] = xx[217] * xx[53];
  xx[219] = xx[6] * xx[218] * xx[56];
  xx[220] = xx[31] * xx[219];
  xx[221] = xx[220] * xx[100];
  xx[222] = xx[208] + xx[6] * xx[53] * xx[218] - xx[217];
  xx[208] = xx[31] * xx[222];
  xx[218] = xx[208] * xx[100];
  xx[223] = xx[62] * xx[221] - xx[218] * xx[65];
  xx[224] = 1.559676967993742e-4;
  xx[225] = 0.02895432697472306;
  xx[226] = xx[225] * xx[69];
  xx[227] = xx[224] - (xx[225] - xx[6] * xx[226] * xx[69]);
  xx[228] = xx[64] * xx[227];
  xx[229] = 0.02284321658378478;
  xx[230] = xx[229] * xx[72];
  xx[231] = xx[6] * xx[230] * xx[75];
  xx[232] = xx[31] * xx[231];
  xx[233] = xx[232] * xx[115];
  xx[234] = 0.02304567302527694;
  xx[235] = xx[234] + xx[6] * xx[72] * xx[230] - xx[229];
  xx[230] = xx[31] * xx[235];
  xx[236] = xx[230] * xx[115];
  xx[237] = xx[81] * xx[233] - xx[236] * xx[84];
  xx[238] = 0.02895432697472309;
  xx[239] = xx[238] * xx[88];
  xx[240] = xx[212] + xx[238] - xx[6] * xx[239] * xx[88];
  xx[212] = xx[83] * xx[240];
  xx[241] = 0.02284321658378476;
  xx[242] = xx[241] * xx[91];
  xx[243] = xx[6] * xx[242] * xx[94];
  xx[244] = xx[31] * xx[243];
  xx[245] = xx[244] * xx[117];
  xx[246] = xx[234] + xx[6] * xx[91] * xx[242] - xx[241];
  xx[234] = xx[31] * xx[246];
  xx[242] = xx[234] * xx[117];
  xx[247] = xx[32] * xx[245] - xx[242] * xx[102];
  xx[248] = xx[238] * xx[106];
  xx[249] = xx[224] - (xx[238] - xx[6] * xx[248] * xx[106]);
  xx[224] = xx[101] * xx[249];
  xx[250] = xx[211] - xx[216] + xx[223] + xx[228] + xx[237] - xx[212] + xx[247]
    + xx[224];
  xx[251] = xx[43] * xx[210] + xx[207] * xx[46];
  xx[207] = 0.04200000799315259;
  xx[210] = xx[207] - xx[6] * xx[42] * xx[214];
  xx[214] = xx[210] * xx[45];
  xx[45] = xx[62] * xx[218] + xx[221] * xx[65];
  xx[218] = 0.0420000244423599;
  xx[221] = xx[218] + xx[6] * xx[61] * xx[226];
  xx[226] = xx[221] * xx[64];
  xx[64] = xx[81] * xx[236] + xx[233] * xx[84];
  xx[233] = xx[207] - xx[6] * xx[80] * xx[239];
  xx[207] = xx[233] * xx[83];
  xx[83] = xx[32] * xx[242] + xx[245] * xx[102];
  xx[236] = xx[218] + xx[6] * xx[99] * xx[248];
  xx[218] = xx[236] * xx[101];
  xx[101] = xx[251] - xx[214] + xx[45] + xx[226] + xx[64] - xx[207] + xx[83] +
    xx[218];
  xx[239] = 0.01000140236744092;
  xx[242] = xx[250] * xx[180] + xx[101] * xx[182] + xx[118] * xx[239];
  xx[252] = xx[183];
  xx[253] = xx[202];
  xx[254] = xx[242];
  xx[245] = pm_math_Vector3_dot_ra(xx + 26, xx + 252);
  xx[248] = xx[176] * xx[180] - xx[179] * xx[182];
  xx[255] = xx[198] * xx[180] - xx[200] * xx[182];
  xx[256] = xx[101] * xx[180] - xx[250] * xx[182];
  xx[257] = xx[248];
  xx[258] = xx[255];
  xx[259] = xx[256];
  xx[260] = pm_math_Vector3_dot_ra(xx + 26, xx + 257);
  xx[261] = 0.01000140224955159;
  xx[262] = 1.535616198867715e-6;
  xx[263] = xx[51] * xx[209] + xx[36] * xx[205];
  xx[36] = xx[40] * xx[209] + xx[49] * xx[205];
  xx[40] = (xx[263] * xx[46] + xx[36] * xx[43]) * xx[82];
  xx[264] = xx[114] * xx[215] - xx[210] * xx[122];
  xx[114] = xx[70] * xx[222] + xx[55] * xx[219];
  xx[55] = xx[59] * xx[222] + xx[68] * xx[219];
  xx[59] = (xx[114] * xx[65] + xx[55] * xx[62]) * xx[100];
  xx[122] = xx[108] * xx[221] - xx[227] * xx[39];
  xx[39] = xx[89] * xx[235] + xx[74] * xx[231];
  xx[74] = xx[78] * xx[235] + xx[87] * xx[231];
  xx[78] = (xx[39] * xx[84] + xx[74] * xx[81]) * xx[115];
  xx[108] = xx[44] * xx[240] - xx[233] * xx[109];
  xx[44] = xx[107] * xx[246] + xx[93] * xx[243];
  xx[93] = xx[97] * xx[246] + xx[105] * xx[243];
  xx[97] = (xx[44] * xx[102] + xx[93] * xx[32]) * xx[117];
  xx[109] = xx[111] * xx[236] - xx[249] * xx[58];
  xx[58] = xx[40] + xx[264] + xx[59] + xx[122] + xx[78] + xx[108] + xx[97] + xx
    [109];
  xx[111] = xx[30] * xx[261] - xx[112] * xx[262] - xx[58];
  xx[265] = (xx[263] * xx[43] - xx[36] * xx[46]) * xx[82];
  xx[266] = xx[48] * xx[215] + xx[210] * xx[110];
  xx[48] = (xx[114] * xx[62] - xx[55] * xx[65]) * xx[100];
  xx[110] = xx[67] * xx[227] + xx[221] * xx[113];
  xx[67] = (xx[39] * xx[81] - xx[74] * xx[84]) * xx[115];
  xx[113] = xx[86] * xx[240] + xx[233] * xx[116];
  xx[86] = (xx[44] * xx[32] - xx[93] * xx[102]) * xx[117];
  xx[116] = xx[96] * xx[249] + xx[236] * xx[119];
  xx[96] = xx[265] - xx[266] + xx[48] + xx[110] + xx[67] - xx[113] + xx[86] +
    xx[116];
  xx[119] = xx[104] * xx[261] + xx[120] * xx[262] + xx[96];
  xx[267] = xx[111] * xx[19] - xx[15] * xx[119];
  xx[268] = - xx[129];
  xx[269] = xx[128];
  xx[270] = xx[131];
  xx[271] = pm_math_Vector3_dot_ra(xx + 268, xx + 137);
  xx[272] = pm_math_Vector3_dot_ra(xx + 268, xx + 252);
  xx[273] = pm_math_Vector3_dot_ra(xx + 268, xx + 257);
  xx[274] = xx[111] * xx[128] + xx[129] * xx[119];
  xx[275] = xx[136];
  xx[276] = xx[17];
  xx[277] = xx[130];
  xx[278] = pm_math_Vector3_dot_ra(xx + 275, xx + 252);
  xx[252] = pm_math_Vector3_dot_ra(xx + 275, xx + 257);
  xx[253] = xx[111] * xx[17] - xx[136] * xx[119];
  xx[254] = 7.558260253012845e-6;
  xx[257] = 6.888775484766295e-6;
  xx[258] = xx[257] * xx[35];
  xx[259] = 1.045837943450455e-6;
  xx[279] = xx[259] * xx[33];
  xx[280] = xx[254] + xx[258] * xx[35] + xx[279] * xx[33] + xx[204] * xx[209] +
    xx[144] * xx[142];
  xx[281] = xx[257] * xx[33];
  xx[282] = xx[259] * xx[47];
  xx[283] = xx[281] * xx[35] + xx[282] * xx[33] + xx[206] * xx[209] - xx[147] *
    xx[142];
  xx[35] = xx[280] * xx[46] - xx[283] * xx[43];
  xx[284] = xx[258] * xx[33] + xx[279] * xx[47] + xx[204] * xx[205] - xx[143] *
    xx[142];
  xx[258] = 1.162181591388395e-6;
  xx[279] = xx[258] + xx[281] * xx[33] + xx[282] * xx[47] + xx[146] * xx[142] +
    xx[206] * xx[205];
  xx[33] = xx[284] * xx[46] - xx[279] * xx[43];
  xx[47] = xx[211] * xx[215] - xx[150] * xx[190];
  xx[281] = 6.888775484766298e-6;
  xx[282] = xx[281] * xx[54];
  xx[285] = xx[259] * xx[52];
  xx[286] = xx[254] + xx[282] * xx[54] + xx[285] * xx[52] + xx[208] * xx[222] +
    xx[141] * xx[152];
  xx[287] = xx[281] * xx[52];
  xx[288] = xx[259] * xx[66];
  xx[289] = xx[287] * xx[54] + xx[288] * xx[52] + xx[220] * xx[222] - xx[155] *
    xx[152];
  xx[54] = xx[286] * xx[65] - xx[289] * xx[62];
  xx[290] = xx[282] * xx[52] + xx[285] * xx[66] + xx[208] * xx[219] - xx[140] *
    xx[152];
  xx[282] = xx[258] + xx[287] * xx[52] + xx[288] * xx[66] + xx[154] * xx[152] +
    xx[220] * xx[219];
  xx[52] = xx[290] * xx[65] - xx[282] * xx[62];
  xx[66] = xx[158] * xx[194] + xx[223] * xx[227];
  xx[285] = 6.888775484766296e-6;
  xx[287] = xx[285] * xx[73];
  xx[288] = 1.045837943450455e-6;
  xx[291] = xx[288] * xx[71];
  xx[292] = xx[254] + xx[287] * xx[73] + xx[291] * xx[71] + xx[230] * xx[235] +
    xx[163] * xx[162];
  xx[293] = xx[285] * xx[71];
  xx[294] = xx[288] * xx[85];
  xx[295] = xx[293] * xx[73] + xx[294] * xx[71] + xx[232] * xx[235] - xx[166] *
    xx[162];
  xx[73] = xx[292] * xx[84] - xx[295] * xx[81];
  xx[296] = xx[287] * xx[71] + xx[291] * xx[85] + xx[230] * xx[231] - xx[161] *
    xx[162];
  xx[287] = xx[258] + xx[293] * xx[71] + xx[294] * xx[85] + xx[165] * xx[162] +
    xx[232] * xx[231];
  xx[71] = xx[296] * xx[84] - xx[287] * xx[81];
  xx[85] = xx[169] * xx[187] + xx[237] * xx[240];
  xx[291] = xx[285] * xx[92];
  xx[293] = xx[288] * xx[90];
  xx[294] = xx[254] + xx[291] * xx[92] + xx[293] * xx[90] + xx[234] * xx[246] +
    xx[171] * xx[172];
  xx[297] = xx[285] * xx[90];
  xx[298] = xx[288] * xx[103];
  xx[299] = xx[297] * xx[92] + xx[298] * xx[90] + xx[244] * xx[246] - xx[175] *
    xx[172];
  xx[92] = xx[294] * xx[102] - xx[299] * xx[32];
  xx[300] = xx[291] * xx[90] + xx[293] * xx[103] + xx[234] * xx[243] - xx[160] *
    xx[172];
  xx[291] = xx[258] + xx[297] * xx[90] + xx[298] * xx[103] + xx[174] * xx[172] +
    xx[244] * xx[243];
  xx[90] = xx[300] * xx[102] - xx[291] * xx[32];
  xx[103] = xx[150] * xx[199] - xx[247] * xx[249];
  xx[293] = 3.197120586509093e-5;
  xx[297] = xx[35] * xx[46] - xx[33] * xx[43] - xx[47] - xx[47] + xx[216] * xx
    [215] + xx[150] * xx[191] + xx[54] * xx[65] - xx[52] * xx[62] + xx[66] + xx
    [66] + xx[228] * xx[227] + xx[158] * xx[195] + xx[73] * xx[84] - xx[71] *
    xx[81] - xx[85] - xx[85] + xx[212] * xx[240] + xx[169] * xx[184] + xx[92] *
    xx[102] - xx[90] * xx[32] - xx[103] - xx[103] + xx[224] * xx[249] + xx[150] *
    xx[196] + xx[293];
  xx[47] = xx[279] * xx[46] + xx[284] * xx[43];
  xx[66] = xx[280] * xx[43] + xx[283] * xx[46];
  xx[85] = xx[210] * xx[211] - xx[150] * xx[149];
  xx[103] = xx[201] * xx[150] + xx[251] * xx[215];
  xx[211] = xx[282] * xx[65] + xx[290] * xx[62];
  xx[298] = xx[286] * xx[62] + xx[289] * xx[65];
  xx[301] = xx[223] * xx[221] + xx[158] * xx[157];
  xx[223] = xx[189] * xx[158] - xx[227] * xx[45];
  xx[302] = xx[287] * xx[84] + xx[296] * xx[81];
  xx[303] = xx[292] * xx[81] + xx[295] * xx[84];
  xx[304] = xx[233] * xx[237] + xx[169] * xx[168];
  xx[237] = xx[64] * xx[240] - xx[193] * xx[169];
  xx[305] = xx[291] * xx[102] + xx[300] * xx[32];
  xx[306] = xx[294] * xx[32] + xx[299] * xx[102];
  xx[307] = xx[150] * xx[177] - xx[247] * xx[236];
  xx[247] = xx[186] * xx[150] + xx[249] * xx[83];
  xx[308] = xx[43] * xx[47] - xx[66] * xx[46] - xx[85] - xx[103] + xx[214] * xx
    [215] + xx[150] * xx[188] + xx[62] * xx[211] - xx[298] * xx[65] + xx[301] -
    xx[223] + xx[226] * xx[227] + xx[158] * xx[192] + xx[81] * xx[302] - xx[303]
    * xx[84] - xx[304] - xx[237] + xx[207] * xx[240] + xx[169] * xx[185] + xx[32]
    * xx[305] - xx[306] * xx[102] - xx[307] + xx[247] + xx[218] * xx[249] + xx
    [150] * xx[197];
  xx[309] = xx[297] * xx[180] + xx[308] * xx[182] + xx[250] * xx[239];
  xx[310] = xx[301] - (xx[54] * xx[62] + xx[52] * xx[65] + xx[223]) - (xx[158] *
    xx[159] - xx[221] * xx[228]) - (xx[35] * xx[43] + xx[33] * xx[46] + xx[103]
    + xx[85] + xx[150] * xx[151] - xx[210] * xx[216]) - (xx[73] * xx[81] + xx[71]
    * xx[84] + xx[237] + xx[304] + xx[169] * xx[170] - xx[233] * xx[212]) + xx
    [247] - (xx[92] * xx[32] + xx[90] * xx[102]) - xx[307] - (xx[150] * xx[178]
    - xx[236] * xx[224]);
  xx[33] = xx[210] * xx[251] - xx[181] * xx[150];
  xx[35] = xx[221] * xx[45] + xx[148] * xx[158];
  xx[45] = xx[233] * xx[64] + xx[156] * xx[169];
  xx[52] = xx[167] * xx[150] - xx[236] * xx[83];
  xx[54] = 1.348671059813626e-4;
  xx[64] = xx[43] * xx[66] + xx[47] * xx[46] - xx[33] - xx[33] + xx[150] * xx
    [145] + xx[210] * xx[214] + xx[62] * xx[298] + xx[211] * xx[65] + xx[35] +
    xx[35] + xx[158] * xx[153] + xx[221] * xx[226] + xx[81] * xx[303] + xx[302] *
    xx[84] - xx[45] - xx[45] + xx[169] * xx[164] + xx[233] * xx[207] + xx[32] *
    xx[306] + xx[305] * xx[102] - xx[52] - xx[52] + xx[150] * xx[173] + xx[236] *
    xx[218] + xx[54];
  xx[33] = xx[310] * xx[180] + xx[64] * xx[182] + xx[101] * xx[239];
  xx[35] = xx[308] * xx[180] - xx[297] * xx[182];
  xx[45] = xx[64] * xx[180] - xx[310] * xx[182];
  xx[47] = xx[35] * xx[180] + xx[45] * xx[182] + xx[256] * xx[239];
  xx[52] = xx[36] * xx[142];
  xx[64] = xx[52] * xx[82];
  xx[66] = xx[263] * xx[142];
  xx[71] = xx[66] * xx[82];
  xx[73] = xx[210] * xx[190] - xx[149] * xx[215];
  xx[83] = xx[150] * xx[40];
  xx[85] = xx[55] * xx[152];
  xx[90] = xx[85] * xx[100];
  xx[92] = xx[114] * xx[152];
  xx[103] = xx[92] * xx[100];
  xx[149] = xx[227] * xx[157] - xx[221] * xx[194];
  xx[157] = xx[158] * xx[59];
  xx[190] = xx[74] * xx[162];
  xx[194] = xx[190] * xx[115];
  xx[207] = xx[39] * xx[162];
  xx[211] = xx[207] * xx[115];
  xx[212] = xx[233] * xx[187] - xx[168] * xx[240];
  xx[168] = xx[169] * xx[78];
  xx[187] = xx[93] * xx[172];
  xx[214] = xx[187] * xx[117];
  xx[216] = xx[44] * xx[172];
  xx[218] = xx[216] * xx[117];
  xx[223] = xx[249] * xx[177] - xx[236] * xx[199];
  xx[177] = xx[150] * xx[97];
  xx[199] = xx[43] * xx[64] + xx[71] * xx[46] - xx[73] + xx[83] + xx[150] * xx
    [264] + xx[62] * xx[90] + xx[103] * xx[65] - xx[149] + xx[157] + xx[158] *
    xx[122] + xx[81] * xx[194] + xx[211] * xx[84] - xx[212] - xx[168] - xx[169] *
    xx[108] + xx[32] * xx[214] + xx[218] * xx[102] - xx[223] - xx[177] - xx[150]
    * xx[109] - (xx[179] * xx[261] + xx[200] * xx[262]);
  xx[224] = xx[181] * xx[215] + xx[210] * xx[201];
  xx[181] = xx[150] * xx[265];
  xx[201] = xx[148] * xx[227] + xx[189] * xx[221];
  xx[148] = xx[158] * xx[48];
  xx[189] = xx[156] * xx[240] + xx[233] * xx[193];
  xx[156] = xx[169] * xx[67];
  xx[193] = xx[167] * xx[249] + xx[186] * xx[236];
  xx[167] = xx[150] * xx[86];
  xx[186] = xx[176] * xx[261] + xx[198] * xx[262] + xx[43] * xx[71] - xx[64] *
    xx[46] - xx[224] + xx[181] - xx[150] * xx[266] + xx[62] * xx[103] - xx[90] *
    xx[65] + xx[201] + xx[148] + xx[158] * xx[110] + xx[81] * xx[211] - xx[194] *
    xx[84] - xx[189] - xx[156] + xx[169] * xx[113] + xx[32] * xx[218] - xx[214] *
    xx[102] + xx[193] - xx[167] - xx[150] * xx[116];
  xx[64] = xx[199] * xx[180] - xx[182] * xx[186];
  xx[71] = - (xx[199] * xx[182] + xx[180] * xx[186]);
  xx[90] = 8.224885814516596e-6;
  xx[103] = 7.656036730940041e-6;
  xx[194] = xx[90] + xx[103] + xx[263] * xx[205] + xx[36] * xx[209];
  xx[211] = xx[265] * xx[215] + xx[210] * xx[40];
  xx[40] = 7.656036730940044e-6;
  xx[214] = xx[90] + xx[40] + xx[114] * xx[219] + xx[55] * xx[222];
  xx[218] = xx[48] * xx[227] + xx[221] * xx[59];
  xx[48] = xx[90] + xx[103] + xx[39] * xx[231] + xx[74] * xx[235];
  xx[59] = xx[67] * xx[240] + xx[233] * xx[78];
  xx[67] = xx[90] + xx[103] + xx[44] * xx[243] + xx[93] * xx[246];
  xx[78] = xx[86] * xx[249] + xx[236] * xx[97];
  xx[86] = 1.101391944042172e-4;
  xx[97] = xx[194] * xx[82] * xx[82] - xx[211] - xx[211] - (xx[210] * xx[264] -
    xx[266] * xx[215]) + xx[214] * xx[100] * xx[100] + xx[218] + xx[218] + xx
    [221] * xx[122] + xx[227] * xx[110] + xx[48] * xx[115] * xx[115] - xx[59] -
    xx[59] - (xx[233] * xx[108] - xx[113] * xx[240]) + xx[67] * xx[117] * xx[117]
    + xx[78] + xx[78] + xx[236] * xx[109] + xx[249] * xx[116] + xx[86] + xx[58] *
    xx[262] + xx[96] * xx[261];
  xx[310] = pm_math_Vector3_dot_ra(xx + 26, xx + 123);
  xx[311] = xx[135];
  xx[312] = xx[127];
  xx[313] = xx[245];
  xx[314] = xx[260];
  xx[315] = xx[267];
  xx[316] = xx[135];
  xx[317] = pm_math_Vector3_dot_ra(xx + 268, xx + 132);
  xx[318] = xx[271];
  xx[319] = xx[272];
  xx[320] = xx[273];
  xx[321] = xx[274];
  xx[322] = xx[127];
  xx[323] = xx[271];
  xx[324] = pm_math_Vector3_dot_ra(xx + 275, xx + 137);
  xx[325] = xx[278];
  xx[326] = xx[252];
  xx[327] = xx[253];
  xx[328] = xx[245];
  xx[329] = xx[272];
  xx[330] = xx[278];
  xx[331] = xx[309] * xx[180] + xx[33] * xx[182] + xx[242] * xx[239];
  xx[332] = xx[47];
  xx[333] = xx[64];
  xx[334] = xx[260];
  xx[335] = xx[273];
  xx[336] = xx[252];
  xx[337] = xx[47];
  xx[338] = xx[45] * xx[180] - xx[35] * xx[182];
  xx[339] = xx[71];
  xx[340] = xx[267];
  xx[341] = xx[274];
  xx[342] = xx[253];
  xx[343] = xx[64];
  xx[344] = xx[71];
  xx[345] = xx[97] + xx[261] * xx[119] - xx[111] * xx[262];
  ii[0] = factorSymmetricPosDef(xx + 310, 6, xx + 301);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'modeloMK4_funcional/6-DOF Joint' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[47] = xx[2] * state[11];
  xx[59] = xx[2] * state[10];
  xx[64] = state[10] - (xx[1] * xx[47] + xx[2] * xx[59]) * xx[6];
  xx[71] = state[11] + xx[6] * (xx[1] * xx[59] - xx[2] * xx[47]);
  xx[47] = xx[71] * xx[50];
  xx[59] = xx[50] * xx[64];
  xx[78] = xx[64] - xx[6] * (xx[42] * xx[47] + xx[59] * xx[50]);
  xx[108] = xx[71] - (xx[47] * xx[50] - xx[42] * xx[59]) * xx[6];
  xx[47] = state[12] - inputDot[6];
  xx[122] = xx[78];
  xx[123] = xx[108];
  xx[124] = xx[47];
  xx[132] = - xx[205];
  xx[133] = - xx[209];
  xx[134] = xx[142];
  pm_math_Vector3_cross_ra(xx + 122, xx + 132, xx + 137);
  pm_math_Vector3_cross_ra(xx + 122, xx + 137, xx + 251);
  xx[59] = xx[34] * xx[252] + xx[251] * xx[37];
  xx[109] = (xx[251] - xx[6] * xx[59] * xx[37] - xx[203] * inputDdot[3]) * xx[31];
  xx[110] = xx[47] - (xx[34] * xx[34] * xx[47] + xx[37] * xx[47] * xx[37]) * xx
    [6];
  xx[113] = xx[110] + inputDot[3];
  xx[116] = xx[203] * inputDot[3];
  xx[125] = (xx[252] - xx[6] * xx[59] * xx[34] - (xx[110] + xx[113]) * xx[116]) *
    xx[31];
  xx[59] = xx[34] * xx[125] + xx[109] * xx[37];
  xx[110] = xx[109] - xx[6] * xx[59] * xx[37];
  xx[109] = xx[78] * inputDot[6];
  xx[127] = xx[108] * inputDot[6];
  xx[137] = xx[64];
  xx[138] = xx[71];
  xx[139] = state[12];
  xx[264] = xx[210];
  xx[265] = - xx[215];
  xx[266] = xx[150];
  pm_math_Vector3_cross_ra(xx + 137, xx + 264, xx + 271);
  pm_math_Vector3_cross_ra(xx + 137, xx + 271, xx + 301);
  xx[135] = xx[302] * xx[50];
  xx[142] = xx[301] * xx[50];
  xx[203] = xx[301] - xx[6] * (xx[42] * xx[135] + xx[142] * xx[50]) - xx[213] *
    inputDdot[6];
  xx[211] = xx[213] * inputDot[6];
  xx[213] = xx[302] - (xx[135] * xx[50] - xx[42] * xx[142]) * xx[6] - (state[12]
    + xx[47]) * xx[211];
  xx[135] = xx[110] + xx[146] * xx[109] - xx[143] * xx[127] - xx[36] *
    inputDdot[6] + xx[203] * xx[41] - xx[49] * xx[213];
  xx[41] = xx[135] * xx[50];
  xx[49] = xx[125] - xx[6] * xx[59] * xx[34];
  xx[59] = xx[49] + xx[144] * xx[127] - xx[147] * xx[109] + xx[263] * inputDdot
    [6] + xx[38] * xx[213] - xx[203] * xx[51];
  xx[38] = xx[59] * xx[50];
  xx[51] = xx[135] - (xx[41] * xx[50] - xx[42] * xx[38]) * xx[6];
  xx[125] = 0.0;
  xx[346] = xx[0];
  xx[347] = xx[125];
  xx[348] = xx[125];
  xx[349] = xx[0];
  xx[350] = xx[125];
  xx[351] = xx[125];
  xx[352] = - 0.18;
  xx[135] = 2.153196201808899e-10;
  xx[142] = 1.402367424384834e-6;
  xx[218] = xx[142] * xx[13];
  xx[226] = - xx[11];
  xx[271] = xx[22];
  xx[272] = xx[226];
  xx[273] = xx[13];
  xx[228] = xx[135] * xx[13];
  xx[237] = xx[11] * xx[135] - xx[22] * xx[142];
  xx[304] = xx[218];
  xx[305] = xx[228];
  xx[306] = xx[237];
  pm_math_Vector3_cross_ra(xx + 271, xx + 304, xx + 353);
  xx[271] = xx[5];
  xx[272] = - xx[18];
  xx[273] = xx[16];
  xx[245] = xx[261] * xx[16];
  xx[247] = xx[262] * xx[16];
  xx[16] = xx[18] * xx[262] - xx[261] * xx[5];
  xx[304] = xx[245];
  xx[305] = xx[247];
  xx[306] = xx[16];
  pm_math_Vector3_cross_ra(xx + 271, xx + 304, xx + 356);
  xx[5] = state[0] - xx[6] * (xx[356] - xx[245] * xx[3]) - xx[262];
  xx[18] = 0.5000000000000001;
  xx[245] = xx[5] * xx[18];
  xx[260] = state[1] - (xx[357] - xx[247] * xx[3]) * xx[6] + xx[261];
  xx[247] = 1.414213562373095;
  xx[267] = state[2] - (xx[358] - xx[16] * xx[3]) * xx[6];
  xx[3] = xx[247] * (xx[0] * xx[267] + xx[260] * xx[0]);
  xx[356] = - (xx[2] * xx[13] - xx[1] * xx[20]);
  xx[357] = xx[22] * xx[1] - xx[11] * xx[2];
  xx[358] = - (xx[11] * xx[1] + xx[22] * xx[2]);
  xx[359] = xx[1] * xx[13] + xx[2] * xx[20];
  xx[360] = xx[135] + (xx[218] * xx[20] + xx[353]) * xx[6] + xx[5] - (xx[245] +
    xx[245]) * xx[6] + 0.06370113964882761;
  xx[361] = xx[6] * (xx[354] + xx[228] * xx[20]) - xx[142] + xx[260] - xx[3] +
    0.02757152586923429;
  xx[362] = xx[6] * (xx[355] + xx[237] * xx[20]) + xx[267] - xx[3] -
    0.02944846882862407;
  bb[0] = sm_core_compiler_computeProximityInfoPlaneBrick(
    modeloMK4_funcional_4ef989e3_1_geometry_1(NULL),
    modeloMK4_funcional_4ef989e3_1_geometry_0(NULL), (pm_math_Transform3 *)(xx +
    346), (pm_math_Transform3 *)(xx + 356), xx + 3, (pm_math_Vector3 *)(xx + 271),
    (pm_math_Vector3 *)(xx + 304), (pm_math_Vector3 *)(xx + 353),
    (pm_math_Vector3 *)(xx + 363));
  xx[366] = xx[1];
  xx[367] = xx[125];
  xx[368] = xx[125];
  xx[369] = xx[2];
  xx[370] = xx[135];
  xx[371] = - xx[142];
  xx[372] = xx[125];
  xx[373] = xx[20];
  xx[374] = xx[22];
  xx[375] = xx[226];
  xx[376] = xx[13];
  xx[1] = xx[18] * state[7];
  xx[2] = xx[247] * (xx[0] * state[9] + xx[0] * state[8]);
  xx[377] = state[7] - (xx[1] + xx[1]) * xx[6];
  xx[378] = state[8] - xx[2];
  xx[379] = state[9] - xx[2];
  pm_math_Quaternion_inverseXform_ra(xx + 373, xx + 377, xx + 0);
  xx[5] = xx[0] - xx[261] * state[12];
  xx[16] = xx[1] - xx[262] * state[12];
  xx[18] = xx[2] + xx[261] * xx[64] + xx[71] * xx[262];
  xx[373] = xx[64];
  xx[374] = xx[71];
  xx[375] = state[12];
  xx[376] = xx[5];
  xx[377] = xx[16];
  xx[378] = xx[18];
  xx[135] = 1.0e6;
  xx[142] = 1000.0;
  xx[218] = 1.0e-4;
  xx[226] = 0.3;
  xx[228] = 0.2119573811760597;
  xx[237] = 9.126024771145405e-4;
  sm_core_compiler_computeSpatialContactWrenches(
    0, 1, bb[0], xx + 3, (const pm_math_Vector3 *)(xx + 271), (const
    pm_math_Vector3 *)(xx + 304), (const pm_math_Vector3 *)(xx + 353), (const
    pm_math_Vector3 *)(xx + 363),
    (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)(xx +
    366), (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)
    (xx + 356), NULL, (const pm_math_SpatialVector *)(xx + 373),
    0, 1, xx[135], xx[142], xx[218], xx[226], xx[228], xx[237], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 379));
  xx[3] = xx[71] * xx[69];
  xx[245] = xx[69] * xx[64];
  xx[247] = xx[64] - xx[6] * (xx[61] * xx[3] + xx[245] * xx[69]);
  xx[260] = xx[71] - (xx[3] * xx[69] - xx[61] * xx[245]) * xx[6];
  xx[3] = state[12] - inputDot[4];
  xx[271] = xx[247];
  xx[272] = xx[260];
  xx[273] = xx[3];
  xx[304] = - xx[219];
  xx[305] = - xx[222];
  xx[306] = xx[152];
  pm_math_Vector3_cross_ra(xx + 271, xx + 304, xx + 353);
  pm_math_Vector3_cross_ra(xx + 271, xx + 353, xx + 356);
  xx[152] = xx[53] * xx[357] + xx[356] * xx[56];
  xx[245] = (xx[356] - xx[6] * xx[152] * xx[56] - xx[217] * inputDdot[2]) * xx
    [31];
  xx[267] = xx[3] - (xx[53] * xx[53] * xx[3] + xx[56] * xx[3] * xx[56]) * xx[6];
  xx[274] = xx[267] + inputDot[2];
  xx[278] = xx[217] * inputDot[2];
  xx[217] = (xx[357] - xx[6] * xx[152] * xx[53] - (xx[267] + xx[274]) * xx[278])
    * xx[31];
  xx[152] = xx[53] * xx[217] + xx[245] * xx[56];
  xx[267] = xx[245] - xx[6] * xx[152] * xx[56];
  xx[245] = xx[247] * inputDot[4];
  xx[297] = xx[260] * inputDot[4];
  xx[353] = - xx[221];
  xx[354] = xx[227];
  xx[355] = xx[158];
  pm_math_Vector3_cross_ra(xx + 137, xx + 353, xx + 359);
  pm_math_Vector3_cross_ra(xx + 137, xx + 359, xx + 362);
  xx[158] = xx[363] * xx[69];
  xx[298] = xx[362] * xx[69];
  xx[307] = xx[362] - xx[6] * (xx[61] * xx[158] + xx[298] * xx[69]) - xx[225] *
    inputDdot[4];
  xx[308] = xx[225] * inputDot[4];
  xx[225] = xx[363] - (xx[158] * xx[69] - xx[61] * xx[298]) * xx[6] - (state[12]
    + xx[3]) * xx[308];
  xx[158] = xx[267] + xx[154] * xx[245] - xx[140] * xx[297] - xx[55] *
    inputDdot[4] + xx[307] * xx[60] - xx[68] * xx[225];
  xx[60] = xx[158] * xx[69];
  xx[68] = xx[217] - xx[6] * xx[152] * xx[53];
  xx[152] = xx[68] + xx[141] * xx[297] - xx[155] * xx[245] + xx[114] *
    inputDdot[4] + xx[57] * xx[225] - xx[307] * xx[70];
  xx[57] = xx[152] * xx[69];
  xx[70] = xx[158] - (xx[60] * xx[69] - xx[61] * xx[57]) * xx[6];
  xx[158] = xx[71] * xx[88];
  xx[217] = xx[88] * xx[64];
  xx[298] = xx[64] - xx[6] * (xx[80] * xx[158] + xx[217] * xx[88]);
  xx[359] = xx[71] - (xx[158] * xx[88] - xx[80] * xx[217]) * xx[6];
  xx[158] = state[12] - inputDot[7];
  xx[365] = xx[298];
  xx[366] = xx[359];
  xx[367] = xx[158];
  xx[368] = - xx[231];
  xx[369] = - xx[235];
  xx[370] = xx[162];
  pm_math_Vector3_cross_ra(xx + 365, xx + 368, xx + 371);
  pm_math_Vector3_cross_ra(xx + 365, xx + 371, xx + 374);
  xx[162] = xx[72] * xx[375] + xx[374] * xx[75];
  xx[217] = (xx[374] - xx[6] * xx[162] * xx[75] - xx[229] * inputDdot[1]) * xx
    [31];
  xx[360] = xx[158] - (xx[72] * xx[72] * xx[158] + xx[75] * xx[158] * xx[75]) *
    xx[6];
  xx[361] = xx[360] + inputDot[1];
  xx[371] = xx[229] * inputDot[1];
  xx[229] = (xx[375] - xx[6] * xx[162] * xx[72] - (xx[360] + xx[361]) * xx[371])
    * xx[31];
  xx[162] = xx[72] * xx[229] + xx[217] * xx[75];
  xx[360] = xx[217] - xx[6] * xx[162] * xx[75];
  xx[217] = xx[298] * inputDot[7];
  xx[372] = xx[359] * inputDot[7];
  xx[385] = xx[233];
  xx[386] = - xx[240];
  xx[387] = - xx[169];
  pm_math_Vector3_cross_ra(xx + 137, xx + 385, xx + 388);
  pm_math_Vector3_cross_ra(xx + 137, xx + 388, xx + 391);
  xx[169] = xx[392] * xx[88];
  xx[373] = xx[391] * xx[88];
  xx[377] = xx[391] - xx[6] * (xx[80] * xx[169] + xx[373] * xx[88]) - xx[238] *
    inputDdot[7];
  xx[378] = xx[238] * inputDot[7];
  xx[388] = xx[392] - (xx[169] * xx[88] - xx[80] * xx[373]) * xx[6] - (state[12]
    + xx[158]) * xx[378];
  xx[169] = xx[360] + xx[165] * xx[217] - xx[161] * xx[372] - xx[74] *
    inputDdot[7] + xx[377] * xx[79] - xx[87] * xx[388];
  xx[79] = xx[169] * xx[88];
  xx[87] = xx[229] - xx[6] * xx[162] * xx[72];
  xx[162] = xx[87] + xx[163] * xx[372] - xx[166] * xx[217] + xx[39] * inputDdot
    [7] + xx[76] * xx[388] - xx[377] * xx[89];
  xx[76] = xx[162] * xx[88];
  xx[89] = xx[169] - (xx[79] * xx[88] - xx[80] * xx[76]) * xx[6];
  xx[169] = xx[71] * xx[106];
  xx[229] = xx[106] * xx[64];
  xx[373] = xx[64] - xx[6] * (xx[99] * xx[169] + xx[229] * xx[106]);
  xx[389] = xx[71] - (xx[169] * xx[106] - xx[99] * xx[229]) * xx[6];
  xx[169] = state[12] - inputDot[5];
  xx[394] = xx[373];
  xx[395] = xx[389];
  xx[396] = xx[169];
  xx[397] = - xx[243];
  xx[398] = - xx[246];
  xx[399] = xx[172];
  pm_math_Vector3_cross_ra(xx + 394, xx + 397, xx + 400);
  pm_math_Vector3_cross_ra(xx + 394, xx + 400, xx + 403);
  xx[172] = xx[91] * xx[404] + xx[403] * xx[94];
  xx[229] = (xx[403] - xx[6] * xx[172] * xx[94] - xx[241] * inputDdot[0]) * xx
    [31];
  xx[390] = xx[169] - (xx[91] * xx[91] * xx[169] + xx[94] * xx[169] * xx[94]) *
    xx[6];
  xx[400] = xx[390] + inputDot[0];
  xx[401] = xx[241] * inputDot[0];
  xx[241] = (xx[404] - xx[6] * xx[172] * xx[91] - (xx[390] + xx[400]) * xx[401])
    * xx[31];
  xx[172] = xx[91] * xx[241] + xx[229] * xx[94];
  xx[390] = xx[229] - xx[6] * xx[172] * xx[94];
  xx[229] = xx[373] * inputDot[5];
  xx[402] = xx[389] * inputDot[5];
  xx[406] = - xx[236];
  xx[407] = xx[249];
  xx[408] = - xx[150];
  pm_math_Vector3_cross_ra(xx + 137, xx + 406, xx + 409);
  pm_math_Vector3_cross_ra(xx + 137, xx + 409, xx + 412);
  xx[150] = xx[413] * xx[106];
  xx[409] = xx[412] * xx[106];
  xx[410] = xx[412] - xx[6] * (xx[99] * xx[150] + xx[409] * xx[106]) - xx[238] *
    inputDdot[5];
  xx[411] = xx[238] * inputDot[5];
  xx[238] = xx[413] - (xx[150] * xx[106] - xx[99] * xx[409]) * xx[6] - (state[12]
    + xx[169]) * xx[411];
  xx[150] = xx[390] + xx[174] * xx[229] - xx[160] * xx[402] - xx[93] *
    inputDdot[5] + xx[410] * xx[98] - xx[105] * xx[238];
  xx[98] = xx[150] * xx[106];
  xx[105] = xx[241] - xx[6] * xx[172] * xx[91];
  xx[172] = xx[105] + xx[171] * xx[402] - xx[175] * xx[229] + xx[44] *
    inputDdot[5] + xx[95] * xx[238] - xx[410] * xx[107];
  xx[95] = xx[172] * xx[106];
  xx[107] = xx[150] - (xx[98] * xx[106] - xx[99] * xx[95]) * xx[6];
  xx[415] = xx[5];
  xx[416] = xx[16];
  xx[417] = xx[18];
  pm_math_Vector3_cross_ra(xx + 137, xx + 415, xx + 418);
  xx[415] = - xx[0];
  xx[416] = - xx[1];
  xx[417] = - xx[2];
  pm_math_Vector3_cross_ra(xx + 137, xx + 415, xx + 0);
  xx[5] = xx[418] + xx[0];
  xx[16] = xx[419] + xx[1];
  xx[18] = xx[51] - xx[382] + xx[70] + xx[89] + xx[107] + xx[104] * xx[5] + xx
    [120] * xx[16];
  xx[104] = xx[59] - xx[6] * (xx[42] * xx[41] + xx[38] * xx[50]);
  xx[38] = xx[152] - xx[6] * (xx[61] * xx[60] + xx[57] * xx[69]);
  xx[41] = xx[162] - xx[6] * (xx[80] * xx[79] + xx[76] * xx[88]);
  xx[57] = xx[172] - xx[6] * (xx[99] * xx[98] + xx[95] * xx[106]);
  xx[59] = xx[104] - xx[383] + xx[38] + xx[41] + xx[57] + xx[112] * xx[16] - xx
    [30] * xx[5];
  xx[30] = xx[34] * xx[108] + xx[78] * xx[37];
  xx[60] = xx[108] - xx[6] * xx[30] * xx[34];
  xx[76] = xx[31] * (xx[253] - (xx[34] * xx[34] * xx[253] + xx[253] * xx[37] *
    xx[37]) * xx[6] + (xx[60] + xx[60]) * xx[116]);
  xx[79] = xx[76] - (xx[34] * xx[34] * xx[76] + xx[76] * xx[37] * xx[37]) * xx[6];
  xx[76] = xx[303] + (xx[108] + xx[108]) * xx[211];
  xx[95] = xx[79] + xx[77] * xx[76] + xx[204] * xx[127] + xx[109] * xx[206];
  xx[98] = xx[53] * xx[260] + xx[247] * xx[56];
  xx[112] = xx[260] - xx[6] * xx[98] * xx[53];
  xx[116] = xx[31] * (xx[358] - (xx[53] * xx[53] * xx[358] + xx[358] * xx[56] *
    xx[56]) * xx[6] + (xx[112] + xx[112]) * xx[278]);
  xx[120] = xx[116] - (xx[53] * xx[53] * xx[116] + xx[116] * xx[56] * xx[56]) *
    xx[6];
  xx[116] = xx[364] + (xx[260] + xx[260]) * xx[308];
  xx[150] = xx[120] + xx[77] * xx[116] + xx[208] * xx[297] + xx[245] * xx[220];
  xx[152] = xx[72] * xx[359] + xx[298] * xx[75];
  xx[162] = xx[359] - xx[6] * xx[152] * xx[72];
  xx[172] = xx[31] * (xx[376] - (xx[72] * xx[72] * xx[376] + xx[376] * xx[75] *
    xx[75]) * xx[6] + (xx[162] + xx[162]) * xx[371]);
  xx[211] = xx[172] - (xx[72] * xx[72] * xx[172] + xx[172] * xx[75] * xx[75]) *
    xx[6];
  xx[172] = xx[393] + (xx[359] + xx[359]) * xx[378];
  xx[241] = xx[211] + xx[77] * xx[172] + xx[230] * xx[372] + xx[217] * xx[232];
  xx[251] = xx[91] * xx[389] + xx[373] * xx[94];
  xx[252] = xx[389] - xx[6] * xx[251] * xx[91];
  xx[253] = xx[31] * (xx[405] - (xx[91] * xx[91] * xx[405] + xx[405] * xx[94] *
    xx[94]) * xx[6] + (xx[252] + xx[252]) * xx[401]);
  xx[31] = xx[253] - (xx[91] * xx[91] * xx[253] + xx[253] * xx[94] * xx[94]) *
    xx[6];
  xx[253] = xx[414] + (xx[389] + xx[389]) * xx[411];
  xx[278] = xx[31] + xx[77] * xx[253] + xx[234] * xx[402] + xx[229] * xx[244];
  xx[0] = xx[420] + xx[2];
  xx[1] = xx[95] - xx[384] + xx[150] + xx[241] + xx[278] + xx[118] * xx[0];
  xx[301] = xx[18];
  xx[302] = xx[59];
  xx[303] = xx[1];
  xx[356] = xx[293] * xx[64];
  xx[357] = xx[71] * xx[54];
  xx[358] = xx[86] * state[12];
  pm_math_Vector3_cross_ra(xx + 137, xx + 356, xx + 362);
  xx[137] = xx[78] * xx[254];
  xx[138] = xx[258] * xx[108];
  xx[139] = xx[90] * xx[47];
  pm_math_Vector3_cross_ra(xx + 122, xx + 137, xx + 356);
  xx[2] = xx[78] - xx[6] * xx[30] * xx[37];
  xx[122] = xx[2];
  xx[123] = xx[60];
  xx[124] = xx[113];
  xx[137] = xx[257] * xx[2];
  xx[138] = xx[259] * xx[60];
  xx[139] = xx[113] * xx[103];
  pm_math_Vector3_cross_ra(xx + 122, xx + 137, xx + 374);
  xx[30] = xx[374] + xx[257] * xx[60] * inputDot[3];
  xx[47] = xx[375] - xx[259] * xx[2] * inputDot[3];
  xx[2] = xx[34] * xx[47] + xx[30] * xx[37];
  xx[122] = xx[110];
  xx[123] = xx[49];
  xx[124] = xx[79];
  pm_math_Vector3_cross_ra(xx + 132, xx + 122, xx + 77);
  xx[49] = xx[144] * xx[205] + xx[143] * xx[209];
  xx[54] = xx[147] * xx[205] + xx[146] * xx[209];
  xx[411] = xx[280];
  xx[412] = - xx[283];
  xx[413] = xx[66];
  xx[414] = - xx[284];
  xx[415] = xx[279];
  xx[416] = xx[52];
  xx[417] = xx[49];
  xx[418] = xx[54];
  xx[419] = xx[194];
  xx[122] = - xx[127];
  xx[123] = xx[109];
  xx[124] = - inputDdot[6];
  pm_math_Matrix3x3_xform_ra(xx + 411, xx + 122, xx + 108);
  xx[52] = xx[356] + xx[30] - xx[6] * xx[2] * xx[37] + xx[77] + xx[108] + xx[203]
    * xx[143] - xx[213] * xx[144] - xx[204] * xx[76];
  xx[30] = xx[52] * xx[50];
  xx[60] = xx[357] + xx[47] - xx[6] * xx[2] * xx[34] + xx[78] + xx[109] + xx[203]
    * xx[146] - xx[213] * xx[147] + xx[206] * xx[76];
  xx[2] = xx[60] * xx[50];
  xx[122] = xx[51];
  xx[123] = xx[104];
  xx[124] = xx[95];
  pm_math_Vector3_cross_ra(xx + 264, xx + 122, xx + 132);
  xx[122] = xx[247] * xx[254];
  xx[123] = xx[258] * xx[260];
  xx[124] = xx[90] * xx[3];
  pm_math_Vector3_cross_ra(xx + 271, xx + 122, xx + 137);
  xx[3] = xx[247] - xx[6] * xx[98] * xx[56];
  xx[122] = xx[3];
  xx[123] = xx[112];
  xx[124] = xx[274];
  xx[204] = xx[281] * xx[3];
  xx[205] = xx[259] * xx[112];
  xx[206] = xx[274] * xx[40];
  pm_math_Vector3_cross_ra(xx + 122, xx + 204, xx + 264);
  xx[47] = xx[264] + xx[281] * xx[112] * inputDot[2];
  xx[51] = xx[265] - xx[259] * xx[3] * inputDot[2];
  xx[3] = xx[53] * xx[51] + xx[47] * xx[56];
  xx[122] = xx[267];
  xx[123] = xx[68];
  xx[124] = xx[120];
  pm_math_Vector3_cross_ra(xx + 304, xx + 122, xx + 204);
  xx[64] = xx[141] * xx[219] + xx[140] * xx[222];
  xx[66] = xx[155] * xx[219] + xx[154] * xx[222];
  xx[411] = xx[286];
  xx[412] = - xx[289];
  xx[413] = xx[92];
  xx[414] = - xx[290];
  xx[415] = xx[282];
  xx[416] = xx[85];
  xx[417] = xx[64];
  xx[418] = xx[66];
  xx[419] = xx[214];
  xx[122] = - xx[297];
  xx[123] = xx[245];
  xx[124] = - inputDdot[4];
  pm_math_Matrix3x3_xform_ra(xx + 411, xx + 122, xx + 271);
  xx[68] = xx[137] + xx[47] - xx[6] * xx[3] * xx[56] + xx[204] + xx[271] + xx
    [307] * xx[140] - xx[225] * xx[141] - xx[208] * xx[116];
  xx[47] = xx[68] * xx[69];
  xx[71] = xx[138] + xx[51] - xx[6] * xx[3] * xx[53] + xx[205] + xx[272] + xx
    [307] * xx[154] - xx[225] * xx[155] + xx[220] * xx[116];
  xx[3] = xx[71] * xx[69];
  xx[122] = xx[70];
  xx[123] = xx[38];
  xx[124] = xx[150];
  pm_math_Vector3_cross_ra(xx + 353, xx + 122, xx + 279);
  xx[122] = xx[298] * xx[254];
  xx[123] = xx[258] * xx[359];
  xx[124] = xx[90] * xx[158];
  pm_math_Vector3_cross_ra(xx + 365, xx + 122, xx + 282);
  xx[38] = xx[298] - xx[6] * xx[152] * xx[75];
  xx[122] = xx[38];
  xx[123] = xx[162];
  xx[124] = xx[361];
  xx[304] = xx[285] * xx[38];
  xx[305] = xx[288] * xx[162];
  xx[306] = xx[361] * xx[103];
  pm_math_Vector3_cross_ra(xx + 122, xx + 304, xx + 353);
  xx[51] = xx[353] + xx[285] * xx[162] * inputDot[1];
  xx[70] = xx[354] - xx[288] * xx[38] * inputDot[1];
  xx[38] = xx[72] * xx[70] + xx[51] * xx[75];
  xx[122] = xx[360];
  xx[123] = xx[87];
  xx[124] = xx[211];
  pm_math_Vector3_cross_ra(xx + 368, xx + 122, xx + 85);
  xx[76] = xx[163] * xx[231] + xx[161] * xx[235];
  xx[92] = xx[166] * xx[231] + xx[165] * xx[235];
  xx[411] = xx[292];
  xx[412] = - xx[295];
  xx[413] = xx[207];
  xx[414] = - xx[296];
  xx[415] = xx[287];
  xx[416] = xx[190];
  xx[417] = xx[76];
  xx[418] = xx[92];
  xx[419] = xx[48];
  xx[122] = - xx[372];
  xx[123] = xx[217];
  xx[124] = - inputDdot[7];
  pm_math_Matrix3x3_xform_ra(xx + 411, xx + 122, xx + 207);
  xx[48] = xx[282] + xx[51] - xx[6] * xx[38] * xx[75] + xx[85] + xx[207] + xx
    [377] * xx[161] - xx[388] * xx[163] - xx[230] * xx[172];
  xx[51] = xx[48] * xx[88];
  xx[95] = xx[283] + xx[70] - xx[6] * xx[38] * xx[72] + xx[86] + xx[208] + xx
    [377] * xx[165] - xx[388] * xx[166] + xx[232] * xx[172];
  xx[38] = xx[95] * xx[88];
  xx[122] = xx[89];
  xx[123] = xx[41];
  xx[124] = xx[241];
  pm_math_Vector3_cross_ra(xx + 385, xx + 122, xx + 161);
  xx[122] = xx[373] * xx[254];
  xx[123] = xx[258] * xx[389];
  xx[124] = xx[90] * xx[169];
  pm_math_Vector3_cross_ra(xx + 394, xx + 122, xx + 230);
  xx[41] = xx[373] - xx[6] * xx[251] * xx[94];
  xx[122] = xx[41];
  xx[123] = xx[252];
  xx[124] = xx[400];
  xx[257] = xx[285] * xx[41];
  xx[258] = xx[288] * xx[252];
  xx[259] = xx[400] * xx[103];
  pm_math_Vector3_cross_ra(xx + 122, xx + 257, xx + 295);
  xx[70] = xx[295] + xx[285] * xx[252] * inputDot[0];
  xx[89] = xx[296] - xx[288] * xx[41] * inputDot[0];
  xx[41] = xx[91] * xx[89] + xx[70] * xx[94];
  xx[122] = xx[390];
  xx[123] = xx[105];
  xx[124] = xx[31];
  pm_math_Vector3_cross_ra(xx + 397, xx + 122, xx + 257);
  xx[31] = xx[171] * xx[243] + xx[160] * xx[246];
  xx[90] = xx[175] * xx[243] + xx[174] * xx[246];
  xx[365] = xx[294];
  xx[366] = - xx[299];
  xx[367] = xx[216];
  xx[368] = - xx[300];
  xx[369] = xx[291];
  xx[370] = xx[187];
  xx[371] = xx[31];
  xx[372] = xx[90];
  xx[373] = xx[67];
  xx[122] = - xx[402];
  xx[123] = xx[229];
  xx[124] = - inputDdot[5];
  pm_math_Matrix3x3_xform_ra(xx + 365, xx + 122, xx + 245);
  xx[67] = xx[230] + xx[70] - xx[6] * xx[41] * xx[94] + xx[257] + xx[245] + xx
    [410] * xx[160] - xx[238] * xx[171] - xx[234] * xx[253];
  xx[70] = xx[67] * xx[106];
  xx[98] = xx[231] + xx[89] - xx[6] * xx[41] * xx[91] + xx[258] + xx[246] + xx
    [410] * xx[174] - xx[238] * xx[175] + xx[244] * xx[253];
  xx[41] = xx[98] * xx[106];
  xx[122] = xx[107];
  xx[123] = xx[57];
  xx[124] = xx[278];
  pm_math_Vector3_cross_ra(xx + 406, xx + 122, xx + 251);
  xx[57] = xx[362] - xx[379] + xx[52] - (xx[30] * xx[50] - xx[42] * xx[2]) * xx
    [6] + xx[132] + xx[68] - (xx[47] * xx[69] - xx[61] * xx[3]) * xx[6] + xx[279]
    + xx[48] - (xx[51] * xx[88] - xx[80] * xx[38]) * xx[6] + xx[161] + xx[67] -
    (xx[70] * xx[106] - xx[99] * xx[41]) * xx[6] + xx[251] + xx[179] * xx[5] +
    xx[200] * xx[16] + xx[250] * xx[0];
  xx[48] = xx[363] - xx[380] + xx[60] - xx[6] * (xx[42] * xx[30] + xx[2] * xx[50])
    + xx[133] + xx[71] - xx[6] * (xx[61] * xx[47] + xx[3] * xx[69]) + xx[280] +
    xx[95] - xx[6] * (xx[80] * xx[51] + xx[38] * xx[88]) + xx[162] + xx[98] -
    xx[6] * (xx[99] * xx[70] + xx[41] * xx[106]) + xx[252] + xx[176] * xx[5] +
    xx[198] * xx[16] + xx[101] * xx[0];
  xx[0] = xx[376] + xx[103] * inputDdot[3];
  xx[2] = xx[266] + xx[40] * inputDdot[2];
  xx[3] = xx[355] + xx[103] * inputDdot[1];
  xx[30] = xx[297] + xx[103] * inputDdot[0];
  xx[103] = - pm_math_Vector3_dot_ra(xx + 26, xx + 301);
  xx[104] = - pm_math_Vector3_dot_ra(xx + 268, xx + 301);
  xx[105] = - pm_math_Vector3_dot_ra(xx + 275, xx + 301);
  xx[106] = - (xx[57] * xx[180] + xx[48] * xx[182] + xx[1] * xx[239]);
  xx[107] = - (xx[48] * xx[180] - xx[57] * xx[182]);
  xx[108] = - (xx[364] - xx[381] + xx[358] + xx[0] - (xx[34] * xx[0] * xx[34] +
    xx[0] * xx[37] * xx[37]) * xx[6] + xx[79] + xx[110] + xx[203] * xx[36] - xx
               [263] * xx[213] + xx[134] + xx[139] + xx[2] - (xx[53] * xx[2] *
    xx[53] + xx[2] * xx[56] * xx[56]) * xx[6] + xx[206] + xx[273] + xx[307] *
               xx[55] - xx[114] * xx[225] + xx[281] + xx[284] + xx[3] - (xx[72] *
    xx[3] * xx[72] + xx[3] * xx[75] * xx[75]) * xx[6] + xx[87] + xx[209] + xx
               [377] * xx[74] - xx[39] * xx[388] + xx[163] + xx[232] + xx[30] -
               (xx[91] * xx[30] * xx[91] + xx[30] * xx[94] * xx[94]) * xx[6] +
               xx[259] + xx[247] + xx[410] * xx[93] - xx[44] * xx[238] + xx[253]
               - (xx[58] * xx[16] + xx[96] * xx[5]) - (xx[18] * xx[261] + xx[59]
    * xx[262]));
  solveSymmetricPosDef(xx + 310, xx + 103, 6, 1, xx + 36, xx + 67);
  xx[0] = xx[82] * (xx[54] * xx[43] + xx[49] * xx[46]) + xx[83] - xx[73] - (xx
    [210] * xx[191] + xx[151] * xx[215]) + xx[100] * (xx[66] * xx[62] + xx[64] *
    xx[65]) + xx[157] - xx[149] + xx[221] * xx[195] + xx[159] * xx[227] + xx[115]
    * (xx[92] * xx[81] + xx[76] * xx[84]) - xx[168] - xx[212] + xx[233] * xx[184]
    + xx[170] * xx[240] + xx[117] * (xx[90] * xx[32] + xx[31] * xx[102]) - xx
    [177] - xx[223] - (xx[236] * xx[196] + xx[178] * xx[249]);
  xx[1] = (xx[49] * xx[43] - xx[54] * xx[46]) * xx[82] + xx[181] - xx[224] + xx
    [210] * xx[188] - xx[145] * xx[215] + (xx[64] * xx[62] - xx[66] * xx[65]) *
    xx[100] + xx[148] + xx[201] + xx[153] * xx[227] - xx[221] * xx[192] + (xx[76]
    * xx[81] - xx[92] * xx[84]) * xx[115] - xx[156] - xx[189] + xx[164] * xx[240]
    - xx[233] * xx[185] + (xx[31] * xx[32] - xx[90] * xx[102]) * xx[117] - xx
    [167] + xx[193] + xx[236] * xx[197] - xx[173] * xx[249];
  xx[257] = xx[179] * xx[15] + xx[200] * xx[19] + xx[250] * xx[25];
  xx[258] = xx[200] * xx[128] - xx[179] * xx[129] + xx[250] * xx[131];
  xx[259] = xx[179] * xx[136] + xx[200] * xx[17] + xx[250] * xx[130];
  xx[260] = xx[309];
  xx[261] = xx[35];
  xx[262] = xx[199];
  xx[263] = xx[176] * xx[15] + xx[198] * xx[19] + xx[101] * xx[25];
  xx[264] = xx[198] * xx[128] - xx[176] * xx[129] + xx[101] * xx[131];
  xx[265] = xx[176] * xx[136] + xx[198] * xx[17] + xx[101] * xx[130];
  xx[266] = xx[33];
  xx[267] = xx[45];
  xx[268] = - xx[186];
  xx[269] = - (xx[96] * xx[15] + xx[58] * xx[19]);
  xx[270] = xx[96] * xx[129] - xx[58] * xx[128];
  xx[271] = - (xx[58] * xx[17] + xx[96] * xx[136]);
  xx[272] = xx[0] * xx[180] - xx[1] * xx[182];
  xx[273] = - (xx[0] * xx[182] + xx[1] * xx[180]);
  xx[274] = xx[97];
  xx[275] = xx[121];
  xx[276] = xx[23];
  xx[277] = xx[4];
  xx[278] = xx[183];
  xx[279] = xx[248];
  xx[280] = - xx[119];
  xx[281] = xx[63];
  xx[282] = xx[24];
  xx[283] = xx[21];
  xx[284] = xx[202];
  xx[285] = xx[255];
  xx[286] = xx[111];
  xx[287] = xx[29];
  xx[288] = xx[12];
  xx[289] = xx[126];
  xx[290] = xx[242];
  xx[291] = xx[256];
  xx[292] = xx[125];
  solveSymmetricPosDef(xx + 310, xx + 257, 6, 6, xx + 42, xx + 0);
  xx[0] = xx[60];
  xx[1] = xx[66];
  xx[2] = xx[72];
  xx[3] = 9.806649999999999;
  xx[4] = xx[11] * xx[3];
  xx[5] = xx[22] * xx[3];
  xx[15] = (xx[4] * xx[20] + xx[5] * xx[13]) * xx[6];
  xx[16] = xx[6] * (xx[5] * xx[20] - xx[4] * xx[13]);
  xx[17] = xx[3] - (xx[22] * xx[5] + xx[11] * xx[4]) * xx[6];
  xx[11] = xx[61];
  xx[12] = xx[67];
  xx[13] = xx[73];
  xx[18] = xx[62];
  xx[19] = xx[68];
  xx[20] = xx[74];
  xx[21] = xx[63];
  xx[22] = xx[69];
  xx[23] = xx[75];
  xx[24] = xx[64];
  xx[25] = xx[70];
  xx[26] = xx[76];
  xx[27] = xx[65];
  xx[28] = xx[71];
  xx[29] = xx[77];
  xx[30] = state[16];
  xx[31] = state[17];
  xx[32] = state[18];
  xx[33] = state[19];
  xx[42] = state[23];
  xx[43] = state[24];
  xx[44] = state[25];
  pm_math_Quaternion_compDeriv_ra(xx + 30, xx + 42, xx + 45);
  xx[4] = state[18] * state[18];
  xx[5] = state[19] * state[19];
  xx[30] = xx[14] - (xx[4] + xx[5]) * xx[6];
  xx[31] = state[17] * state[18];
  xx[32] = state[16] * state[19];
  xx[33] = xx[6] * (xx[31] - xx[32]);
  xx[34] = state[16] * state[18];
  xx[35] = state[17] * state[19];
  xx[49] = (xx[34] + xx[35]) * xx[6];
  xx[50] = xx[30];
  xx[51] = xx[33];
  xx[52] = xx[49];
  xx[53] = 4.188790204786391e-3;
  xx[54] = xx[53] * xx[30];
  xx[30] = xx[53] * xx[33];
  xx[33] = xx[53] * xx[49];
  xx[55] = xx[54];
  xx[56] = xx[30];
  xx[57] = xx[33];
  xx[49] = (xx[32] + xx[31]) * xx[6];
  xx[31] = xx[53] * xx[49];
  xx[32] = state[17] * state[17];
  xx[58] = xx[14] - (xx[5] + xx[32]) * xx[6];
  xx[5] = xx[53] * xx[58];
  xx[59] = state[18] * state[19];
  xx[60] = state[16] * state[17];
  xx[61] = xx[6] * (xx[59] - xx[60]);
  xx[62] = xx[53] * xx[61];
  xx[63] = xx[31];
  xx[64] = xx[5];
  xx[65] = xx[62];
  xx[66] = pm_math_Vector3_dot_ra(xx + 50, xx + 63);
  xx[67] = xx[6] * (xx[35] - xx[34]);
  xx[34] = xx[53] * xx[67];
  xx[35] = (xx[60] + xx[59]) * xx[6];
  xx[59] = xx[53] * xx[35];
  xx[60] = xx[14] - (xx[32] + xx[4]) * xx[6];
  xx[4] = xx[53] * xx[60];
  xx[68] = xx[34];
  xx[69] = xx[59];
  xx[70] = xx[4];
  xx[32] = pm_math_Vector3_dot_ra(xx + 50, xx + 68);
  xx[71] = xx[49];
  xx[72] = xx[58];
  xx[73] = xx[61];
  xx[49] = pm_math_Vector3_dot_ra(xx + 71, xx + 68);
  xx[74] = xx[67];
  xx[75] = xx[35];
  xx[76] = xx[60];
  xx[35] = 1.675516081914556e-7;
  xx[77] = pm_math_Vector3_dot_ra(xx + 50, xx + 55);
  xx[78] = xx[66];
  xx[79] = xx[32];
  xx[80] = xx[125];
  xx[81] = xx[125];
  xx[82] = xx[125];
  xx[83] = xx[66];
  xx[84] = pm_math_Vector3_dot_ra(xx + 71, xx + 63);
  xx[85] = xx[49];
  xx[86] = xx[125];
  xx[87] = xx[125];
  xx[88] = xx[125];
  xx[89] = xx[32];
  xx[90] = xx[49];
  xx[91] = pm_math_Vector3_dot_ra(xx + 74, xx + 68);
  xx[92] = xx[125];
  xx[93] = xx[125];
  xx[94] = xx[125];
  xx[95] = xx[125];
  xx[96] = xx[125];
  xx[97] = xx[125];
  xx[98] = xx[35];
  xx[99] = xx[125];
  xx[100] = xx[125];
  xx[101] = xx[125];
  xx[102] = xx[125];
  xx[103] = xx[125];
  xx[104] = xx[125];
  xx[105] = xx[35];
  xx[106] = xx[125];
  xx[107] = xx[125];
  xx[108] = xx[125];
  xx[109] = xx[125];
  xx[110] = xx[125];
  xx[111] = xx[125];
  xx[112] = xx[35];
  ii[0] = factorSymmetricPosDef(xx + 77, 6, xx + 63);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassImplicit6Dof",
      "An implicit 6-DOF joint is attached to a degenerate mass distribution.",
      neDiagMgr);
  }

  xx[32] = - state[16];
  xx[49] = - state[17];
  xx[55] = - state[18];
  xx[56] = - state[19];
  xx[63] = xx[32];
  xx[64] = xx[49];
  xx[65] = xx[55];
  xx[66] = xx[56];
  xx[67] = state[20];
  xx[68] = state[21];
  xx[69] = state[22];
  pm_math_Quaternion_inverseXform_ra(xx + 63, xx + 67, xx + 113);
  pm_math_Vector3_cross_ra(xx + 42, xx + 113, xx + 63);
  xx[66] = - xx[113];
  xx[67] = - xx[114];
  xx[68] = - xx[115];
  pm_math_Vector3_cross_ra(xx + 42, xx + 66, xx + 116);
  xx[126] = xx[32];
  xx[127] = xx[49];
  xx[128] = xx[55];
  xx[129] = xx[56];
  xx[130] = state[13];
  xx[131] = state[14];
  xx[132] = state[15];
  bb[0] = sm_core_compiler_computeProximityInfoPlaneSphere(
    modeloMK4_funcional_4ef989e3_1_geometry_1(NULL),
    modeloMK4_funcional_4ef989e3_1_geometry_2(NULL), (pm_math_Transform3 *)(xx +
    346), (pm_math_Transform3 *)(xx + 126), xx + 32, (pm_math_Vector3 *)(xx + 55),
    (pm_math_Vector3 *)(xx + 66), (pm_math_Vector3 *)(xx + 119),
    (pm_math_Vector3 *)(xx + 122));
  xx[143] = xx[14];
  xx[144] = xx[125];
  xx[145] = xx[125];
  xx[146] = xx[125];
  xx[147] = xx[125];
  xx[148] = xx[125];
  xx[149] = xx[125];
  xx[136] = state[23];
  xx[137] = state[24];
  xx[138] = state[25];
  xx[139] = xx[113];
  xx[140] = xx[114];
  xx[141] = xx[115];
  sm_core_compiler_computeSpatialContactWrenches(
    0, 1, bb[0], xx + 32, (const pm_math_Vector3 *)(xx + 55), (const
    pm_math_Vector3 *)(xx + 66), (const pm_math_Vector3 *)(xx + 119), (const
    pm_math_Vector3 *)(xx + 122),
    (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)(xx +
    143), (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)
    (xx + 126), NULL, (const pm_math_SpatialVector *)(xx + 136),
    0, 1, xx[135], xx[142], xx[218], xx[226], xx[228], xx[237], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 150));
  xx[55] = (xx[63] + xx[116]) * xx[53] - xx[153];
  xx[56] = (xx[64] + xx[117]) * xx[53] - xx[154];
  xx[57] = (xx[65] + xx[118]) * xx[53] - xx[155];
  xx[63] = xx[35] * state[23];
  xx[64] = xx[35] * state[24];
  xx[65] = xx[35] * state[25];
  pm_math_Vector3_cross_ra(xx + 42, xx + 63, xx + 66);
  xx[113] = - pm_math_Vector3_dot_ra(xx + 50, xx + 55);
  xx[114] = - pm_math_Vector3_dot_ra(xx + 71, xx + 55);
  xx[115] = - pm_math_Vector3_dot_ra(xx + 74, xx + 55);
  xx[116] = xx[150] - xx[66];
  xx[117] = xx[151] - xx[67];
  xx[118] = xx[152] - xx[68];
  solveSymmetricPosDef(xx + 77, xx + 113, 6, 1, xx + 63, xx + 69);
  xx[150] = xx[125];
  xx[151] = xx[125];
  xx[152] = xx[125];
  xx[153] = xx[35];
  xx[154] = xx[125];
  xx[155] = xx[125];
  xx[156] = xx[125];
  xx[157] = xx[125];
  xx[158] = xx[125];
  xx[159] = xx[125];
  xx[160] = xx[35];
  xx[161] = xx[125];
  xx[162] = xx[125];
  xx[163] = xx[125];
  xx[164] = xx[125];
  xx[165] = xx[125];
  xx[166] = xx[125];
  xx[167] = xx[35];
  xx[168] = xx[54];
  xx[169] = xx[31];
  xx[170] = xx[34];
  xx[171] = xx[125];
  xx[172] = xx[125];
  xx[173] = xx[125];
  xx[174] = xx[30];
  xx[175] = xx[5];
  xx[176] = xx[59];
  xx[177] = xx[125];
  xx[178] = xx[125];
  xx[179] = xx[125];
  xx[180] = xx[33];
  xx[181] = xx[62];
  xx[182] = xx[4];
  xx[183] = xx[125];
  xx[184] = xx[125];
  xx[185] = xx[125];
  solveSymmetricPosDef(xx + 77, xx + 150, 6, 6, xx + 238, xx + 54);
  xx[30] = xx[256];
  xx[31] = xx[262];
  xx[32] = xx[268];
  xx[4] = xx[3] * state[17];
  xx[5] = xx[3] * state[18];
  xx[42] = xx[6] * (xx[4] * state[19] - xx[5] * state[16]);
  xx[43] = (xx[4] * state[16] + xx[5] * state[19]) * xx[6];
  xx[44] = xx[3] - (xx[4] * state[17] + xx[5] * state[18]) * xx[6];
  xx[49] = xx[257];
  xx[50] = xx[263];
  xx[51] = xx[269];
  xx[54] = xx[258];
  xx[55] = xx[264];
  xx[56] = xx[270];
  xx[57] = xx[259];
  xx[58] = xx[265];
  xx[59] = xx[271];
  xx[60] = xx[260];
  xx[61] = xx[266];
  xx[62] = xx[272];
  xx[69] = xx[261];
  xx[70] = xx[267];
  xx[71] = xx[273];
  xx[72] = state[29];
  xx[73] = state[30];
  xx[74] = state[31];
  xx[75] = state[32];
  xx[76] = state[36];
  xx[77] = state[37];
  xx[78] = state[38];
  pm_math_Quaternion_compDeriv_ra(xx + 72, xx + 76, xx + 79);
  xx[4] = state[31] * state[31];
  xx[5] = state[32] * state[32];
  xx[33] = xx[14] - (xx[4] + xx[5]) * xx[6];
  xx[34] = state[30] * state[31];
  xx[52] = state[29] * state[32];
  xx[72] = xx[6] * (xx[34] - xx[52]);
  xx[73] = state[29] * state[31];
  xx[74] = state[30] * state[32];
  xx[75] = (xx[73] + xx[74]) * xx[6];
  xx[83] = xx[33];
  xx[84] = xx[72];
  xx[85] = xx[75];
  xx[86] = xx[53] * xx[33];
  xx[33] = xx[53] * xx[72];
  xx[72] = xx[53] * xx[75];
  xx[87] = xx[86];
  xx[88] = xx[33];
  xx[89] = xx[72];
  xx[75] = (xx[52] + xx[34]) * xx[6];
  xx[34] = xx[53] * xx[75];
  xx[52] = state[30] * state[30];
  xx[90] = xx[14] - (xx[5] + xx[52]) * xx[6];
  xx[5] = xx[53] * xx[90];
  xx[91] = state[31] * state[32];
  xx[92] = state[29] * state[30];
  xx[93] = xx[6] * (xx[91] - xx[92]);
  xx[94] = xx[53] * xx[93];
  xx[95] = xx[34];
  xx[96] = xx[5];
  xx[97] = xx[94];
  xx[98] = pm_math_Vector3_dot_ra(xx + 83, xx + 95);
  xx[99] = xx[6] * (xx[74] - xx[73]);
  xx[73] = xx[53] * xx[99];
  xx[74] = (xx[92] + xx[91]) * xx[6];
  xx[91] = xx[53] * xx[74];
  xx[92] = xx[14] - (xx[52] + xx[4]) * xx[6];
  xx[4] = xx[53] * xx[92];
  xx[100] = xx[73];
  xx[101] = xx[91];
  xx[102] = xx[4];
  xx[52] = pm_math_Vector3_dot_ra(xx + 83, xx + 100);
  xx[103] = xx[75];
  xx[104] = xx[90];
  xx[105] = xx[93];
  xx[75] = pm_math_Vector3_dot_ra(xx + 103, xx + 100);
  xx[106] = xx[99];
  xx[107] = xx[74];
  xx[108] = xx[92];
  xx[150] = pm_math_Vector3_dot_ra(xx + 83, xx + 87);
  xx[151] = xx[98];
  xx[152] = xx[52];
  xx[153] = xx[125];
  xx[154] = xx[125];
  xx[155] = xx[125];
  xx[156] = xx[98];
  xx[157] = pm_math_Vector3_dot_ra(xx + 103, xx + 95);
  xx[158] = xx[75];
  xx[159] = xx[125];
  xx[160] = xx[125];
  xx[161] = xx[125];
  xx[162] = xx[52];
  xx[163] = xx[75];
  xx[164] = pm_math_Vector3_dot_ra(xx + 106, xx + 100);
  xx[165] = xx[125];
  xx[166] = xx[125];
  xx[167] = xx[125];
  xx[168] = xx[125];
  xx[169] = xx[125];
  xx[170] = xx[125];
  xx[171] = xx[35];
  xx[172] = xx[125];
  xx[173] = xx[125];
  xx[174] = xx[125];
  xx[175] = xx[125];
  xx[176] = xx[125];
  xx[177] = xx[125];
  xx[178] = xx[35];
  xx[179] = xx[125];
  xx[180] = xx[125];
  xx[181] = xx[125];
  xx[182] = xx[125];
  xx[183] = xx[125];
  xx[184] = xx[125];
  xx[185] = xx[35];
  ii[0] = factorSymmetricPosDef(xx + 150, 6, xx + 95);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassImplicit6Dof",
      "An implicit 6-DOF joint is attached to a degenerate mass distribution.",
      neDiagMgr);
  }

  xx[52] = - state[29];
  xx[74] = - state[30];
  xx[75] = - state[31];
  xx[87] = - state[32];
  xx[95] = xx[52];
  xx[96] = xx[74];
  xx[97] = xx[75];
  xx[98] = xx[87];
  xx[88] = state[33];
  xx[89] = state[34];
  xx[90] = state[35];
  pm_math_Quaternion_inverseXform_ra(xx + 95, xx + 88, xx + 99);
  pm_math_Vector3_cross_ra(xx + 76, xx + 99, xx + 88);
  xx[95] = - xx[99];
  xx[96] = - xx[100];
  xx[97] = - xx[101];
  pm_math_Vector3_cross_ra(xx + 76, xx + 95, xx + 109);
  xx[112] = xx[52];
  xx[113] = xx[74];
  xx[114] = xx[75];
  xx[115] = xx[87];
  xx[116] = state[26];
  xx[117] = state[27];
  xx[118] = state[28];
  bb[0] = sm_core_compiler_computeProximityInfoPlaneSphere(
    modeloMK4_funcional_4ef989e3_1_geometry_1(NULL),
    modeloMK4_funcional_4ef989e3_1_geometry_2(NULL), (pm_math_Transform3 *)(xx +
    346), (pm_math_Transform3 *)(xx + 112), xx + 52, (pm_math_Vector3 *)(xx + 95),
    (pm_math_Vector3 *)(xx + 119), (pm_math_Vector3 *)(xx + 122),
    (pm_math_Vector3 *)(xx + 126));
  xx[129] = state[36];
  xx[130] = state[37];
  xx[131] = state[38];
  xx[132] = xx[99];
  xx[133] = xx[100];
  xx[134] = xx[101];
  sm_core_compiler_computeSpatialContactWrenches(
    0, 1, bb[0], xx + 52, (const pm_math_Vector3 *)(xx + 95), (const
    pm_math_Vector3 *)(xx + 119), (const pm_math_Vector3 *)(xx + 122), (const
    pm_math_Vector3 *)(xx + 126),
    (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)(xx +
    143), (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)
    (xx + 112), NULL, (const pm_math_SpatialVector *)(xx + 129),
    0, 1, xx[135], xx[142], xx[218], xx[226], xx[228], xx[237], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 136));
  xx[95] = (xx[88] + xx[109]) * xx[53] - xx[139];
  xx[96] = (xx[89] + xx[110]) * xx[53] - xx[140];
  xx[97] = (xx[90] + xx[111]) * xx[53] - xx[141];
  xx[87] = xx[35] * state[36];
  xx[88] = xx[35] * state[37];
  xx[89] = xx[35] * state[38];
  pm_math_Vector3_cross_ra(xx + 76, xx + 87, xx + 98);
  xx[109] = - pm_math_Vector3_dot_ra(xx + 83, xx + 95);
  xx[110] = - pm_math_Vector3_dot_ra(xx + 103, xx + 95);
  xx[111] = - pm_math_Vector3_dot_ra(xx + 106, xx + 95);
  xx[112] = xx[136] - xx[98];
  xx[113] = xx[137] - xx[99];
  xx[114] = xx[138] - xx[100];
  solveSymmetricPosDef(xx + 150, xx + 109, 6, 1, xx + 95, xx + 101);
  xx[238] = xx[125];
  xx[239] = xx[125];
  xx[240] = xx[125];
  xx[241] = xx[35];
  xx[242] = xx[125];
  xx[243] = xx[125];
  xx[244] = xx[125];
  xx[245] = xx[125];
  xx[246] = xx[125];
  xx[247] = xx[125];
  xx[248] = xx[35];
  xx[249] = xx[125];
  xx[250] = xx[125];
  xx[251] = xx[125];
  xx[252] = xx[125];
  xx[253] = xx[125];
  xx[254] = xx[125];
  xx[255] = xx[35];
  xx[256] = xx[86];
  xx[257] = xx[34];
  xx[258] = xx[73];
  xx[259] = xx[125];
  xx[260] = xx[125];
  xx[261] = xx[125];
  xx[262] = xx[33];
  xx[263] = xx[5];
  xx[264] = xx[91];
  xx[265] = xx[125];
  xx[266] = xx[125];
  xx[267] = xx[125];
  xx[268] = xx[72];
  xx[269] = xx[94];
  xx[270] = xx[4];
  xx[271] = xx[125];
  xx[272] = xx[125];
  xx[273] = xx[125];
  solveSymmetricPosDef(xx + 150, xx + 238, 6, 6, xx + 274, xx + 72);
  xx[72] = xx[292];
  xx[73] = xx[298];
  xx[74] = xx[304];
  xx[4] = xx[3] * state[30];
  xx[5] = xx[3] * state[31];
  xx[75] = xx[6] * (xx[4] * state[32] - xx[5] * state[29]);
  xx[76] = (xx[4] * state[29] + xx[5] * state[32]) * xx[6];
  xx[77] = xx[3] - (xx[4] * state[30] + xx[5] * state[31]) * xx[6];
  xx[83] = xx[293];
  xx[84] = xx[299];
  xx[85] = xx[305];
  xx[86] = xx[294];
  xx[87] = xx[300];
  xx[88] = xx[306];
  xx[89] = xx[295];
  xx[90] = xx[301];
  xx[91] = xx[307];
  xx[92] = xx[296];
  xx[93] = xx[302];
  xx[94] = xx[308];
  xx[101] = xx[297];
  xx[102] = xx[303];
  xx[103] = xx[309];
  xx[104] = state[42];
  xx[105] = state[43];
  xx[106] = state[44];
  xx[107] = state[45];
  xx[108] = state[49];
  xx[109] = state[50];
  xx[110] = state[51];
  pm_math_Quaternion_compDeriv_ra(xx + 104, xx + 108, xx + 111);
  xx[4] = state[44] * state[44];
  xx[5] = state[45] * state[45];
  xx[33] = xx[14] - (xx[4] + xx[5]) * xx[6];
  xx[34] = state[43] * state[44];
  xx[52] = state[42] * state[45];
  xx[78] = xx[6] * (xx[34] - xx[52]);
  xx[104] = state[42] * state[44];
  xx[105] = state[43] * state[45];
  xx[106] = (xx[104] + xx[105]) * xx[6];
  xx[115] = xx[33];
  xx[116] = xx[78];
  xx[117] = xx[106];
  xx[107] = xx[53] * xx[33];
  xx[33] = xx[53] * xx[78];
  xx[78] = xx[53] * xx[106];
  xx[118] = xx[107];
  xx[119] = xx[33];
  xx[120] = xx[78];
  xx[106] = (xx[52] + xx[34]) * xx[6];
  xx[34] = xx[53] * xx[106];
  xx[52] = state[43] * state[43];
  xx[121] = xx[14] - (xx[5] + xx[52]) * xx[6];
  xx[5] = xx[53] * xx[121];
  xx[122] = state[44] * state[45];
  xx[123] = state[42] * state[43];
  xx[124] = xx[6] * (xx[122] - xx[123]);
  xx[126] = xx[53] * xx[124];
  xx[127] = xx[34];
  xx[128] = xx[5];
  xx[129] = xx[126];
  xx[130] = pm_math_Vector3_dot_ra(xx + 115, xx + 127);
  xx[131] = xx[6] * (xx[105] - xx[104]);
  xx[104] = xx[53] * xx[131];
  xx[105] = (xx[123] + xx[122]) * xx[6];
  xx[122] = xx[53] * xx[105];
  xx[123] = xx[14] - (xx[52] + xx[4]) * xx[6];
  xx[4] = xx[53] * xx[123];
  xx[132] = xx[104];
  xx[133] = xx[122];
  xx[134] = xx[4];
  xx[52] = pm_math_Vector3_dot_ra(xx + 115, xx + 132);
  xx[136] = xx[106];
  xx[137] = xx[121];
  xx[138] = xx[124];
  xx[106] = pm_math_Vector3_dot_ra(xx + 136, xx + 132);
  xx[139] = xx[131];
  xx[140] = xx[105];
  xx[141] = xx[123];
  xx[150] = pm_math_Vector3_dot_ra(xx + 115, xx + 118);
  xx[151] = xx[130];
  xx[152] = xx[52];
  xx[153] = xx[125];
  xx[154] = xx[125];
  xx[155] = xx[125];
  xx[156] = xx[130];
  xx[157] = pm_math_Vector3_dot_ra(xx + 136, xx + 127);
  xx[158] = xx[106];
  xx[159] = xx[125];
  xx[160] = xx[125];
  xx[161] = xx[125];
  xx[162] = xx[52];
  xx[163] = xx[106];
  xx[164] = pm_math_Vector3_dot_ra(xx + 139, xx + 132);
  xx[165] = xx[125];
  xx[166] = xx[125];
  xx[167] = xx[125];
  xx[168] = xx[125];
  xx[169] = xx[125];
  xx[170] = xx[125];
  xx[171] = xx[35];
  xx[172] = xx[125];
  xx[173] = xx[125];
  xx[174] = xx[125];
  xx[175] = xx[125];
  xx[176] = xx[125];
  xx[177] = xx[125];
  xx[178] = xx[35];
  xx[179] = xx[125];
  xx[180] = xx[125];
  xx[181] = xx[125];
  xx[182] = xx[125];
  xx[183] = xx[125];
  xx[184] = xx[125];
  xx[185] = xx[35];
  ii[0] = factorSymmetricPosDef(xx + 150, 6, xx + 127);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassImplicit6Dof",
      "An implicit 6-DOF joint is attached to a degenerate mass distribution.",
      neDiagMgr);
  }

  xx[52] = - state[42];
  xx[105] = - state[43];
  xx[106] = - state[44];
  xx[118] = - state[45];
  xx[127] = xx[52];
  xx[128] = xx[105];
  xx[129] = xx[106];
  xx[130] = xx[118];
  xx[119] = state[46];
  xx[120] = state[47];
  xx[121] = state[48];
  pm_math_Quaternion_inverseXform_ra(xx + 127, xx + 119, xx + 131);
  pm_math_Vector3_cross_ra(xx + 108, xx + 131, xx + 119);
  xx[127] = - xx[131];
  xx[128] = - xx[132];
  xx[129] = - xx[133];
  pm_math_Vector3_cross_ra(xx + 108, xx + 127, xx + 186);
  xx[189] = xx[52];
  xx[190] = xx[105];
  xx[191] = xx[106];
  xx[192] = xx[118];
  xx[193] = state[39];
  xx[194] = state[40];
  xx[195] = state[41];
  bb[0] = sm_core_compiler_computeProximityInfoPlaneSphere(
    modeloMK4_funcional_4ef989e3_1_geometry_1(NULL),
    modeloMK4_funcional_4ef989e3_1_geometry_2(NULL), (pm_math_Transform3 *)(xx +
    346), (pm_math_Transform3 *)(xx + 189), xx + 52, (pm_math_Vector3 *)(xx +
    127), (pm_math_Vector3 *)(xx + 196), (pm_math_Vector3 *)(xx + 199),
    (pm_math_Vector3 *)(xx + 202));
  xx[205] = state[49];
  xx[206] = state[50];
  xx[207] = state[51];
  xx[208] = xx[131];
  xx[209] = xx[132];
  xx[210] = xx[133];
  sm_core_compiler_computeSpatialContactWrenches(
    0, 1, bb[0], xx + 52, (const pm_math_Vector3 *)(xx + 127), (const
    pm_math_Vector3 *)(xx + 196), (const pm_math_Vector3 *)(xx + 199), (const
    pm_math_Vector3 *)(xx + 202),
    (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)(xx +
    143), (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)
    (xx + 189), NULL, (const pm_math_SpatialVector *)(xx + 205),
    0, 1, xx[135], xx[142], xx[218], xx[226], xx[228], xx[237], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 211));
  xx[127] = (xx[119] + xx[186]) * xx[53] - xx[214];
  xx[128] = (xx[120] + xx[187]) * xx[53] - xx[215];
  xx[129] = (xx[121] + xx[188]) * xx[53] - xx[216];
  xx[118] = xx[35] * state[49];
  xx[119] = xx[35] * state[50];
  xx[120] = xx[35] * state[51];
  pm_math_Vector3_cross_ra(xx + 108, xx + 118, xx + 130);
  xx[186] = - pm_math_Vector3_dot_ra(xx + 115, xx + 127);
  xx[187] = - pm_math_Vector3_dot_ra(xx + 136, xx + 127);
  xx[188] = - pm_math_Vector3_dot_ra(xx + 139, xx + 127);
  xx[189] = xx[211] - xx[130];
  xx[190] = xx[212] - xx[131];
  xx[191] = xx[213] - xx[132];
  solveSymmetricPosDef(xx + 150, xx + 186, 6, 1, xx + 115, xx + 127);
  xx[238] = xx[125];
  xx[239] = xx[125];
  xx[240] = xx[125];
  xx[241] = xx[35];
  xx[242] = xx[125];
  xx[243] = xx[125];
  xx[244] = xx[125];
  xx[245] = xx[125];
  xx[246] = xx[125];
  xx[247] = xx[125];
  xx[248] = xx[35];
  xx[249] = xx[125];
  xx[250] = xx[125];
  xx[251] = xx[125];
  xx[252] = xx[125];
  xx[253] = xx[125];
  xx[254] = xx[125];
  xx[255] = xx[35];
  xx[256] = xx[107];
  xx[257] = xx[34];
  xx[258] = xx[104];
  xx[259] = xx[125];
  xx[260] = xx[125];
  xx[261] = xx[125];
  xx[262] = xx[33];
  xx[263] = xx[5];
  xx[264] = xx[122];
  xx[265] = xx[125];
  xx[266] = xx[125];
  xx[267] = xx[125];
  xx[268] = xx[78];
  xx[269] = xx[126];
  xx[270] = xx[4];
  xx[271] = xx[125];
  xx[272] = xx[125];
  xx[273] = xx[125];
  solveSymmetricPosDef(xx + 150, xx + 238, 6, 6, xx + 274, xx + 104);
  xx[104] = xx[292];
  xx[105] = xx[298];
  xx[106] = xx[304];
  xx[4] = xx[3] * state[43];
  xx[5] = xx[3] * state[44];
  xx[107] = xx[6] * (xx[4] * state[45] - xx[5] * state[42]);
  xx[108] = (xx[4] * state[42] + xx[5] * state[45]) * xx[6];
  xx[109] = xx[3] - (xx[4] * state[43] + xx[5] * state[44]) * xx[6];
  xx[121] = xx[293];
  xx[122] = xx[299];
  xx[123] = xx[305];
  xx[126] = xx[294];
  xx[127] = xx[300];
  xx[128] = xx[306];
  xx[129] = xx[295];
  xx[130] = xx[301];
  xx[131] = xx[307];
  xx[132] = xx[296];
  xx[133] = xx[302];
  xx[134] = xx[308];
  xx[136] = xx[297];
  xx[137] = xx[303];
  xx[138] = xx[309];
  xx[150] = state[55];
  xx[151] = state[56];
  xx[152] = state[57];
  xx[153] = state[58];
  xx[139] = state[62];
  xx[140] = state[63];
  xx[141] = state[64];
  pm_math_Quaternion_compDeriv_ra(xx + 150, xx + 139, xx + 154);
  xx[4] = state[57] * state[57];
  xx[5] = state[58] * state[58];
  xx[33] = xx[14] - (xx[4] + xx[5]) * xx[6];
  xx[34] = state[56] * state[57];
  xx[52] = state[55] * state[58];
  xx[78] = xx[6] * (xx[34] - xx[52]);
  xx[110] = state[55] * state[57];
  xx[124] = state[56] * state[58];
  xx[150] = (xx[110] + xx[124]) * xx[6];
  xx[151] = xx[33];
  xx[152] = xx[78];
  xx[153] = xx[150];
  xx[158] = xx[53] * xx[33];
  xx[33] = xx[53] * xx[78];
  xx[78] = xx[53] * xx[150];
  xx[159] = xx[158];
  xx[160] = xx[33];
  xx[161] = xx[78];
  xx[150] = (xx[52] + xx[34]) * xx[6];
  xx[34] = xx[53] * xx[150];
  xx[52] = state[56] * state[56];
  xx[162] = xx[14] - (xx[5] + xx[52]) * xx[6];
  xx[5] = xx[53] * xx[162];
  xx[163] = state[57] * state[58];
  xx[164] = state[55] * state[56];
  xx[165] = xx[6] * (xx[163] - xx[164]);
  xx[166] = xx[53] * xx[165];
  xx[167] = xx[34];
  xx[168] = xx[5];
  xx[169] = xx[166];
  xx[170] = pm_math_Vector3_dot_ra(xx + 151, xx + 167);
  xx[171] = xx[6] * (xx[124] - xx[110]);
  xx[110] = xx[53] * xx[171];
  xx[124] = (xx[164] + xx[163]) * xx[6];
  xx[163] = xx[53] * xx[124];
  xx[164] = xx[14] - (xx[52] + xx[4]) * xx[6];
  xx[4] = xx[53] * xx[164];
  xx[172] = xx[110];
  xx[173] = xx[163];
  xx[174] = xx[4];
  xx[14] = pm_math_Vector3_dot_ra(xx + 151, xx + 172);
  xx[175] = xx[150];
  xx[176] = xx[162];
  xx[177] = xx[165];
  xx[52] = pm_math_Vector3_dot_ra(xx + 175, xx + 172);
  xx[178] = xx[171];
  xx[179] = xx[124];
  xx[180] = xx[164];
  xx[181] = pm_math_Vector3_dot_ra(xx + 151, xx + 159);
  xx[182] = xx[170];
  xx[183] = xx[14];
  xx[184] = xx[125];
  xx[185] = xx[125];
  xx[186] = xx[125];
  xx[187] = xx[170];
  xx[188] = pm_math_Vector3_dot_ra(xx + 175, xx + 167);
  xx[189] = xx[52];
  xx[190] = xx[125];
  xx[191] = xx[125];
  xx[192] = xx[125];
  xx[193] = xx[14];
  xx[194] = xx[52];
  xx[195] = pm_math_Vector3_dot_ra(xx + 178, xx + 172);
  xx[196] = xx[125];
  xx[197] = xx[125];
  xx[198] = xx[125];
  xx[199] = xx[125];
  xx[200] = xx[125];
  xx[201] = xx[125];
  xx[202] = xx[35];
  xx[203] = xx[125];
  xx[204] = xx[125];
  xx[205] = xx[125];
  xx[206] = xx[125];
  xx[207] = xx[125];
  xx[208] = xx[125];
  xx[209] = xx[35];
  xx[210] = xx[125];
  xx[211] = xx[125];
  xx[212] = xx[125];
  xx[213] = xx[125];
  xx[214] = xx[125];
  xx[215] = xx[125];
  xx[216] = xx[35];
  ii[0] = factorSymmetricPosDef(xx + 181, 6, xx + 167);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassImplicit6Dof",
      "An implicit 6-DOF joint is attached to a degenerate mass distribution.",
      neDiagMgr);
  }

  xx[14] = - state[55];
  xx[52] = - state[56];
  xx[124] = - state[57];
  xx[150] = - state[58];
  xx[159] = xx[14];
  xx[160] = xx[52];
  xx[161] = xx[124];
  xx[162] = xx[150];
  xx[167] = state[59];
  xx[168] = state[60];
  xx[169] = state[61];
  pm_math_Quaternion_inverseXform_ra(xx + 159, xx + 167, xx + 170);
  pm_math_Vector3_cross_ra(xx + 139, xx + 170, xx + 159);
  xx[167] = - xx[170];
  xx[168] = - xx[171];
  xx[169] = - xx[172];
  pm_math_Vector3_cross_ra(xx + 139, xx + 167, xx + 219);
  xx[229] = xx[14];
  xx[230] = xx[52];
  xx[231] = xx[124];
  xx[232] = xx[150];
  xx[233] = state[52];
  xx[234] = state[53];
  xx[235] = state[54];
  bb[0] = sm_core_compiler_computeProximityInfoPlaneSphere(
    modeloMK4_funcional_4ef989e3_1_geometry_1(NULL),
    modeloMK4_funcional_4ef989e3_1_geometry_2(NULL), (pm_math_Transform3 *)(xx +
    346), (pm_math_Transform3 *)(xx + 229), xx + 14, (pm_math_Vector3 *)(xx +
    167), (pm_math_Vector3 *)(xx + 222), (pm_math_Vector3 *)(xx + 238),
    (pm_math_Vector3 *)(xx + 241));
  xx[244] = state[62];
  xx[245] = state[63];
  xx[246] = state[64];
  xx[247] = xx[170];
  xx[248] = xx[171];
  xx[249] = xx[172];
  sm_core_compiler_computeSpatialContactWrenches(
    0, 1, bb[0], xx + 14, (const pm_math_Vector3 *)(xx + 167), (const
    pm_math_Vector3 *)(xx + 222), (const pm_math_Vector3 *)(xx + 238), (const
    pm_math_Vector3 *)(xx + 241),
    (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)(xx +
    143), (const pm_math_Transform3 *)(xx + 346), (const pm_math_Transform3 *)
    (xx + 229), NULL, (const pm_math_SpatialVector *)(xx + 244),
    0, 1, xx[135], xx[142], xx[218], xx[226], xx[228], xx[237], NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 250));
  xx[142] = (xx[159] + xx[219]) * xx[53] - xx[253];
  xx[143] = (xx[160] + xx[220]) * xx[53] - xx[254];
  xx[144] = (xx[161] + xx[221]) * xx[53] - xx[255];
  xx[145] = xx[35] * state[62];
  xx[146] = xx[35] * state[63];
  xx[147] = xx[35] * state[64];
  pm_math_Vector3_cross_ra(xx + 139, xx + 145, xx + 148);
  xx[167] = - pm_math_Vector3_dot_ra(xx + 151, xx + 142);
  xx[168] = - pm_math_Vector3_dot_ra(xx + 175, xx + 142);
  xx[169] = - pm_math_Vector3_dot_ra(xx + 178, xx + 142);
  xx[170] = xx[250] - xx[148];
  xx[171] = xx[251] - xx[149];
  xx[172] = xx[252] - xx[150];
  solveSymmetricPosDef(xx + 181, xx + 167, 6, 1, xx + 139, xx + 145);
  xx[217] = xx[125];
  xx[218] = xx[125];
  xx[219] = xx[125];
  xx[220] = xx[35];
  xx[221] = xx[125];
  xx[222] = xx[125];
  xx[223] = xx[125];
  xx[224] = xx[125];
  xx[225] = xx[125];
  xx[226] = xx[125];
  xx[227] = xx[35];
  xx[228] = xx[125];
  xx[229] = xx[125];
  xx[230] = xx[125];
  xx[231] = xx[125];
  xx[232] = xx[125];
  xx[233] = xx[125];
  xx[234] = xx[35];
  xx[235] = xx[158];
  xx[236] = xx[34];
  xx[237] = xx[110];
  xx[238] = xx[125];
  xx[239] = xx[125];
  xx[240] = xx[125];
  xx[241] = xx[33];
  xx[242] = xx[5];
  xx[243] = xx[163];
  xx[244] = xx[125];
  xx[245] = xx[125];
  xx[246] = xx[125];
  xx[247] = xx[78];
  xx[248] = xx[166];
  xx[249] = xx[4];
  xx[250] = xx[125];
  xx[251] = xx[125];
  xx[252] = xx[125];
  solveSymmetricPosDef(xx + 181, xx + 217, 6, 6, xx + 253, xx + 145);
  xx[33] = xx[271];
  xx[34] = xx[277];
  xx[35] = xx[283];
  xx[4] = xx[3] * state[56];
  xx[5] = xx[3] * state[57];
  xx[145] = xx[6] * (xx[4] * state[58] - xx[5] * state[55]);
  xx[146] = (xx[4] * state[55] + xx[5] * state[58]) * xx[6];
  xx[147] = xx[3] - (xx[4] * state[56] + xx[5] * state[57]) * xx[6];
  xx[3] = xx[272];
  xx[4] = xx[278];
  xx[5] = xx[284];
  xx[148] = xx[273];
  xx[149] = xx[279];
  xx[150] = xx[285];
  xx[151] = xx[274];
  xx[152] = xx[280];
  xx[153] = xx[286];
  xx[158] = xx[275];
  xx[159] = xx[281];
  xx[160] = xx[287];
  xx[161] = xx[276];
  xx[162] = xx[282];
  xx[163] = xx[288];
  deriv[0] = state[7];
  deriv[1] = state[8];
  deriv[2] = state[9];
  deriv[3] = xx[7];
  deriv[4] = xx[8];
  deriv[5] = xx[9];
  deriv[6] = xx[10];
  deriv[7] = xx[36] - pm_math_Vector3_dot_ra(xx + 0, xx + 15);
  deriv[8] = xx[37] - pm_math_Vector3_dot_ra(xx + 11, xx + 15);
  deriv[9] = xx[38] - pm_math_Vector3_dot_ra(xx + 18, xx + 15);
  deriv[10] = xx[39] - pm_math_Vector3_dot_ra(xx + 21, xx + 15);
  deriv[11] = xx[40] - pm_math_Vector3_dot_ra(xx + 24, xx + 15);
  deriv[12] = xx[41] - pm_math_Vector3_dot_ra(xx + 27, xx + 15);
  deriv[13] = state[20];
  deriv[14] = state[21];
  deriv[15] = state[22];
  deriv[16] = xx[45];
  deriv[17] = xx[46];
  deriv[18] = xx[47];
  deriv[19] = xx[48];
  deriv[20] = xx[63] - pm_math_Vector3_dot_ra(xx + 30, xx + 42);
  deriv[21] = xx[64] - pm_math_Vector3_dot_ra(xx + 49, xx + 42);
  deriv[22] = xx[65] - pm_math_Vector3_dot_ra(xx + 54, xx + 42);
  deriv[23] = xx[66] - pm_math_Vector3_dot_ra(xx + 57, xx + 42);
  deriv[24] = xx[67] - pm_math_Vector3_dot_ra(xx + 60, xx + 42);
  deriv[25] = xx[68] - pm_math_Vector3_dot_ra(xx + 69, xx + 42);
  deriv[26] = state[33];
  deriv[27] = state[34];
  deriv[28] = state[35];
  deriv[29] = xx[79];
  deriv[30] = xx[80];
  deriv[31] = xx[81];
  deriv[32] = xx[82];
  deriv[33] = xx[95] - pm_math_Vector3_dot_ra(xx + 72, xx + 75);
  deriv[34] = xx[96] - pm_math_Vector3_dot_ra(xx + 83, xx + 75);
  deriv[35] = xx[97] - pm_math_Vector3_dot_ra(xx + 86, xx + 75);
  deriv[36] = xx[98] - pm_math_Vector3_dot_ra(xx + 89, xx + 75);
  deriv[37] = xx[99] - pm_math_Vector3_dot_ra(xx + 92, xx + 75);
  deriv[38] = xx[100] - pm_math_Vector3_dot_ra(xx + 101, xx + 75);
  deriv[39] = state[46];
  deriv[40] = state[47];
  deriv[41] = state[48];
  deriv[42] = xx[111];
  deriv[43] = xx[112];
  deriv[44] = xx[113];
  deriv[45] = xx[114];
  deriv[46] = xx[115] - pm_math_Vector3_dot_ra(xx + 104, xx + 107);
  deriv[47] = xx[116] - pm_math_Vector3_dot_ra(xx + 121, xx + 107);
  deriv[48] = xx[117] - pm_math_Vector3_dot_ra(xx + 126, xx + 107);
  deriv[49] = xx[118] - pm_math_Vector3_dot_ra(xx + 129, xx + 107);
  deriv[50] = xx[119] - pm_math_Vector3_dot_ra(xx + 132, xx + 107);
  deriv[51] = xx[120] - pm_math_Vector3_dot_ra(xx + 136, xx + 107);
  deriv[52] = state[59];
  deriv[53] = state[60];
  deriv[54] = state[61];
  deriv[55] = xx[154];
  deriv[56] = xx[155];
  deriv[57] = xx[156];
  deriv[58] = xx[157];
  deriv[59] = xx[139] - pm_math_Vector3_dot_ra(xx + 33, xx + 145);
  deriv[60] = xx[140] - pm_math_Vector3_dot_ra(xx + 3, xx + 145);
  deriv[61] = xx[141] - pm_math_Vector3_dot_ra(xx + 148, xx + 145);
  deriv[62] = xx[142] - pm_math_Vector3_dot_ra(xx + 151, xx + 145);
  deriv[63] = xx[143] - pm_math_Vector3_dot_ra(xx + 158, xx + 145);
  deriv[64] = xx[144] - pm_math_Vector3_dot_ra(xx + 161, xx + 145);
  errorResult[0] = xx[125];
  return NULL;
}

PmfMessageId modeloMK4_funcional_4ef989e3_1_numJacPerturbLoBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = 1.0e-9;
  xx[1] = 1.0e-8;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[1];
  bounds[4] = xx[1];
  bounds[5] = xx[1];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[0];
  bounds[9] = xx[0];
  bounds[10] = xx[1];
  bounds[11] = xx[1];
  bounds[12] = xx[1];
  bounds[13] = xx[0];
  bounds[14] = xx[0];
  bounds[15] = xx[0];
  bounds[16] = xx[1];
  bounds[17] = xx[1];
  bounds[18] = xx[1];
  bounds[19] = xx[1];
  bounds[20] = xx[0];
  bounds[21] = xx[0];
  bounds[22] = xx[0];
  bounds[23] = xx[1];
  bounds[24] = xx[1];
  bounds[25] = xx[1];
  bounds[26] = xx[0];
  bounds[27] = xx[0];
  bounds[28] = xx[0];
  bounds[29] = xx[1];
  bounds[30] = xx[1];
  bounds[31] = xx[1];
  bounds[32] = xx[1];
  bounds[33] = xx[0];
  bounds[34] = xx[0];
  bounds[35] = xx[0];
  bounds[36] = xx[1];
  bounds[37] = xx[1];
  bounds[38] = xx[1];
  bounds[39] = xx[0];
  bounds[40] = xx[0];
  bounds[41] = xx[0];
  bounds[42] = xx[1];
  bounds[43] = xx[1];
  bounds[44] = xx[1];
  bounds[45] = xx[1];
  bounds[46] = xx[0];
  bounds[47] = xx[0];
  bounds[48] = xx[0];
  bounds[49] = xx[1];
  bounds[50] = xx[1];
  bounds[51] = xx[1];
  bounds[52] = xx[0];
  bounds[53] = xx[0];
  bounds[54] = xx[0];
  bounds[55] = xx[1];
  bounds[56] = xx[1];
  bounds[57] = xx[1];
  bounds[58] = xx[1];
  bounds[59] = xx[0];
  bounds[60] = xx[0];
  bounds[61] = xx[0];
  bounds[62] = xx[1];
  bounds[63] = xx[1];
  bounds[64] = xx[1];
  errorResult[0] = 0.0;
  return NULL;
}

PmfMessageId modeloMK4_funcional_4ef989e3_1_numJacPerturbHiBounds(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, const double *discreteState, double *bounds, double
  *errorResult, NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[2];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) state;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) inputDdot;
  (void) discreteState;
  (void) neDiagMgr;
  xx[0] = +pmf_get_inf();
  xx[1] = 0.1;
  bounds[0] = xx[0];
  bounds[1] = xx[0];
  bounds[2] = xx[0];
  bounds[3] = xx[1];
  bounds[4] = xx[1];
  bounds[5] = xx[1];
  bounds[6] = xx[1];
  bounds[7] = xx[0];
  bounds[8] = xx[0];
  bounds[9] = xx[0];
  bounds[10] = xx[0];
  bounds[11] = xx[0];
  bounds[12] = xx[0];
  bounds[13] = xx[0];
  bounds[14] = xx[0];
  bounds[15] = xx[0];
  bounds[16] = xx[1];
  bounds[17] = xx[1];
  bounds[18] = xx[1];
  bounds[19] = xx[1];
  bounds[20] = xx[0];
  bounds[21] = xx[0];
  bounds[22] = xx[0];
  bounds[23] = xx[0];
  bounds[24] = xx[0];
  bounds[25] = xx[0];
  bounds[26] = xx[0];
  bounds[27] = xx[0];
  bounds[28] = xx[0];
  bounds[29] = xx[1];
  bounds[30] = xx[1];
  bounds[31] = xx[1];
  bounds[32] = xx[1];
  bounds[33] = xx[0];
  bounds[34] = xx[0];
  bounds[35] = xx[0];
  bounds[36] = xx[0];
  bounds[37] = xx[0];
  bounds[38] = xx[0];
  bounds[39] = xx[0];
  bounds[40] = xx[0];
  bounds[41] = xx[0];
  bounds[42] = xx[1];
  bounds[43] = xx[1];
  bounds[44] = xx[1];
  bounds[45] = xx[1];
  bounds[46] = xx[0];
  bounds[47] = xx[0];
  bounds[48] = xx[0];
  bounds[49] = xx[0];
  bounds[50] = xx[0];
  bounds[51] = xx[0];
  bounds[52] = xx[0];
  bounds[53] = xx[0];
  bounds[54] = xx[0];
  bounds[55] = xx[1];
  bounds[56] = xx[1];
  bounds[57] = xx[1];
  bounds[58] = xx[1];
  bounds[59] = xx[0];
  bounds[60] = xx[0];
  bounds[61] = xx[0];
  bounds[62] = xx[0];
  bounds[63] = xx[0];
  bounds[64] = xx[0];
  errorResult[0] = 0.0;
  return NULL;
}
