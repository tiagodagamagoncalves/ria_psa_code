clear all
close all
clc
%-------------------------------------------------------------------------%
% Definicao da Caixa de Dialogo:
promptdlg1 = 'algoritmo (1 - Italo / 2 - Thomas)';
defaultans1 = '1';
promptdlg2 = 'Gait (1 - Caminhar / 2 - Trotar)(Valido p/ algoritmo 1)';
defaultans2 = '1';
promptdlg3 = 'Comprimento do Passo (Valido p/ algoritmo 1)';
defaultans3 = '0.2';
promptdlg4 = 'Periodo do Ciclo (Valido p/ algoritmo 1)';
defaultans4 = '4';
promptdlg5 = 'Quantidade de Ciclos (Valido p/ algoritmo 1)';
defaultans5 = '5';
namedlg = 'Parametros de Simulacao';
promptdlg = {promptdlg1,promptdlg2,promptdlg3,...
promptdlg4,promptdlg5};
defaultans = {defaultans1, defaultans2, defaultans3,...
defaultans4, defaultans5};
answer = inputdlg(promptdlg,namedlg,1,defaultans,'on');
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% atribuicao das opcoes nas variaveis:
algor = str2double(answer{1}); % algoritmo utilizado
gait = str2double(answer{2}); % padrao de locomocao
LS = str2double(answer{3}); % comprimento do passo
T = str2double(answer{4}); % periodo de ciclo
nc = str2double(answer{5}); % numero de ciclos
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Parametros Fisicos do modelo:
body_x_ic = 0; % Posicao CG Corpo X e condicao inicial
body_y_ic = 0.26; % Posicao CG Corpo Y
body_z_ic = 0; % Posicao CG Corpo Z
n = 0.9; % Peso da mola (forca normal nao linear)
m = 0.9; % Peso do amortecedor (forca normal nao linear)
g_force = 9.81; % Forca da gravidade
sample_time = 0.003; % Sample time Thomas
sample_time_measurements = -1;
spring_body_x = 10^5; % Param. em X da mola do corpo
damper_body_x = 10^3; % Param. em X do amortecedor do corpo
spring_body_z = 10^4; % Param. em Z da mola do corpo
damper_body_z = 10^2; % Param. em Z do amortecedor do corpo
friction_spring = 1.3*10^6; % Param. de friccao da mola do solo
friction_damper = 3.4*10^3; % Param. de friccao do amortecedor do solo
normal_spring = 1.7*10^6; % Param. normal do amortecedor do solo
normal_damper = 2.7*10^6; % Param. normal da mola do solo
upper_friction_saturation = 2*10^6; % Saturacao positiva Friccao
lower_friction_saturation = -2*10^6; % Saturacao negativa Friccao
upper_normal_saturation = 4*10^6; % Saturacao positiva Normal
lower_normal_saturation = -2*10^6; % Saturacao negativa Normal
rho = 200; % Densidade da perna
rho_body = 100; % Densidade do corpo
h_legs = 0.2; % comprimento das pernas
r_legs = 0.02; % raio das pernas
h_upper_leg_1 = h_legs; % Comprimento perna 1 superior
r_upper_leg_1 = r_legs; % Raio perna 1 superior
h_lower_leg_1 = h_legs; % Comprimento perna 1 inferior
r_lower_leg_1 = r_legs; % Raio perna 1 inferior
h_upper_leg_2 = h_legs; % Comprimento perna 2 superior
r_upper_leg_2 = r_legs; % Raio perna 2 superior
h_lower_leg_2 = h_legs; % Comprimento perna 2 inferior
r_lower_leg_2 = r_legs; % Raio perna 2 inferior
h_upper_leg_3 = h_legs; % Comprimento perna 3 superior
r_upper_leg_3 = r_legs; % Raio perna 3 superior
h_lower_leg_3 = h_legs; % Comprimento perna 3 inferior
r_lower_leg_3 = r_legs; % Raio perna 3 inferior
h_upper_leg_4 = h_legs; % Comprimento perna 4 superior
r_upper_leg_4 = r_legs; % Raio perna 4 superior
h_lower_leg_4 = h_legs; % Comprimento perna 4 inferior
r_lower_leg_4 = r_legs; % Raio perna 4 inferior
h_ground = 0.01; %Altura solo Y
w_ground = 2; %Largura solo X
d_ground = 1; %Profundidade solo Z
h_body = 0.15; %Altura corpo Y
w_body = 0.3; %Largura corpo X
d_body = 0.2; %Profundidade corpo Z
% Massa perna 1:
m_upper_leg_1 = (pi*r_upper_leg_1^2*h_upper_leg_1*rho);
m_lower_leg_1 = (pi*r_lower_leg_1^2*h_lower_leg_1*rho);
% Massa perna 2:
m_upper_leg_2 = (pi*r_upper_leg_2^2*h_upper_leg_2*rho);
m_lower_leg_2 = (pi*r_lower_leg_2^2*h_lower_leg_2*rho);
% Massa perna 3:
m_upper_leg_3 = (pi*r_upper_leg_3^2*h_upper_leg_3*rho);
m_lower_leg_3 = (pi*r_lower_leg_3^2*h_lower_leg_3*rho);
% Massa perna 4:
m_upper_leg_4 = (pi*r_upper_leg_4^2*h_upper_leg_4*rho);
m_lower_leg_4 = (pi*r_lower_leg_4^2*h_lower_leg_4*rho);
m_ground = 400; % Massa do solo
m_body = rho_body*(h_body*d_body*w_body); % Massa do corpo
inertia_upper_leg_1 = ... % Inercia Sup. Perna 1
[((1/2)*m_upper_leg_1*r_upper_leg_1^2) 0 0; ...
0 (1/12)*(m_upper_leg_1*(3*r_upper_leg_1^2+h_upper_leg_1^2)) 0; ...
0 0 (1/12)*(m_upper_leg_1*(3*r_upper_leg_1^2+h_upper_leg_1^2))];
inertia_lower_leg_1 = ... % Inercia Inf. Perna 1
[((1/2)*m_lower_leg_1*r_lower_leg_1^2) 0 0; ...
0 (1/12)*(m_lower_leg_1*(3*r_lower_leg_1^2+h_lower_leg_1^2)) 0; ...
0 0 (1/12)*(m_lower_leg_1*(3*r_lower_leg_1^2+h_lower_leg_1^2))];
inertia_upper_leg_2 = ... % Inercia Sup. Perna 2
[((1/2)*m_upper_leg_2*r_upper_leg_2^2) 0 0;...
0 (1/12)*(m_upper_leg_2*(3*r_upper_leg_2^2+h_upper_leg_2^2)) 0; ...
0 0 (1/12)*(m_upper_leg_2*(3*r_upper_leg_2^2+h_upper_leg_2^2))];
inertia_lower_leg_2 = ... % Inercia Inf. Perna 2
[((1/2)*m_lower_leg_2*r_lower_leg_2^2) 0 0; ...
0 (1/12)*(m_lower_leg_2*(3*r_lower_leg_2^2+h_lower_leg_2^2)) 0; ...
0 0 (1/12)*(m_lower_leg_2*(3*r_lower_leg_2^2+h_lower_leg_2^2))];
inertia_upper_leg_3 = ... % Inercia Sup. Perna 3
[((1/2)*m_upper_leg_3*r_upper_leg_3^2) 0 0; ...
0 (1/12)*(m_upper_leg_3*(3*r_upper_leg_3^2+h_upper_leg_3^2)) 0; ...
0 0 (1/12)*(m_upper_leg_3*(3*r_upper_leg_3^2+h_upper_leg_3^2))];
inertia_lower_leg_3 = ... % Inercia Inf. Perna 3
[((1/2)*m_lower_leg_3*r_lower_leg_3^2) 0 0; ...
0 (1/12)*(m_lower_leg_3*(3*r_lower_leg_3^2+h_lower_leg_3^2)) 0; ...
0 0 (1/12)*(m_lower_leg_3*(3*r_lower_leg_3^2+h_lower_leg_3^2))];
inertia_upper_leg_4 = ... % Inercia Sup. Perna 4
[((1/2)*m_upper_leg_4*r_upper_leg_4^2) 0 0; ...
0 (1/12)*(m_upper_leg_4*(3*r_upper_leg_4^2+h_upper_leg_4^2)) 0; ...
0 0 (1/12)*(m_upper_leg_4*(3*r_upper_leg_4^2+h_upper_leg_4^2))];
inertia_lower_leg_4 = ... % Inercia Inf. Perna 4
[((1/2)*m_lower_leg_4*r_lower_leg_4^2) 0 0; ...
0 (1/12)*(m_lower_leg_4*(3*r_lower_leg_4^2+h_lower_leg_4^2)) 0; ...
0 0 (1/12)*(m_lower_leg_4*(3*r_lower_leg_4^2+h_lower_leg_4^2))];
inertia_ground = ... % Inercia Solo
[(1/12)*m_ground*(h_ground^2+d_ground^2) 0 0; ...
0 (1/12)*m_ground*(w_ground^2+d_ground^2) 0; ...
0 0 (1/12)*m_ground*(w_ground^2+h_ground^2)];
inertia_body = ... % Inercia Corpo
(1/12)*[m_body*(h_body^2+d_body^2) 0 0; ...
0 (1/12)*m_body*(w_body^2+d_body^2) 0; ...
0 0 (1/12)*m_body*(w_body^2+h_body^2)];
%-------------------------------------------------------------------------%
% Parametros dos controladores do modelo:
% Parametros das ancas
ganho_hip = 77;
zero_hip = -20.88;
polo_hip = -150;
% Parametros dos joelhos
ganho_knee = 204;
zero_knee = -20.88 ;
polo_knee = -150;
% FT do controlador das ancas
C_hip = zpk(zero_hip,polo_hip,ganho_hip);
% FT do controlador dos joelhos
C_knee = zpk(zero_knee,polo_knee,ganho_knee);
upper_torque_hip = 20; % saturacao superior ancas
lower_torque_hip = -20; % saturacao inferior ancas
upper_torque_knee = 20; % saturacao superior joelhos
lower_torque_knee = -20; % saturacao inferior joelhos
%-------------------------------------------------------------------------%
% Padroes de Locomocao:
switch algor,
%---------------------------------------------------------------------%
% Plameamento de Trajectorias:
case 1
FC = LS / pi; % altura do passo
L = h_upper_leg_1; % comprimento da perna.
switch gait,
case 1
beta = 0.75; % fracao de sustentacao
case 2
beta = 0.5; % fracao de sustentacao
end
% tempo de amostragem do sistema
sample_time = 0.005;
% tempo de amostragem das medidas
sample_time_measurements = -1;
final_time = nc*T;
t0 = 0:sample_time:T; % vetor de tempo de um periodo
t = 0:sample_time:final_time; % vetor de tempo total
TS = (beta)*T; % tempo de suporte
ts = 0:sample_time:TS;
TT = (1-beta)*T; % tempo de transferencia
tt = 0:sample_time:TT;
Hrb = 0.26; % altura do robo
VF = LS/T; % velocidade frontal
VL = VF/(1-beta); % velocidade da perna
% inicializacao dos vetores
theta1 = [];
theta2 = [];
X_leg = [];
Y_leg = [];
Z_leg = [];
X = [];
Y = [];
% fase de transferencia da perna
X_leg_s = VL*(tt - TT*sin((2*pi*tt)/TT)/(2*pi));
Y_leg_s = (FC/2)*(1 - cos(2*pi*tt/TT));
Z_leg_s(1:length(X_leg)) = 0;
% fase de suporte da perna
X_leg_p = repmat(X_leg_s(end),1,length(ts));
Y_leg_p = repmat(Y_leg_s(end),1,length(ts));
Z_leg_p = zeros(1,length(ts));
% concatenacao das fases da perna
X_leg = [X_leg_s X_leg_p];
Y_leg = [Y_leg_s Y_leg_p];
Z_leg = [Z_leg_s Z_leg_p];
% movimento do corpo
X_body = (VF)*t0 + LS*beta/2;
Y_body(1,1:length(t0)) = Hrb;
Z_body(1:length(X_body)) = 0;
% ajuste do referencial
for i = 1:1:length(t0)
X = [X X_leg(i) - X_body(i)];
Y = [Y Y_leg(i) - Y_body(i)];
end
% Cinematica Inversa
for i = 1:1:length(t0),
Theta2 = - acos((X(1,i)^2 + Y(1,i)^2 - 2*L^2)/(2*L^2));
Theta1 = atan2(Y(1,i),X(1,i)) - ...
atan2(sin(Theta2),((1 + cos(Theta2)))) ;
theta1 = [theta1 ((180/pi)*Theta1) ];
theta2 = [theta2 ((180/pi)*Theta2) ];
end
% Replicacao de trajetoria para n ciclos
theta1 = horzcat(theta1);
theta2 = horzcat(theta2);
auxtheta1 = theta1;
auxtheta2 = theta2;
X = horzcat(X_leg, X_body(1,2:end));
Y = horzcat(Y_leg, Y_body(1,2:end));
Z = horzcat(Z_leg, Z_body(1,2:end));
auxX = X;
auxY = Y;
auxZ = Z;
if nc>1
for i = 1:1:nc-1 ,
theta1 = horzcat(auxtheta1,theta1(1,2:end));
theta2 = horzcat(auxtheta2,theta2(1,2:end));
X = horzcat(auxX,X(1,2:end));
Y = horzcat(auxY,Y(1,2:end));
Z = horzcat(auxZ,Z(1,2:end));
end
end
% defasamento dos angulos para os padroes de locomocao
switch gait
case 1
% Caminhar
a4 = 0/nc;
a2 = 0.25/nc;
a3 = 0.5/nc;
a1 = 0.75/nc;
case 2
% Trotar
a1 = 0/nc;
a2 = 0.5/nc;
a3 = 0.5/nc;
a4 = 0/nc;
end
F1 = round(a1*length(t));
F2 = round(a2*length(t));
F3 = round(a3*length(t));
F4 = round(a4*length(t));
shift = 1:1:length(t);
dt1 = circshift(shift,[0,F1]);
dt2 = circshift(shift,[0,F2]);
dt3 = circshift(shift,[0,F3]);
dt4 = circshift(shift,[0,F4]);
hip_1(:,2) = theta1(1,dt1); % angulos anca 1
hip_1(:,1) = t(1,:); % Tempos anca 1
knee_1(:,2) = theta2(1,dt1); % angulos joelho 1
knee_1(:,1) = t(1,:); % Tempos joelho 1
hip_2(:,2) = theta1(1,dt2); % angulos anca 2
hip_2(:,1) = t(1,:); % Tempos anca 2
knee_2(:,2) = theta2(1,dt2); % angulos joelho 2
knee_2(:,1) = t(1,:); % Tempos joelho 2
hip_3(:,2) = theta1(1,dt3); % angulos anca 3
hip_3(:,1) = t(1,:); % Tempos anca 3
knee_3(:,2) = theta2(1,dt3); % angulos joelho 3
knee_3(:,1) = t(1,:); % Tempos joelho 3
hip_4(:,2) = theta1(1,dt4); % angulos anca 4
hip_4(:,1) = t(1,:); % Tempos anca 4
knee_4(:,2) = theta2(1,dt4); % angulos joelho 4
knee_4(:,1) = t(1,:); % Tempos joelho 4
%---------------------------------------------------------------------%
% angulos pre-definidos em arquivos .txt:
case 2
load t.txt % Carregar o vector tempo
load teta1.txt % Carrega valores das juntas da anca
load teta2.txt % Carrega valores das juntas do joelho
%Perna 1
hip_1(:,2) = teta1(1:6000,1); % angulos anca 1
hip_1(:,1) = t(1:6000); % Tempos anca 1
hip_1(:,2) = hip_1(:,2)-10;
knee_1(:,2) = teta2(1:6000,1); % angulos joelho 1
knee_1(:,1) = t(1:6000); % Tempos joelho 1
%Perna 2
hip_2(:,2) = teta1(1:6000,2); % angulos anca 2
hip_2(:,1) = t(1:6000); % Tempos anca 2
hip_2(:,2) = hip_2(:,2)- 10;
knee_2(:,2) = teta2(1:6000,2); % angulos joelho 2
knee_2(:,1) = t(1:6000); % Tempos joelho 2
%Perna 3
hip_3(:,2) = teta1(1:6000,3); % angulos anca 3
hip_3(:,1) = t(1:6000); % Tempos anca 3
hip_3(:,2) = hip_3(:,2)- 10;
knee_3(:,2) = teta2(1:6000,3); % angulos joelho 3
knee_3(:,1) = t(1:6000); % Tempos joelho 3
%Perna 4
hip_4(:,2) = teta1(1:6000,4); % angulos anca 4
hip_4(:,1) = t(1:6000); % Tempos anca 4
hip_4(:,2) = hip_4(:,2)-10;
knee_4(:,2) = teta2(1:6000,4); % angulos joelho 4
knee_4(:,1) = t(1:6000); % Tempos joelho 4
end
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% Graficos:
if algor == 1,
figure(1); % Grafico dos angulos
subplot(2,4,1);
plot(hip_1(:,1),hip_1(:,2));
title('Hip 1');
subplot(2,4,5);
plot(knee_1(:,1),knee_1(:,2));
title('Knee 1');
subplot(2,4,2);
plot(hip_2(:,1),hip_2(:,2));
title('Hip 2');
subplot(2,4,6);
plot(knee_2(:,1),knee_2(:,2));
title('Knee 2');
subplot(2,4,3);
plot(hip_3(:,1),hip_3(:,2));
title('Hip 3');
subplot(2,4,7);
plot(knee_3(:,1),knee_3(:,2));
title('Knee 3');
subplot(2,4,4);
plot(hip_4(:,1),hip_4(:,2));
title('Hip 4');
subplot(2,4,8);
plot(knee_4(:,1),knee_4(:,2));
title('Knee 4');
figure(2); % Grafico da trajectoria planeada
subplot(2,1,1);
plot(X_leg,Y_leg);
title('Leg Movement');
subplot(2,1,2);
plot(X_body,Y_body);
title('Body Movement');
figure(3); % Grafico animado da trajectoria planeada
for i = 1:length(X_body)
axis([-2*LS 2*LS, -0 Hrb+0.05]);
plot(X_body(i),Y_body(i),'b*');
pause(0.001)
hold on
plot(X_leg(i),Y_leg(i),'g*');
pause(0.001)
title('Leg Movement vs. Body Movement');
end
else
figure(2); % graficos do algoritmo de Castro
plot(hip_1(:,1),hip_1(:,2),'r');
hold on
plot(hip_2(:,1),hip_2(:,2),'b');
hold on
plot(hip_3(:,1),hip_3(:,2),'g');
hold on
plot(hip_4(:,1),hip_4(:,2),'d');
end
