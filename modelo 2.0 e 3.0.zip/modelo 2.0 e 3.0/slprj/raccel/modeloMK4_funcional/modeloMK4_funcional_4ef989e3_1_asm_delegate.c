/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'modeloMK4_funcional/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "sm_CTarget.h"

void modeloMK4_funcional_4ef989e3_1_setTargets(const RuntimeDerivedValuesBundle *
  rtdv, CTarget *targets)
{
  (void) rtdv;
  (void) targets;
}

void modeloMK4_funcional_4ef989e3_1_resetAsmStateVector(const void *mech, double
  *state)
{
  double xx[2];
  (void) mech;
  xx[0] = 0.0;
  xx[1] = 1.0;
  state[0] = xx[0];
  state[1] = xx[0];
  state[2] = xx[0];
  state[3] = xx[1];
  state[4] = xx[0];
  state[5] = xx[0];
  state[6] = xx[0];
  state[7] = xx[0];
  state[8] = xx[0];
  state[9] = xx[0];
  state[10] = xx[0];
  state[11] = xx[0];
  state[12] = xx[0];
  state[13] = xx[0];
  state[14] = xx[0];
  state[15] = xx[0];
  state[16] = xx[0];
  state[17] = xx[0];
  state[18] = xx[0];
  state[19] = xx[0];
  state[20] = xx[0];
  state[21] = xx[0];
  state[22] = xx[0];
  state[23] = xx[0];
  state[24] = xx[0];
  state[25] = xx[0];
  state[26] = xx[0];
  state[27] = xx[0];
  state[28] = xx[0];
  state[29] = xx[0];
  state[30] = xx[0];
  state[31] = xx[0];
  state[32] = xx[1];
  state[33] = xx[0];
  state[34] = xx[0];
  state[35] = xx[0];
  state[36] = xx[0];
  state[37] = xx[0];
  state[38] = xx[0];
  state[39] = xx[0];
  state[40] = xx[0];
  state[41] = xx[0];
  state[42] = xx[0];
  state[43] = xx[0];
  state[44] = xx[0];
  state[45] = xx[1];
  state[46] = xx[0];
  state[47] = xx[0];
  state[48] = xx[0];
  state[49] = xx[0];
  state[50] = xx[0];
  state[51] = xx[0];
  state[52] = xx[0];
  state[53] = xx[0];
  state[54] = xx[0];
  state[55] = xx[0];
  state[56] = xx[0];
  state[57] = xx[0];
  state[58] = xx[1];
  state[59] = xx[0];
  state[60] = xx[0];
  state[61] = xx[0];
  state[62] = xx[0];
  state[63] = xx[0];
  state[64] = xx[0];
  state[65] = xx[0];
  state[66] = xx[0];
  state[67] = xx[0];
  state[68] = xx[0];
  state[69] = xx[0];
  state[70] = xx[0];
  state[71] = xx[1];
  state[72] = xx[0];
  state[73] = xx[0];
  state[74] = xx[0];
  state[75] = xx[0];
  state[76] = xx[0];
  state[77] = xx[0];
  state[78] = xx[0];
  state[79] = xx[0];
  state[80] = xx[0];
}

void modeloMK4_funcional_4ef989e3_1_initializeTrackedAngleState(const void *mech,
  const RuntimeDerivedValuesBundle *rtdv, const int *modeVector, const double
  *motionData, double *state)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
  (void) modeVector;
  (void) motionData;
}

void modeloMK4_funcional_4ef989e3_1_computeDiscreteState(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, double *state)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
}

void modeloMK4_funcional_4ef989e3_1_adjustPosition(const void *mech, const
  double *dofDeltas, double *state)
{
  double xx[32];
  (void) mech;
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  xx[4] = dofDeltas[3];
  xx[5] = dofDeltas[4];
  xx[6] = dofDeltas[5];
  pm_math_Quaternion_compDeriv_ra(xx + 0, xx + 4, xx + 7);
  xx[0] = state[3] + xx[7];
  xx[1] = state[4] + xx[8];
  xx[2] = state[5] + xx[9];
  xx[3] = state[6] + xx[10];
  xx[4] = 1.0e-64;
  xx[5] = sqrt(xx[0] * xx[0] + xx[1] * xx[1] + xx[2] * xx[2] + xx[3] * xx[3]);
  if (xx[4] > xx[5])
    xx[5] = xx[4];
  xx[6] = state[32];
  xx[7] = state[33];
  xx[8] = state[34];
  xx[9] = state[35];
  xx[10] = dofDeltas[17];
  xx[11] = dofDeltas[18];
  xx[12] = dofDeltas[19];
  pm_math_Quaternion_compDeriv_ra(xx + 6, xx + 10, xx + 13);
  xx[6] = state[32] + xx[13];
  xx[7] = state[33] + xx[14];
  xx[8] = state[34] + xx[15];
  xx[9] = state[35] + xx[16];
  xx[10] = sqrt(xx[6] * xx[6] + xx[7] * xx[7] + xx[8] * xx[8] + xx[9] * xx[9]);
  if (xx[4] > xx[10])
    xx[10] = xx[4];
  xx[11] = state[45];
  xx[12] = state[46];
  xx[13] = state[47];
  xx[14] = state[48];
  xx[15] = dofDeltas[23];
  xx[16] = dofDeltas[24];
  xx[17] = dofDeltas[25];
  pm_math_Quaternion_compDeriv_ra(xx + 11, xx + 15, xx + 18);
  xx[11] = state[45] + xx[18];
  xx[12] = state[46] + xx[19];
  xx[13] = state[47] + xx[20];
  xx[14] = state[48] + xx[21];
  xx[15] = sqrt(xx[11] * xx[11] + xx[12] * xx[12] + xx[13] * xx[13] + xx[14] *
                xx[14]);
  if (xx[4] > xx[15])
    xx[15] = xx[4];
  xx[16] = state[58];
  xx[17] = state[59];
  xx[18] = state[60];
  xx[19] = state[61];
  xx[20] = dofDeltas[29];
  xx[21] = dofDeltas[30];
  xx[22] = dofDeltas[31];
  pm_math_Quaternion_compDeriv_ra(xx + 16, xx + 20, xx + 23);
  xx[16] = state[58] + xx[23];
  xx[17] = state[59] + xx[24];
  xx[18] = state[60] + xx[25];
  xx[19] = state[61] + xx[26];
  xx[20] = sqrt(xx[16] * xx[16] + xx[17] * xx[17] + xx[18] * xx[18] + xx[19] *
                xx[19]);
  if (xx[4] > xx[20])
    xx[20] = xx[4];
  xx[21] = state[71];
  xx[22] = state[72];
  xx[23] = state[73];
  xx[24] = state[74];
  xx[25] = dofDeltas[35];
  xx[26] = dofDeltas[36];
  xx[27] = dofDeltas[37];
  pm_math_Quaternion_compDeriv_ra(xx + 21, xx + 25, xx + 28);
  xx[21] = state[71] + xx[28];
  xx[22] = state[72] + xx[29];
  xx[23] = state[73] + xx[30];
  xx[24] = state[74] + xx[31];
  xx[25] = sqrt(xx[21] * xx[21] + xx[22] * xx[22] + xx[23] * xx[23] + xx[24] *
                xx[24]);
  if (xx[4] > xx[25])
    xx[25] = xx[4];
  state[0] = state[0] + dofDeltas[0];
  state[1] = state[1] + dofDeltas[1];
  state[2] = state[2] + dofDeltas[2];
  state[3] = xx[0] / xx[5];
  state[4] = xx[1] / xx[5];
  state[5] = xx[2] / xx[5];
  state[6] = xx[3] / xx[5];
  state[13] = state[13] + dofDeltas[6];
  state[15] = state[15] + dofDeltas[7];
  state[17] = state[17] + dofDeltas[8];
  state[19] = state[19] + dofDeltas[9];
  state[21] = state[21] + dofDeltas[10];
  state[23] = state[23] + dofDeltas[11];
  state[25] = state[25] + dofDeltas[12];
  state[27] = state[27] + dofDeltas[13];
  state[29] = state[29] + dofDeltas[14];
  state[30] = state[30] + dofDeltas[15];
  state[31] = state[31] + dofDeltas[16];
  state[32] = xx[6] / xx[10];
  state[33] = xx[7] / xx[10];
  state[34] = xx[8] / xx[10];
  state[35] = xx[9] / xx[10];
  state[42] = state[42] + dofDeltas[20];
  state[43] = state[43] + dofDeltas[21];
  state[44] = state[44] + dofDeltas[22];
  state[45] = xx[11] / xx[15];
  state[46] = xx[12] / xx[15];
  state[47] = xx[13] / xx[15];
  state[48] = xx[14] / xx[15];
  state[55] = state[55] + dofDeltas[26];
  state[56] = state[56] + dofDeltas[27];
  state[57] = state[57] + dofDeltas[28];
  state[58] = xx[16] / xx[20];
  state[59] = xx[17] / xx[20];
  state[60] = xx[18] / xx[20];
  state[61] = xx[19] / xx[20];
  state[68] = state[68] + dofDeltas[32];
  state[69] = state[69] + dofDeltas[33];
  state[70] = state[70] + dofDeltas[34];
  state[71] = xx[21] / xx[25];
  state[72] = xx[22] / xx[25];
  state[73] = xx[23] / xx[25];
  state[74] = xx[24] / xx[25];
}

static void perturbAsmJointPrimitiveState_0_0(double mag, double *state)
{
  state[0] = state[0] + mag;
}

static void perturbAsmJointPrimitiveState_0_0v(double mag, double *state)
{
  state[0] = state[0] + mag;
  state[7] = state[7] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_0_1(double mag, double *state)
{
  state[1] = state[1] + mag;
}

static void perturbAsmJointPrimitiveState_0_1v(double mag, double *state)
{
  state[1] = state[1] + mag;
  state[8] = state[8] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_0_2(double mag, double *state)
{
  state[2] = state[2] + mag;
}

static void perturbAsmJointPrimitiveState_0_2v(double mag, double *state)
{
  state[2] = state[2] + mag;
  state[9] = state[9] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_0_3(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[0] = state[3];
  xx[1] = state[4];
  xx[2] = state[5];
  xx[3] = state[6];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 0, xx + 4);
  state[3] = xx[4];
  state[4] = xx[5];
  state[5] = xx[6];
  state[6] = xx[7];
}

static void perturbAsmJointPrimitiveState_0_3v(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[3] = state[3];
  xx[4] = state[4];
  xx[5] = state[5];
  xx[6] = state[6];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 3, xx + 7);
  state[3] = xx[7];
  state[4] = xx[8];
  state[5] = xx[9];
  state[6] = xx[10];
  state[10] = state[10] + 1.2 * mag;
  state[11] = state[11] - xx[2];
  state[12] = state[12] + 0.9 * mag;
}

static void perturbAsmJointPrimitiveState_1_0(double mag, double *state)
{
  state[13] = state[13] + mag;
}

static void perturbAsmJointPrimitiveState_1_0v(double mag, double *state)
{
  state[13] = state[13] + mag;
  state[14] = state[14] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_2_0(double mag, double *state)
{
  state[15] = state[15] + mag;
}

static void perturbAsmJointPrimitiveState_2_0v(double mag, double *state)
{
  state[15] = state[15] + mag;
  state[16] = state[16] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_3_0(double mag, double *state)
{
  state[17] = state[17] + mag;
}

static void perturbAsmJointPrimitiveState_3_0v(double mag, double *state)
{
  state[17] = state[17] + mag;
  state[18] = state[18] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_4_0(double mag, double *state)
{
  state[19] = state[19] + mag;
}

static void perturbAsmJointPrimitiveState_4_0v(double mag, double *state)
{
  state[19] = state[19] + mag;
  state[20] = state[20] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_5_0(double mag, double *state)
{
  state[21] = state[21] + mag;
}

static void perturbAsmJointPrimitiveState_5_0v(double mag, double *state)
{
  state[21] = state[21] + mag;
  state[22] = state[22] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_6_0(double mag, double *state)
{
  state[23] = state[23] + mag;
}

static void perturbAsmJointPrimitiveState_6_0v(double mag, double *state)
{
  state[23] = state[23] + mag;
  state[24] = state[24] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_7_0(double mag, double *state)
{
  state[25] = state[25] + mag;
}

static void perturbAsmJointPrimitiveState_7_0v(double mag, double *state)
{
  state[25] = state[25] + mag;
  state[26] = state[26] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_8_0(double mag, double *state)
{
  state[27] = state[27] + mag;
}

static void perturbAsmJointPrimitiveState_8_0v(double mag, double *state)
{
  state[27] = state[27] + mag;
  state[28] = state[28] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_9_0(double mag, double *state)
{
  state[29] = state[29] + mag;
}

static void perturbAsmJointPrimitiveState_9_0v(double mag, double *state)
{
  state[29] = state[29] + mag;
  state[36] = state[36] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_9_1(double mag, double *state)
{
  state[30] = state[30] + mag;
}

static void perturbAsmJointPrimitiveState_9_1v(double mag, double *state)
{
  state[30] = state[30] + mag;
  state[37] = state[37] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_9_2(double mag, double *state)
{
  state[31] = state[31] + mag;
}

static void perturbAsmJointPrimitiveState_9_2v(double mag, double *state)
{
  state[31] = state[31] + mag;
  state[38] = state[38] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_9_3(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[0] = state[32];
  xx[1] = state[33];
  xx[2] = state[34];
  xx[3] = state[35];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 0, xx + 4);
  state[32] = xx[4];
  state[33] = xx[5];
  state[34] = xx[6];
  state[35] = xx[7];
}

static void perturbAsmJointPrimitiveState_9_3v(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[3] = state[32];
  xx[4] = state[33];
  xx[5] = state[34];
  xx[6] = state[35];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 3, xx + 7);
  state[32] = xx[7];
  state[33] = xx[8];
  state[34] = xx[9];
  state[35] = xx[10];
  state[39] = state[39] + 1.2 * mag;
  state[40] = state[40] - xx[2];
  state[41] = state[41] + 0.9 * mag;
}

static void perturbAsmJointPrimitiveState_10_0(double mag, double *state)
{
  state[42] = state[42] + mag;
}

static void perturbAsmJointPrimitiveState_10_0v(double mag, double *state)
{
  state[42] = state[42] + mag;
  state[49] = state[49] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_10_1(double mag, double *state)
{
  state[43] = state[43] + mag;
}

static void perturbAsmJointPrimitiveState_10_1v(double mag, double *state)
{
  state[43] = state[43] + mag;
  state[50] = state[50] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_10_2(double mag, double *state)
{
  state[44] = state[44] + mag;
}

static void perturbAsmJointPrimitiveState_10_2v(double mag, double *state)
{
  state[44] = state[44] + mag;
  state[51] = state[51] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_10_3(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[0] = state[45];
  xx[1] = state[46];
  xx[2] = state[47];
  xx[3] = state[48];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 0, xx + 4);
  state[45] = xx[4];
  state[46] = xx[5];
  state[47] = xx[6];
  state[48] = xx[7];
}

static void perturbAsmJointPrimitiveState_10_3v(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[3] = state[45];
  xx[4] = state[46];
  xx[5] = state[47];
  xx[6] = state[48];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 3, xx + 7);
  state[45] = xx[7];
  state[46] = xx[8];
  state[47] = xx[9];
  state[48] = xx[10];
  state[52] = state[52] + 1.2 * mag;
  state[53] = state[53] - xx[2];
  state[54] = state[54] + 0.9 * mag;
}

static void perturbAsmJointPrimitiveState_11_0(double mag, double *state)
{
  state[55] = state[55] + mag;
}

static void perturbAsmJointPrimitiveState_11_0v(double mag, double *state)
{
  state[55] = state[55] + mag;
  state[62] = state[62] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_11_1(double mag, double *state)
{
  state[56] = state[56] + mag;
}

static void perturbAsmJointPrimitiveState_11_1v(double mag, double *state)
{
  state[56] = state[56] + mag;
  state[63] = state[63] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_11_2(double mag, double *state)
{
  state[57] = state[57] + mag;
}

static void perturbAsmJointPrimitiveState_11_2v(double mag, double *state)
{
  state[57] = state[57] + mag;
  state[64] = state[64] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_11_3(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[0] = state[58];
  xx[1] = state[59];
  xx[2] = state[60];
  xx[3] = state[61];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 0, xx + 4);
  state[58] = xx[4];
  state[59] = xx[5];
  state[60] = xx[6];
  state[61] = xx[7];
}

static void perturbAsmJointPrimitiveState_11_3v(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[3] = state[58];
  xx[4] = state[59];
  xx[5] = state[60];
  xx[6] = state[61];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 3, xx + 7);
  state[58] = xx[7];
  state[59] = xx[8];
  state[60] = xx[9];
  state[61] = xx[10];
  state[65] = state[65] + 1.2 * mag;
  state[66] = state[66] - xx[2];
  state[67] = state[67] + 0.9 * mag;
}

static void perturbAsmJointPrimitiveState_12_0(double mag, double *state)
{
  state[68] = state[68] + mag;
}

static void perturbAsmJointPrimitiveState_12_0v(double mag, double *state)
{
  state[68] = state[68] + mag;
  state[75] = state[75] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_12_1(double mag, double *state)
{
  state[69] = state[69] + mag;
}

static void perturbAsmJointPrimitiveState_12_1v(double mag, double *state)
{
  state[69] = state[69] + mag;
  state[76] = state[76] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_12_2(double mag, double *state)
{
  state[70] = state[70] + mag;
}

static void perturbAsmJointPrimitiveState_12_2v(double mag, double *state)
{
  state[70] = state[70] + mag;
  state[77] = state[77] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_12_3(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[0] = state[71];
  xx[1] = state[72];
  xx[2] = state[73];
  xx[3] = state[74];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 0, xx + 4);
  state[71] = xx[4];
  state[72] = xx[5];
  state[73] = xx[6];
  state[74] = xx[7];
}

static void perturbAsmJointPrimitiveState_12_3v(double mag, double *state)
{
  double xx[15];
  xx[0] = 1.0;
  xx[1] = fabs(mag);
  xx[2] = xx[0] / (xx[1] - floor(xx[1]) + 1.0e-9);
  xx[1] = sin(xx[2]);
  xx[3] = 0.0;
  xx[4] = cos(xx[2]);
  xx[5] = sin(2.0 * xx[2]);
  xx[2] = 0.5 * mag;
  xx[6] = sqrt(xx[1] * xx[1] + xx[4] * xx[4] + xx[5] * xx[5]);
  xx[7] = xx[6] == 0.0 ? 0.0 : xx[1] / xx[6];
  xx[8] = sin(xx[2]);
  xx[9] = xx[6] == 0.0 ? 0.0 : xx[4] / xx[6];
  xx[10] = xx[6] == 0.0 ? 0.0 : xx[5] / xx[6];
  xx[11] = xx[1] == xx[3] && xx[4] == xx[3] && xx[5] == xx[3] ? xx[0] : cos(xx[2]);
  xx[12] = xx[7] * xx[8];
  xx[13] = xx[9] * xx[8];
  xx[14] = xx[10] * xx[8];
  xx[3] = state[71];
  xx[4] = state[72];
  xx[5] = state[73];
  xx[6] = state[74];
  pm_math_Quaternion_compose_ra(xx + 11, xx + 3, xx + 7);
  state[71] = xx[7];
  state[72] = xx[8];
  state[73] = xx[9];
  state[74] = xx[10];
  state[78] = state[78] + 1.2 * mag;
  state[79] = state[79] - xx[2];
  state[80] = state[80] + 0.9 * mag;
}

void modeloMK4_funcional_4ef989e3_1_perturbAsmJointPrimitiveState(const void
  *mech, size_t stageIdx, size_t primIdx, double mag, boolean_T
  doPerturbVelocity, double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch ((stageIdx * 6 + primIdx) * 2 + (doPerturbVelocity ? 1 : 0))
  {
   case 0:
    perturbAsmJointPrimitiveState_0_0(mag, state);
    break;

   case 1:
    perturbAsmJointPrimitiveState_0_0v(mag, state);
    break;

   case 2:
    perturbAsmJointPrimitiveState_0_1(mag, state);
    break;

   case 3:
    perturbAsmJointPrimitiveState_0_1v(mag, state);
    break;

   case 4:
    perturbAsmJointPrimitiveState_0_2(mag, state);
    break;

   case 5:
    perturbAsmJointPrimitiveState_0_2v(mag, state);
    break;

   case 6:
    perturbAsmJointPrimitiveState_0_3(mag, state);
    break;

   case 7:
    perturbAsmJointPrimitiveState_0_3v(mag, state);
    break;

   case 12:
    perturbAsmJointPrimitiveState_1_0(mag, state);
    break;

   case 13:
    perturbAsmJointPrimitiveState_1_0v(mag, state);
    break;

   case 24:
    perturbAsmJointPrimitiveState_2_0(mag, state);
    break;

   case 25:
    perturbAsmJointPrimitiveState_2_0v(mag, state);
    break;

   case 36:
    perturbAsmJointPrimitiveState_3_0(mag, state);
    break;

   case 37:
    perturbAsmJointPrimitiveState_3_0v(mag, state);
    break;

   case 48:
    perturbAsmJointPrimitiveState_4_0(mag, state);
    break;

   case 49:
    perturbAsmJointPrimitiveState_4_0v(mag, state);
    break;

   case 60:
    perturbAsmJointPrimitiveState_5_0(mag, state);
    break;

   case 61:
    perturbAsmJointPrimitiveState_5_0v(mag, state);
    break;

   case 72:
    perturbAsmJointPrimitiveState_6_0(mag, state);
    break;

   case 73:
    perturbAsmJointPrimitiveState_6_0v(mag, state);
    break;

   case 84:
    perturbAsmJointPrimitiveState_7_0(mag, state);
    break;

   case 85:
    perturbAsmJointPrimitiveState_7_0v(mag, state);
    break;

   case 96:
    perturbAsmJointPrimitiveState_8_0(mag, state);
    break;

   case 97:
    perturbAsmJointPrimitiveState_8_0v(mag, state);
    break;

   case 108:
    perturbAsmJointPrimitiveState_9_0(mag, state);
    break;

   case 109:
    perturbAsmJointPrimitiveState_9_0v(mag, state);
    break;

   case 110:
    perturbAsmJointPrimitiveState_9_1(mag, state);
    break;

   case 111:
    perturbAsmJointPrimitiveState_9_1v(mag, state);
    break;

   case 112:
    perturbAsmJointPrimitiveState_9_2(mag, state);
    break;

   case 113:
    perturbAsmJointPrimitiveState_9_2v(mag, state);
    break;

   case 114:
    perturbAsmJointPrimitiveState_9_3(mag, state);
    break;

   case 115:
    perturbAsmJointPrimitiveState_9_3v(mag, state);
    break;

   case 120:
    perturbAsmJointPrimitiveState_10_0(mag, state);
    break;

   case 121:
    perturbAsmJointPrimitiveState_10_0v(mag, state);
    break;

   case 122:
    perturbAsmJointPrimitiveState_10_1(mag, state);
    break;

   case 123:
    perturbAsmJointPrimitiveState_10_1v(mag, state);
    break;

   case 124:
    perturbAsmJointPrimitiveState_10_2(mag, state);
    break;

   case 125:
    perturbAsmJointPrimitiveState_10_2v(mag, state);
    break;

   case 126:
    perturbAsmJointPrimitiveState_10_3(mag, state);
    break;

   case 127:
    perturbAsmJointPrimitiveState_10_3v(mag, state);
    break;

   case 132:
    perturbAsmJointPrimitiveState_11_0(mag, state);
    break;

   case 133:
    perturbAsmJointPrimitiveState_11_0v(mag, state);
    break;

   case 134:
    perturbAsmJointPrimitiveState_11_1(mag, state);
    break;

   case 135:
    perturbAsmJointPrimitiveState_11_1v(mag, state);
    break;

   case 136:
    perturbAsmJointPrimitiveState_11_2(mag, state);
    break;

   case 137:
    perturbAsmJointPrimitiveState_11_2v(mag, state);
    break;

   case 138:
    perturbAsmJointPrimitiveState_11_3(mag, state);
    break;

   case 139:
    perturbAsmJointPrimitiveState_11_3v(mag, state);
    break;

   case 144:
    perturbAsmJointPrimitiveState_12_0(mag, state);
    break;

   case 145:
    perturbAsmJointPrimitiveState_12_0v(mag, state);
    break;

   case 146:
    perturbAsmJointPrimitiveState_12_1(mag, state);
    break;

   case 147:
    perturbAsmJointPrimitiveState_12_1v(mag, state);
    break;

   case 148:
    perturbAsmJointPrimitiveState_12_2(mag, state);
    break;

   case 149:
    perturbAsmJointPrimitiveState_12_2v(mag, state);
    break;

   case 150:
    perturbAsmJointPrimitiveState_12_3(mag, state);
    break;

   case 151:
    perturbAsmJointPrimitiveState_12_3v(mag, state);
    break;
  }
}

static void computePosDofBlendMatrix_0_3(const double *state, int partialType,
  double *matrix)
{
  double xx[20];
  xx[0] = 9.87654321;
  xx[1] = 2.0;
  xx[2] = xx[1] * (state[4] * state[5] - state[3] * state[6]);
  xx[3] = xx[2] * xx[2];
  xx[4] = 1.0;
  xx[5] = (state[3] * state[3] + state[4] * state[4]) * xx[1] - xx[4];
  xx[6] = xx[5] * xx[5];
  xx[7] = sqrt(xx[3] + xx[6]);
  xx[8] = xx[7] == 0.0 ? 0.0 : - xx[2] / xx[7];
  xx[9] = xx[6] + xx[3];
  xx[3] = sqrt(xx[9]);
  xx[6] = xx[3] == 0.0 ? 0.0 : xx[5] / xx[3];
  xx[10] = 0.0;
  xx[11] = (state[4] * state[6] + state[3] * state[5]) * xx[1];
  xx[1] = sqrt(xx[9] + xx[11] * xx[11]);
  xx[12] = xx[1] == 0.0 ? 0.0 : xx[5] / xx[1];
  xx[14] = xx[8];
  xx[15] = xx[6];
  xx[16] = xx[10];
  xx[17] = xx[8];
  xx[18] = xx[8];
  xx[19] = xx[12];
  xx[6] = xx[13 + (partialType)];
  xx[8] = xx[7] == 0.0 ? 0.0 : xx[5] / xx[7];
  xx[7] = xx[3] == 0.0 ? 0.0 : xx[2] / xx[3];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[2] / xx[1];
  xx[13] = xx[8];
  xx[14] = xx[7];
  xx[15] = xx[10];
  xx[16] = xx[8];
  xx[17] = xx[8];
  xx[18] = xx[3];
  xx[2] = xx[12 + (partialType)];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[11] / xx[1];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[4];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[18] = xx[3];
  xx[1] = xx[12 + (partialType)];
  xx[3] = xx[11] * xx[5];
  xx[5] = sqrt(xx[9] * xx[9] + xx[3] * xx[3]);
  xx[7] = xx[5] == 0.0 ? 0.0 : xx[9] / xx[5];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[7];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[7] = xx[11 + (partialType)];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[10];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[8] = xx[11 + (partialType)];
  xx[9] = xx[5] == 0.0 ? 0.0 : xx[3] / xx[5];
  xx[12] = xx[4];
  xx[13] = xx[4];
  xx[14] = xx[10];
  xx[15] = xx[9];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[0] = xx[11 + (partialType)];
  matrix[0] = xx[6];
  matrix[1] = xx[2];
  matrix[2] = xx[1];
  matrix[3] = xx[7];
  matrix[4] = xx[8];
  matrix[5] = xx[0];
  matrix[6] = xx[8];
  matrix[7] = xx[8];
  matrix[8] = xx[8];
}

static void computePosDofBlendMatrix_9_3(const double *state, int partialType,
  double *matrix)
{
  double xx[20];
  xx[0] = 9.87654321;
  xx[1] = 2.0;
  xx[2] = xx[1] * (state[33] * state[34] - state[32] * state[35]);
  xx[3] = xx[2] * xx[2];
  xx[4] = 1.0;
  xx[5] = (state[32] * state[32] + state[33] * state[33]) * xx[1] - xx[4];
  xx[6] = xx[5] * xx[5];
  xx[7] = sqrt(xx[3] + xx[6]);
  xx[8] = xx[7] == 0.0 ? 0.0 : - xx[2] / xx[7];
  xx[9] = xx[6] + xx[3];
  xx[3] = sqrt(xx[9]);
  xx[6] = xx[3] == 0.0 ? 0.0 : xx[5] / xx[3];
  xx[10] = 0.0;
  xx[11] = (state[33] * state[35] + state[32] * state[34]) * xx[1];
  xx[1] = sqrt(xx[9] + xx[11] * xx[11]);
  xx[12] = xx[1] == 0.0 ? 0.0 : xx[5] / xx[1];
  xx[14] = xx[8];
  xx[15] = xx[6];
  xx[16] = xx[10];
  xx[17] = xx[8];
  xx[18] = xx[8];
  xx[19] = xx[12];
  xx[6] = xx[13 + (partialType)];
  xx[8] = xx[7] == 0.0 ? 0.0 : xx[5] / xx[7];
  xx[7] = xx[3] == 0.0 ? 0.0 : xx[2] / xx[3];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[2] / xx[1];
  xx[13] = xx[8];
  xx[14] = xx[7];
  xx[15] = xx[10];
  xx[16] = xx[8];
  xx[17] = xx[8];
  xx[18] = xx[3];
  xx[2] = xx[12 + (partialType)];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[11] / xx[1];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[4];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[18] = xx[3];
  xx[1] = xx[12 + (partialType)];
  xx[3] = xx[11] * xx[5];
  xx[5] = sqrt(xx[9] * xx[9] + xx[3] * xx[3]);
  xx[7] = xx[5] == 0.0 ? 0.0 : xx[9] / xx[5];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[7];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[7] = xx[11 + (partialType)];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[10];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[8] = xx[11 + (partialType)];
  xx[9] = xx[5] == 0.0 ? 0.0 : xx[3] / xx[5];
  xx[12] = xx[4];
  xx[13] = xx[4];
  xx[14] = xx[10];
  xx[15] = xx[9];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[0] = xx[11 + (partialType)];
  matrix[0] = xx[6];
  matrix[1] = xx[2];
  matrix[2] = xx[1];
  matrix[3] = xx[7];
  matrix[4] = xx[8];
  matrix[5] = xx[0];
  matrix[6] = xx[8];
  matrix[7] = xx[8];
  matrix[8] = xx[8];
}

static void computePosDofBlendMatrix_10_3(const double *state, int partialType,
  double *matrix)
{
  double xx[20];
  xx[0] = 9.87654321;
  xx[1] = 2.0;
  xx[2] = xx[1] * (state[46] * state[47] - state[45] * state[48]);
  xx[3] = xx[2] * xx[2];
  xx[4] = 1.0;
  xx[5] = (state[45] * state[45] + state[46] * state[46]) * xx[1] - xx[4];
  xx[6] = xx[5] * xx[5];
  xx[7] = sqrt(xx[3] + xx[6]);
  xx[8] = xx[7] == 0.0 ? 0.0 : - xx[2] / xx[7];
  xx[9] = xx[6] + xx[3];
  xx[3] = sqrt(xx[9]);
  xx[6] = xx[3] == 0.0 ? 0.0 : xx[5] / xx[3];
  xx[10] = 0.0;
  xx[11] = (state[46] * state[48] + state[45] * state[47]) * xx[1];
  xx[1] = sqrt(xx[9] + xx[11] * xx[11]);
  xx[12] = xx[1] == 0.0 ? 0.0 : xx[5] / xx[1];
  xx[14] = xx[8];
  xx[15] = xx[6];
  xx[16] = xx[10];
  xx[17] = xx[8];
  xx[18] = xx[8];
  xx[19] = xx[12];
  xx[6] = xx[13 + (partialType)];
  xx[8] = xx[7] == 0.0 ? 0.0 : xx[5] / xx[7];
  xx[7] = xx[3] == 0.0 ? 0.0 : xx[2] / xx[3];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[2] / xx[1];
  xx[13] = xx[8];
  xx[14] = xx[7];
  xx[15] = xx[10];
  xx[16] = xx[8];
  xx[17] = xx[8];
  xx[18] = xx[3];
  xx[2] = xx[12 + (partialType)];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[11] / xx[1];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[4];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[18] = xx[3];
  xx[1] = xx[12 + (partialType)];
  xx[3] = xx[11] * xx[5];
  xx[5] = sqrt(xx[9] * xx[9] + xx[3] * xx[3]);
  xx[7] = xx[5] == 0.0 ? 0.0 : xx[9] / xx[5];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[7];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[7] = xx[11 + (partialType)];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[10];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[8] = xx[11 + (partialType)];
  xx[9] = xx[5] == 0.0 ? 0.0 : xx[3] / xx[5];
  xx[12] = xx[4];
  xx[13] = xx[4];
  xx[14] = xx[10];
  xx[15] = xx[9];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[0] = xx[11 + (partialType)];
  matrix[0] = xx[6];
  matrix[1] = xx[2];
  matrix[2] = xx[1];
  matrix[3] = xx[7];
  matrix[4] = xx[8];
  matrix[5] = xx[0];
  matrix[6] = xx[8];
  matrix[7] = xx[8];
  matrix[8] = xx[8];
}

static void computePosDofBlendMatrix_11_3(const double *state, int partialType,
  double *matrix)
{
  double xx[20];
  xx[0] = 9.87654321;
  xx[1] = 2.0;
  xx[2] = xx[1] * (state[59] * state[60] - state[58] * state[61]);
  xx[3] = xx[2] * xx[2];
  xx[4] = 1.0;
  xx[5] = (state[58] * state[58] + state[59] * state[59]) * xx[1] - xx[4];
  xx[6] = xx[5] * xx[5];
  xx[7] = sqrt(xx[3] + xx[6]);
  xx[8] = xx[7] == 0.0 ? 0.0 : - xx[2] / xx[7];
  xx[9] = xx[6] + xx[3];
  xx[3] = sqrt(xx[9]);
  xx[6] = xx[3] == 0.0 ? 0.0 : xx[5] / xx[3];
  xx[10] = 0.0;
  xx[11] = (state[59] * state[61] + state[58] * state[60]) * xx[1];
  xx[1] = sqrt(xx[9] + xx[11] * xx[11]);
  xx[12] = xx[1] == 0.0 ? 0.0 : xx[5] / xx[1];
  xx[14] = xx[8];
  xx[15] = xx[6];
  xx[16] = xx[10];
  xx[17] = xx[8];
  xx[18] = xx[8];
  xx[19] = xx[12];
  xx[6] = xx[13 + (partialType)];
  xx[8] = xx[7] == 0.0 ? 0.0 : xx[5] / xx[7];
  xx[7] = xx[3] == 0.0 ? 0.0 : xx[2] / xx[3];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[2] / xx[1];
  xx[13] = xx[8];
  xx[14] = xx[7];
  xx[15] = xx[10];
  xx[16] = xx[8];
  xx[17] = xx[8];
  xx[18] = xx[3];
  xx[2] = xx[12 + (partialType)];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[11] / xx[1];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[4];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[18] = xx[3];
  xx[1] = xx[12 + (partialType)];
  xx[3] = xx[11] * xx[5];
  xx[5] = sqrt(xx[9] * xx[9] + xx[3] * xx[3]);
  xx[7] = xx[5] == 0.0 ? 0.0 : xx[9] / xx[5];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[7];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[7] = xx[11 + (partialType)];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[10];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[8] = xx[11 + (partialType)];
  xx[9] = xx[5] == 0.0 ? 0.0 : xx[3] / xx[5];
  xx[12] = xx[4];
  xx[13] = xx[4];
  xx[14] = xx[10];
  xx[15] = xx[9];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[0] = xx[11 + (partialType)];
  matrix[0] = xx[6];
  matrix[1] = xx[2];
  matrix[2] = xx[1];
  matrix[3] = xx[7];
  matrix[4] = xx[8];
  matrix[5] = xx[0];
  matrix[6] = xx[8];
  matrix[7] = xx[8];
  matrix[8] = xx[8];
}

static void computePosDofBlendMatrix_12_3(const double *state, int partialType,
  double *matrix)
{
  double xx[20];
  xx[0] = 9.87654321;
  xx[1] = 2.0;
  xx[2] = xx[1] * (state[72] * state[73] - state[71] * state[74]);
  xx[3] = xx[2] * xx[2];
  xx[4] = 1.0;
  xx[5] = (state[71] * state[71] + state[72] * state[72]) * xx[1] - xx[4];
  xx[6] = xx[5] * xx[5];
  xx[7] = sqrt(xx[3] + xx[6]);
  xx[8] = xx[7] == 0.0 ? 0.0 : - xx[2] / xx[7];
  xx[9] = xx[6] + xx[3];
  xx[3] = sqrt(xx[9]);
  xx[6] = xx[3] == 0.0 ? 0.0 : xx[5] / xx[3];
  xx[10] = 0.0;
  xx[11] = (state[72] * state[74] + state[71] * state[73]) * xx[1];
  xx[1] = sqrt(xx[9] + xx[11] * xx[11]);
  xx[12] = xx[1] == 0.0 ? 0.0 : xx[5] / xx[1];
  xx[14] = xx[8];
  xx[15] = xx[6];
  xx[16] = xx[10];
  xx[17] = xx[8];
  xx[18] = xx[8];
  xx[19] = xx[12];
  xx[6] = xx[13 + (partialType)];
  xx[8] = xx[7] == 0.0 ? 0.0 : xx[5] / xx[7];
  xx[7] = xx[3] == 0.0 ? 0.0 : xx[2] / xx[3];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[2] / xx[1];
  xx[13] = xx[8];
  xx[14] = xx[7];
  xx[15] = xx[10];
  xx[16] = xx[8];
  xx[17] = xx[8];
  xx[18] = xx[3];
  xx[2] = xx[12 + (partialType)];
  xx[3] = xx[1] == 0.0 ? 0.0 : xx[11] / xx[1];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[4];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[18] = xx[3];
  xx[1] = xx[12 + (partialType)];
  xx[3] = xx[11] * xx[5];
  xx[5] = sqrt(xx[9] * xx[9] + xx[3] * xx[3]);
  xx[7] = xx[5] == 0.0 ? 0.0 : xx[9] / xx[5];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[7];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[7] = xx[11 + (partialType)];
  xx[12] = xx[10];
  xx[13] = xx[10];
  xx[14] = xx[10];
  xx[15] = xx[10];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[8] = xx[11 + (partialType)];
  xx[9] = xx[5] == 0.0 ? 0.0 : xx[3] / xx[5];
  xx[12] = xx[4];
  xx[13] = xx[4];
  xx[14] = xx[10];
  xx[15] = xx[9];
  xx[16] = xx[10];
  xx[17] = xx[10];
  xx[0] = xx[11 + (partialType)];
  matrix[0] = xx[6];
  matrix[1] = xx[2];
  matrix[2] = xx[1];
  matrix[3] = xx[7];
  matrix[4] = xx[8];
  matrix[5] = xx[0];
  matrix[6] = xx[8];
  matrix[7] = xx[8];
  matrix[8] = xx[8];
}

void modeloMK4_funcional_4ef989e3_1_computePosDofBlendMatrix(const void *mech,
  size_t stageIdx, size_t primIdx, const double *state, int partialType, double *
  matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
   case 3:
    computePosDofBlendMatrix_0_3(state, partialType, matrix);
    break;

   case 57:
    computePosDofBlendMatrix_9_3(state, partialType, matrix);
    break;

   case 63:
    computePosDofBlendMatrix_10_3(state, partialType, matrix);
    break;

   case 69:
    computePosDofBlendMatrix_11_3(state, partialType, matrix);
    break;

   case 75:
    computePosDofBlendMatrix_12_3(state, partialType, matrix);
    break;
  }
}

static void computeVelDofBlendMatrix_0_3(const double *state, int partialType,
  double *matrix)
{
  double xx[15];
  (void) state;
  xx[0] = 9.87654321;
  xx[1] = 0.0;
  xx[2] = 1.0;
  xx[4] = xx[1];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[2];
  xx[10] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[2];
  xx[9] = xx[1];
  xx[11] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[2];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[12] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[13] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[14] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[0] = xx[3 + (partialType)];
  matrix[0] = xx[10];
  matrix[1] = xx[11];
  matrix[2] = xx[12];
  matrix[3] = xx[13];
  matrix[4] = xx[14];
  matrix[5] = xx[0];
  matrix[6] = xx[13];
  matrix[7] = xx[13];
  matrix[8] = xx[13];
}

static void computeVelDofBlendMatrix_9_3(const double *state, int partialType,
  double *matrix)
{
  double xx[15];
  (void) state;
  xx[0] = 9.87654321;
  xx[1] = 0.0;
  xx[2] = 1.0;
  xx[4] = xx[1];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[2];
  xx[10] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[2];
  xx[9] = xx[1];
  xx[11] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[2];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[12] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[13] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[14] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[0] = xx[3 + (partialType)];
  matrix[0] = xx[10];
  matrix[1] = xx[11];
  matrix[2] = xx[12];
  matrix[3] = xx[13];
  matrix[4] = xx[14];
  matrix[5] = xx[0];
  matrix[6] = xx[13];
  matrix[7] = xx[13];
  matrix[8] = xx[13];
}

static void computeVelDofBlendMatrix_10_3(const double *state, int partialType,
  double *matrix)
{
  double xx[15];
  (void) state;
  xx[0] = 9.87654321;
  xx[1] = 0.0;
  xx[2] = 1.0;
  xx[4] = xx[1];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[2];
  xx[10] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[2];
  xx[9] = xx[1];
  xx[11] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[2];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[12] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[13] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[14] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[0] = xx[3 + (partialType)];
  matrix[0] = xx[10];
  matrix[1] = xx[11];
  matrix[2] = xx[12];
  matrix[3] = xx[13];
  matrix[4] = xx[14];
  matrix[5] = xx[0];
  matrix[6] = xx[13];
  matrix[7] = xx[13];
  matrix[8] = xx[13];
}

static void computeVelDofBlendMatrix_11_3(const double *state, int partialType,
  double *matrix)
{
  double xx[15];
  (void) state;
  xx[0] = 9.87654321;
  xx[1] = 0.0;
  xx[2] = 1.0;
  xx[4] = xx[1];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[2];
  xx[10] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[2];
  xx[9] = xx[1];
  xx[11] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[2];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[12] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[13] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[14] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[0] = xx[3 + (partialType)];
  matrix[0] = xx[10];
  matrix[1] = xx[11];
  matrix[2] = xx[12];
  matrix[3] = xx[13];
  matrix[4] = xx[14];
  matrix[5] = xx[0];
  matrix[6] = xx[13];
  matrix[7] = xx[13];
  matrix[8] = xx[13];
}

static void computeVelDofBlendMatrix_12_3(const double *state, int partialType,
  double *matrix)
{
  double xx[15];
  (void) state;
  xx[0] = 9.87654321;
  xx[1] = 0.0;
  xx[2] = 1.0;
  xx[4] = xx[1];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[2];
  xx[10] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[2];
  xx[9] = xx[1];
  xx[11] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[2];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[12] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[13] = xx[3 + (partialType)];
  xx[4] = xx[1];
  xx[5] = xx[1];
  xx[6] = xx[1];
  xx[7] = xx[2];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[14] = xx[3 + (partialType)];
  xx[4] = xx[2];
  xx[5] = xx[2];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[1];
  xx[9] = xx[1];
  xx[0] = xx[3 + (partialType)];
  matrix[0] = xx[10];
  matrix[1] = xx[11];
  matrix[2] = xx[12];
  matrix[3] = xx[13];
  matrix[4] = xx[14];
  matrix[5] = xx[0];
  matrix[6] = xx[13];
  matrix[7] = xx[13];
  matrix[8] = xx[13];
}

void modeloMK4_funcional_4ef989e3_1_computeVelDofBlendMatrix(const void *mech,
  size_t stageIdx, size_t primIdx, const double *state, int partialType, double *
  matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
   case 3:
    computeVelDofBlendMatrix_0_3(state, partialType, matrix);
    break;

   case 57:
    computeVelDofBlendMatrix_9_3(state, partialType, matrix);
    break;

   case 63:
    computeVelDofBlendMatrix_10_3(state, partialType, matrix);
    break;

   case 69:
    computeVelDofBlendMatrix_11_3(state, partialType, matrix);
    break;

   case 75:
    computeVelDofBlendMatrix_12_3(state, partialType, matrix);
    break;
  }
}

static void projectPartiallyTargetedPos_0_3(const double *origState, int
  partialType, double *state)
{
  boolean_T bb[2];
  double xx[17];
  xx[0] = 2.0;
  xx[1] = (state[4] * state[6] + state[3] * state[5]) * xx[0];
  xx[2] = 0.99999999999999;
  bb[0] = fabs(xx[1]) > xx[2];
  xx[3] = 1.570796326794897;
  if (xx[1] < 0.0)
    xx[4] = -1.0;
  else if (xx[1] > 0.0)
    xx[4] = +1.0;
  else
    xx[4] = 0.0;
  xx[5] = fabs(xx[1]) > 1.0 ? atan2(xx[1], 0.0) : asin(xx[1]);
  xx[1] = bb[0] ? xx[3] * xx[4] : xx[5];
  xx[5] = (origState[4] * origState[6] + origState[3] * origState[5]) * xx[0];
  bb[1] = fabs(xx[5]) > xx[2];
  if (xx[5] < 0.0)
    xx[2] = -1.0;
  else if (xx[5] > 0.0)
    xx[2] = +1.0;
  else
    xx[2] = 0.0;
  xx[6] = fabs(xx[5]) > 1.0 ? atan2(xx[5], 0.0) : asin(xx[5]);
  xx[5] = bb[1] ? xx[3] * xx[2] : xx[6];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[5];
  xx[9] = xx[5];
  xx[10] = xx[1];
  xx[11] = xx[1];
  xx[12] = xx[5];
  xx[1] = xx[6 + (partialType)];
  xx[3] = cos(xx[1]);
  xx[5] = 0.5;
  xx[6] = state[5] * state[6];
  xx[7] = state[3] * state[4];
  xx[8] = state[3] * state[3];
  xx[9] = 1.0;
  xx[10] = (xx[8] + state[5] * state[5]) * xx[0] - xx[9];
  xx[11] = (xx[6] + xx[7]) * xx[0];
  xx[10] = (xx[11] == 0.0 && xx[10] == 0.0) ? 0.0 : atan2(xx[11], xx[10]);
  xx[11] = (xx[8] + state[6] * state[6]) * xx[0] - xx[9];
  xx[12] = - (xx[0] * (xx[6] - xx[7]));
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[6] = bb[0] ? xx[5] * xx[10] : xx[11];
  xx[7] = (xx[8] + state[4] * state[4]) * xx[0] - xx[9];
  xx[10] = - (xx[0] * (state[4] * state[5] - state[3] * state[6]));
  xx[7] = (xx[10] == 0.0 && xx[7] == 0.0) ? 0.0 : atan2(xx[10], xx[7]);
  xx[8] = bb[0] ? xx[4] * xx[6] : xx[7];
  xx[4] = origState[5] * origState[6];
  xx[7] = origState[3] * origState[4];
  xx[10] = origState[3] * origState[3];
  xx[11] = (xx[10] + origState[5] * origState[5]) * xx[0] - xx[9];
  xx[12] = (xx[4] + xx[7]) * xx[0];
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[12] = (xx[10] + origState[6] * origState[6]) * xx[0] - xx[9];
  xx[13] = - (xx[0] * (xx[4] - xx[7]));
  xx[12] = (xx[13] == 0.0 && xx[12] == 0.0) ? 0.0 : atan2(xx[13], xx[12]);
  xx[4] = bb[1] ? xx[5] * xx[11] : xx[12];
  xx[5] = (xx[10] + origState[4] * origState[4]) * xx[0] - xx[9];
  xx[7] = - (xx[0] * (origState[4] * origState[5] - origState[3] * origState[6]));
  xx[5] = (xx[7] == 0.0 && xx[5] == 0.0) ? 0.0 : atan2(xx[7], xx[5]);
  xx[0] = bb[1] ? xx[2] * xx[4] : xx[5];
  xx[9] = xx[8];
  xx[10] = xx[8];
  xx[11] = xx[8];
  xx[12] = xx[8];
  xx[13] = xx[0];
  xx[14] = xx[0];
  xx[15] = xx[0];
  xx[0] = xx[9 + (partialType)];
  xx[2] = cos(xx[0]);
  xx[5] = sin(xx[0]);
  xx[0] = sin(xx[1]);
  xx[7] = xx[6];
  xx[8] = xx[4];
  xx[9] = xx[6];
  xx[10] = xx[4];
  xx[11] = xx[6];
  xx[12] = xx[4];
  xx[13] = xx[6];
  xx[1] = xx[7 + (partialType)];
  xx[4] = cos(xx[1]);
  xx[6] = sin(xx[1]);
  xx[1] = xx[2] * xx[6];
  xx[7] = xx[4] * xx[2];
  xx[8] = xx[3] * xx[2];
  xx[9] = - (xx[3] * xx[5]);
  xx[10] = xx[0];
  xx[11] = xx[4] * xx[5] + xx[1] * xx[0];
  xx[12] = xx[7] - xx[6] * xx[0] * xx[5];
  xx[13] = - (xx[3] * xx[6]);
  xx[14] = xx[6] * xx[5] - xx[7] * xx[0];
  xx[15] = xx[1] + xx[4] * xx[0] * xx[5];
  xx[16] = xx[4] * xx[3];
  pm_math_Quaternion_Matrix3x3Ctor_ra(xx + 8, xx + 0);
  state[3] = xx[0];
  state[4] = xx[1];
  state[5] = xx[2];
  state[6] = xx[3];
}

static void projectPartiallyTargetedPos_9_3(const double *origState, int
  partialType, double *state)
{
  boolean_T bb[2];
  double xx[17];
  xx[0] = 2.0;
  xx[1] = (state[33] * state[35] + state[32] * state[34]) * xx[0];
  xx[2] = 0.99999999999999;
  bb[0] = fabs(xx[1]) > xx[2];
  xx[3] = 1.570796326794897;
  if (xx[1] < 0.0)
    xx[4] = -1.0;
  else if (xx[1] > 0.0)
    xx[4] = +1.0;
  else
    xx[4] = 0.0;
  xx[5] = fabs(xx[1]) > 1.0 ? atan2(xx[1], 0.0) : asin(xx[1]);
  xx[1] = bb[0] ? xx[3] * xx[4] : xx[5];
  xx[5] = (origState[33] * origState[35] + origState[32] * origState[34]) * xx[0];
  bb[1] = fabs(xx[5]) > xx[2];
  if (xx[5] < 0.0)
    xx[2] = -1.0;
  else if (xx[5] > 0.0)
    xx[2] = +1.0;
  else
    xx[2] = 0.0;
  xx[6] = fabs(xx[5]) > 1.0 ? atan2(xx[5], 0.0) : asin(xx[5]);
  xx[5] = bb[1] ? xx[3] * xx[2] : xx[6];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[5];
  xx[9] = xx[5];
  xx[10] = xx[1];
  xx[11] = xx[1];
  xx[12] = xx[5];
  xx[1] = xx[6 + (partialType)];
  xx[3] = cos(xx[1]);
  xx[5] = 0.5;
  xx[6] = state[34] * state[35];
  xx[7] = state[32] * state[33];
  xx[8] = state[32] * state[32];
  xx[9] = 1.0;
  xx[10] = (xx[8] + state[34] * state[34]) * xx[0] - xx[9];
  xx[11] = (xx[6] + xx[7]) * xx[0];
  xx[10] = (xx[11] == 0.0 && xx[10] == 0.0) ? 0.0 : atan2(xx[11], xx[10]);
  xx[11] = (xx[8] + state[35] * state[35]) * xx[0] - xx[9];
  xx[12] = - (xx[0] * (xx[6] - xx[7]));
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[6] = bb[0] ? xx[5] * xx[10] : xx[11];
  xx[7] = (xx[8] + state[33] * state[33]) * xx[0] - xx[9];
  xx[10] = - (xx[0] * (state[33] * state[34] - state[32] * state[35]));
  xx[7] = (xx[10] == 0.0 && xx[7] == 0.0) ? 0.0 : atan2(xx[10], xx[7]);
  xx[8] = bb[0] ? xx[4] * xx[6] : xx[7];
  xx[4] = origState[34] * origState[35];
  xx[7] = origState[32] * origState[33];
  xx[10] = origState[32] * origState[32];
  xx[11] = (xx[10] + origState[34] * origState[34]) * xx[0] - xx[9];
  xx[12] = (xx[4] + xx[7]) * xx[0];
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[12] = (xx[10] + origState[35] * origState[35]) * xx[0] - xx[9];
  xx[13] = - (xx[0] * (xx[4] - xx[7]));
  xx[12] = (xx[13] == 0.0 && xx[12] == 0.0) ? 0.0 : atan2(xx[13], xx[12]);
  xx[4] = bb[1] ? xx[5] * xx[11] : xx[12];
  xx[5] = (xx[10] + origState[33] * origState[33]) * xx[0] - xx[9];
  xx[7] = - (xx[0] * (origState[33] * origState[34] - origState[32] * origState
                      [35]));
  xx[5] = (xx[7] == 0.0 && xx[5] == 0.0) ? 0.0 : atan2(xx[7], xx[5]);
  xx[0] = bb[1] ? xx[2] * xx[4] : xx[5];
  xx[9] = xx[8];
  xx[10] = xx[8];
  xx[11] = xx[8];
  xx[12] = xx[8];
  xx[13] = xx[0];
  xx[14] = xx[0];
  xx[15] = xx[0];
  xx[0] = xx[9 + (partialType)];
  xx[2] = cos(xx[0]);
  xx[5] = sin(xx[0]);
  xx[0] = sin(xx[1]);
  xx[7] = xx[6];
  xx[8] = xx[4];
  xx[9] = xx[6];
  xx[10] = xx[4];
  xx[11] = xx[6];
  xx[12] = xx[4];
  xx[13] = xx[6];
  xx[1] = xx[7 + (partialType)];
  xx[4] = cos(xx[1]);
  xx[6] = sin(xx[1]);
  xx[1] = xx[2] * xx[6];
  xx[7] = xx[4] * xx[2];
  xx[8] = xx[3] * xx[2];
  xx[9] = - (xx[3] * xx[5]);
  xx[10] = xx[0];
  xx[11] = xx[4] * xx[5] + xx[1] * xx[0];
  xx[12] = xx[7] - xx[6] * xx[0] * xx[5];
  xx[13] = - (xx[3] * xx[6]);
  xx[14] = xx[6] * xx[5] - xx[7] * xx[0];
  xx[15] = xx[1] + xx[4] * xx[0] * xx[5];
  xx[16] = xx[4] * xx[3];
  pm_math_Quaternion_Matrix3x3Ctor_ra(xx + 8, xx + 0);
  state[32] = xx[0];
  state[33] = xx[1];
  state[34] = xx[2];
  state[35] = xx[3];
}

static void projectPartiallyTargetedPos_10_3(const double *origState, int
  partialType, double *state)
{
  boolean_T bb[2];
  double xx[17];
  xx[0] = 2.0;
  xx[1] = (state[46] * state[48] + state[45] * state[47]) * xx[0];
  xx[2] = 0.99999999999999;
  bb[0] = fabs(xx[1]) > xx[2];
  xx[3] = 1.570796326794897;
  if (xx[1] < 0.0)
    xx[4] = -1.0;
  else if (xx[1] > 0.0)
    xx[4] = +1.0;
  else
    xx[4] = 0.0;
  xx[5] = fabs(xx[1]) > 1.0 ? atan2(xx[1], 0.0) : asin(xx[1]);
  xx[1] = bb[0] ? xx[3] * xx[4] : xx[5];
  xx[5] = (origState[46] * origState[48] + origState[45] * origState[47]) * xx[0];
  bb[1] = fabs(xx[5]) > xx[2];
  if (xx[5] < 0.0)
    xx[2] = -1.0;
  else if (xx[5] > 0.0)
    xx[2] = +1.0;
  else
    xx[2] = 0.0;
  xx[6] = fabs(xx[5]) > 1.0 ? atan2(xx[5], 0.0) : asin(xx[5]);
  xx[5] = bb[1] ? xx[3] * xx[2] : xx[6];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[5];
  xx[9] = xx[5];
  xx[10] = xx[1];
  xx[11] = xx[1];
  xx[12] = xx[5];
  xx[1] = xx[6 + (partialType)];
  xx[3] = cos(xx[1]);
  xx[5] = 0.5;
  xx[6] = state[47] * state[48];
  xx[7] = state[45] * state[46];
  xx[8] = state[45] * state[45];
  xx[9] = 1.0;
  xx[10] = (xx[8] + state[47] * state[47]) * xx[0] - xx[9];
  xx[11] = (xx[6] + xx[7]) * xx[0];
  xx[10] = (xx[11] == 0.0 && xx[10] == 0.0) ? 0.0 : atan2(xx[11], xx[10]);
  xx[11] = (xx[8] + state[48] * state[48]) * xx[0] - xx[9];
  xx[12] = - (xx[0] * (xx[6] - xx[7]));
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[6] = bb[0] ? xx[5] * xx[10] : xx[11];
  xx[7] = (xx[8] + state[46] * state[46]) * xx[0] - xx[9];
  xx[10] = - (xx[0] * (state[46] * state[47] - state[45] * state[48]));
  xx[7] = (xx[10] == 0.0 && xx[7] == 0.0) ? 0.0 : atan2(xx[10], xx[7]);
  xx[8] = bb[0] ? xx[4] * xx[6] : xx[7];
  xx[4] = origState[47] * origState[48];
  xx[7] = origState[45] * origState[46];
  xx[10] = origState[45] * origState[45];
  xx[11] = (xx[10] + origState[47] * origState[47]) * xx[0] - xx[9];
  xx[12] = (xx[4] + xx[7]) * xx[0];
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[12] = (xx[10] + origState[48] * origState[48]) * xx[0] - xx[9];
  xx[13] = - (xx[0] * (xx[4] - xx[7]));
  xx[12] = (xx[13] == 0.0 && xx[12] == 0.0) ? 0.0 : atan2(xx[13], xx[12]);
  xx[4] = bb[1] ? xx[5] * xx[11] : xx[12];
  xx[5] = (xx[10] + origState[46] * origState[46]) * xx[0] - xx[9];
  xx[7] = - (xx[0] * (origState[46] * origState[47] - origState[45] * origState
                      [48]));
  xx[5] = (xx[7] == 0.0 && xx[5] == 0.0) ? 0.0 : atan2(xx[7], xx[5]);
  xx[0] = bb[1] ? xx[2] * xx[4] : xx[5];
  xx[9] = xx[8];
  xx[10] = xx[8];
  xx[11] = xx[8];
  xx[12] = xx[8];
  xx[13] = xx[0];
  xx[14] = xx[0];
  xx[15] = xx[0];
  xx[0] = xx[9 + (partialType)];
  xx[2] = cos(xx[0]);
  xx[5] = sin(xx[0]);
  xx[0] = sin(xx[1]);
  xx[7] = xx[6];
  xx[8] = xx[4];
  xx[9] = xx[6];
  xx[10] = xx[4];
  xx[11] = xx[6];
  xx[12] = xx[4];
  xx[13] = xx[6];
  xx[1] = xx[7 + (partialType)];
  xx[4] = cos(xx[1]);
  xx[6] = sin(xx[1]);
  xx[1] = xx[2] * xx[6];
  xx[7] = xx[4] * xx[2];
  xx[8] = xx[3] * xx[2];
  xx[9] = - (xx[3] * xx[5]);
  xx[10] = xx[0];
  xx[11] = xx[4] * xx[5] + xx[1] * xx[0];
  xx[12] = xx[7] - xx[6] * xx[0] * xx[5];
  xx[13] = - (xx[3] * xx[6]);
  xx[14] = xx[6] * xx[5] - xx[7] * xx[0];
  xx[15] = xx[1] + xx[4] * xx[0] * xx[5];
  xx[16] = xx[4] * xx[3];
  pm_math_Quaternion_Matrix3x3Ctor_ra(xx + 8, xx + 0);
  state[45] = xx[0];
  state[46] = xx[1];
  state[47] = xx[2];
  state[48] = xx[3];
}

static void projectPartiallyTargetedPos_11_3(const double *origState, int
  partialType, double *state)
{
  boolean_T bb[2];
  double xx[17];
  xx[0] = 2.0;
  xx[1] = (state[59] * state[61] + state[58] * state[60]) * xx[0];
  xx[2] = 0.99999999999999;
  bb[0] = fabs(xx[1]) > xx[2];
  xx[3] = 1.570796326794897;
  if (xx[1] < 0.0)
    xx[4] = -1.0;
  else if (xx[1] > 0.0)
    xx[4] = +1.0;
  else
    xx[4] = 0.0;
  xx[5] = fabs(xx[1]) > 1.0 ? atan2(xx[1], 0.0) : asin(xx[1]);
  xx[1] = bb[0] ? xx[3] * xx[4] : xx[5];
  xx[5] = (origState[59] * origState[61] + origState[58] * origState[60]) * xx[0];
  bb[1] = fabs(xx[5]) > xx[2];
  if (xx[5] < 0.0)
    xx[2] = -1.0;
  else if (xx[5] > 0.0)
    xx[2] = +1.0;
  else
    xx[2] = 0.0;
  xx[6] = fabs(xx[5]) > 1.0 ? atan2(xx[5], 0.0) : asin(xx[5]);
  xx[5] = bb[1] ? xx[3] * xx[2] : xx[6];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[5];
  xx[9] = xx[5];
  xx[10] = xx[1];
  xx[11] = xx[1];
  xx[12] = xx[5];
  xx[1] = xx[6 + (partialType)];
  xx[3] = cos(xx[1]);
  xx[5] = 0.5;
  xx[6] = state[60] * state[61];
  xx[7] = state[58] * state[59];
  xx[8] = state[58] * state[58];
  xx[9] = 1.0;
  xx[10] = (xx[8] + state[60] * state[60]) * xx[0] - xx[9];
  xx[11] = (xx[6] + xx[7]) * xx[0];
  xx[10] = (xx[11] == 0.0 && xx[10] == 0.0) ? 0.0 : atan2(xx[11], xx[10]);
  xx[11] = (xx[8] + state[61] * state[61]) * xx[0] - xx[9];
  xx[12] = - (xx[0] * (xx[6] - xx[7]));
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[6] = bb[0] ? xx[5] * xx[10] : xx[11];
  xx[7] = (xx[8] + state[59] * state[59]) * xx[0] - xx[9];
  xx[10] = - (xx[0] * (state[59] * state[60] - state[58] * state[61]));
  xx[7] = (xx[10] == 0.0 && xx[7] == 0.0) ? 0.0 : atan2(xx[10], xx[7]);
  xx[8] = bb[0] ? xx[4] * xx[6] : xx[7];
  xx[4] = origState[60] * origState[61];
  xx[7] = origState[58] * origState[59];
  xx[10] = origState[58] * origState[58];
  xx[11] = (xx[10] + origState[60] * origState[60]) * xx[0] - xx[9];
  xx[12] = (xx[4] + xx[7]) * xx[0];
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[12] = (xx[10] + origState[61] * origState[61]) * xx[0] - xx[9];
  xx[13] = - (xx[0] * (xx[4] - xx[7]));
  xx[12] = (xx[13] == 0.0 && xx[12] == 0.0) ? 0.0 : atan2(xx[13], xx[12]);
  xx[4] = bb[1] ? xx[5] * xx[11] : xx[12];
  xx[5] = (xx[10] + origState[59] * origState[59]) * xx[0] - xx[9];
  xx[7] = - (xx[0] * (origState[59] * origState[60] - origState[58] * origState
                      [61]));
  xx[5] = (xx[7] == 0.0 && xx[5] == 0.0) ? 0.0 : atan2(xx[7], xx[5]);
  xx[0] = bb[1] ? xx[2] * xx[4] : xx[5];
  xx[9] = xx[8];
  xx[10] = xx[8];
  xx[11] = xx[8];
  xx[12] = xx[8];
  xx[13] = xx[0];
  xx[14] = xx[0];
  xx[15] = xx[0];
  xx[0] = xx[9 + (partialType)];
  xx[2] = cos(xx[0]);
  xx[5] = sin(xx[0]);
  xx[0] = sin(xx[1]);
  xx[7] = xx[6];
  xx[8] = xx[4];
  xx[9] = xx[6];
  xx[10] = xx[4];
  xx[11] = xx[6];
  xx[12] = xx[4];
  xx[13] = xx[6];
  xx[1] = xx[7 + (partialType)];
  xx[4] = cos(xx[1]);
  xx[6] = sin(xx[1]);
  xx[1] = xx[2] * xx[6];
  xx[7] = xx[4] * xx[2];
  xx[8] = xx[3] * xx[2];
  xx[9] = - (xx[3] * xx[5]);
  xx[10] = xx[0];
  xx[11] = xx[4] * xx[5] + xx[1] * xx[0];
  xx[12] = xx[7] - xx[6] * xx[0] * xx[5];
  xx[13] = - (xx[3] * xx[6]);
  xx[14] = xx[6] * xx[5] - xx[7] * xx[0];
  xx[15] = xx[1] + xx[4] * xx[0] * xx[5];
  xx[16] = xx[4] * xx[3];
  pm_math_Quaternion_Matrix3x3Ctor_ra(xx + 8, xx + 0);
  state[58] = xx[0];
  state[59] = xx[1];
  state[60] = xx[2];
  state[61] = xx[3];
}

static void projectPartiallyTargetedPos_12_3(const double *origState, int
  partialType, double *state)
{
  boolean_T bb[2];
  double xx[17];
  xx[0] = 2.0;
  xx[1] = (state[72] * state[74] + state[71] * state[73]) * xx[0];
  xx[2] = 0.99999999999999;
  bb[0] = fabs(xx[1]) > xx[2];
  xx[3] = 1.570796326794897;
  if (xx[1] < 0.0)
    xx[4] = -1.0;
  else if (xx[1] > 0.0)
    xx[4] = +1.0;
  else
    xx[4] = 0.0;
  xx[5] = fabs(xx[1]) > 1.0 ? atan2(xx[1], 0.0) : asin(xx[1]);
  xx[1] = bb[0] ? xx[3] * xx[4] : xx[5];
  xx[5] = (origState[72] * origState[74] + origState[71] * origState[73]) * xx[0];
  bb[1] = fabs(xx[5]) > xx[2];
  if (xx[5] < 0.0)
    xx[2] = -1.0;
  else if (xx[5] > 0.0)
    xx[2] = +1.0;
  else
    xx[2] = 0.0;
  xx[6] = fabs(xx[5]) > 1.0 ? atan2(xx[5], 0.0) : asin(xx[5]);
  xx[5] = bb[1] ? xx[3] * xx[2] : xx[6];
  xx[6] = xx[1];
  xx[7] = xx[1];
  xx[8] = xx[5];
  xx[9] = xx[5];
  xx[10] = xx[1];
  xx[11] = xx[1];
  xx[12] = xx[5];
  xx[1] = xx[6 + (partialType)];
  xx[3] = cos(xx[1]);
  xx[5] = 0.5;
  xx[6] = state[73] * state[74];
  xx[7] = state[71] * state[72];
  xx[8] = state[71] * state[71];
  xx[9] = 1.0;
  xx[10] = (xx[8] + state[73] * state[73]) * xx[0] - xx[9];
  xx[11] = (xx[6] + xx[7]) * xx[0];
  xx[10] = (xx[11] == 0.0 && xx[10] == 0.0) ? 0.0 : atan2(xx[11], xx[10]);
  xx[11] = (xx[8] + state[74] * state[74]) * xx[0] - xx[9];
  xx[12] = - (xx[0] * (xx[6] - xx[7]));
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[6] = bb[0] ? xx[5] * xx[10] : xx[11];
  xx[7] = (xx[8] + state[72] * state[72]) * xx[0] - xx[9];
  xx[10] = - (xx[0] * (state[72] * state[73] - state[71] * state[74]));
  xx[7] = (xx[10] == 0.0 && xx[7] == 0.0) ? 0.0 : atan2(xx[10], xx[7]);
  xx[8] = bb[0] ? xx[4] * xx[6] : xx[7];
  xx[4] = origState[73] * origState[74];
  xx[7] = origState[71] * origState[72];
  xx[10] = origState[71] * origState[71];
  xx[11] = (xx[10] + origState[73] * origState[73]) * xx[0] - xx[9];
  xx[12] = (xx[4] + xx[7]) * xx[0];
  xx[11] = (xx[12] == 0.0 && xx[11] == 0.0) ? 0.0 : atan2(xx[12], xx[11]);
  xx[12] = (xx[10] + origState[74] * origState[74]) * xx[0] - xx[9];
  xx[13] = - (xx[0] * (xx[4] - xx[7]));
  xx[12] = (xx[13] == 0.0 && xx[12] == 0.0) ? 0.0 : atan2(xx[13], xx[12]);
  xx[4] = bb[1] ? xx[5] * xx[11] : xx[12];
  xx[5] = (xx[10] + origState[72] * origState[72]) * xx[0] - xx[9];
  xx[7] = - (xx[0] * (origState[72] * origState[73] - origState[71] * origState
                      [74]));
  xx[5] = (xx[7] == 0.0 && xx[5] == 0.0) ? 0.0 : atan2(xx[7], xx[5]);
  xx[0] = bb[1] ? xx[2] * xx[4] : xx[5];
  xx[9] = xx[8];
  xx[10] = xx[8];
  xx[11] = xx[8];
  xx[12] = xx[8];
  xx[13] = xx[0];
  xx[14] = xx[0];
  xx[15] = xx[0];
  xx[0] = xx[9 + (partialType)];
  xx[2] = cos(xx[0]);
  xx[5] = sin(xx[0]);
  xx[0] = sin(xx[1]);
  xx[7] = xx[6];
  xx[8] = xx[4];
  xx[9] = xx[6];
  xx[10] = xx[4];
  xx[11] = xx[6];
  xx[12] = xx[4];
  xx[13] = xx[6];
  xx[1] = xx[7 + (partialType)];
  xx[4] = cos(xx[1]);
  xx[6] = sin(xx[1]);
  xx[1] = xx[2] * xx[6];
  xx[7] = xx[4] * xx[2];
  xx[8] = xx[3] * xx[2];
  xx[9] = - (xx[3] * xx[5]);
  xx[10] = xx[0];
  xx[11] = xx[4] * xx[5] + xx[1] * xx[0];
  xx[12] = xx[7] - xx[6] * xx[0] * xx[5];
  xx[13] = - (xx[3] * xx[6]);
  xx[14] = xx[6] * xx[5] - xx[7] * xx[0];
  xx[15] = xx[1] + xx[4] * xx[0] * xx[5];
  xx[16] = xx[4] * xx[3];
  pm_math_Quaternion_Matrix3x3Ctor_ra(xx + 8, xx + 0);
  state[71] = xx[0];
  state[72] = xx[1];
  state[73] = xx[2];
  state[74] = xx[3];
}

void modeloMK4_funcional_4ef989e3_1_projectPartiallyTargetedPos(const void *mech,
  size_t stageIdx, size_t primIdx, const double *origState, int partialType,
  double *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) origState;
  (void) partialType;
  (void) state;
  switch ((stageIdx * 6 + primIdx))
  {
   case 3:
    projectPartiallyTargetedPos_0_3(origState, partialType, state);
    break;

   case 57:
    projectPartiallyTargetedPos_9_3(origState, partialType, state);
    break;

   case 63:
    projectPartiallyTargetedPos_10_3(origState, partialType, state);
    break;

   case 69:
    projectPartiallyTargetedPos_11_3(origState, partialType, state);
    break;

   case 75:
    projectPartiallyTargetedPos_12_3(origState, partialType, state);
    break;
  }
}

void modeloMK4_funcional_4ef989e3_1_propagateMotion(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, const double *state, double *motionData)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[136];
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  xx[0] = 0.7071067811865476;
  xx[1] = 7.677004418860416e-5;
  xx[2] = 0.9999999970531803;
  xx[3] = xx[1] * state[3] - xx[2] * state[6];
  xx[4] = xx[0] * xx[3];
  xx[5] = xx[2] * state[5] + xx[1] * state[4];
  xx[6] = xx[5] * xx[0];
  xx[7] = xx[4] + xx[6];
  xx[8] = xx[4] - xx[6];
  xx[4] = xx[2] * state[3] + xx[1] * state[6];
  xx[6] = xx[0] * xx[4];
  xx[9] = xx[1] * state[5] - xx[2] * state[4];
  xx[10] = xx[0] * xx[9];
  xx[11] = - (xx[6] + xx[10]);
  xx[12] = xx[6] - xx[10];
  xx[6] = 2.0;
  xx[13] = xx[9];
  xx[14] = - xx[5];
  xx[15] = xx[3];
  xx[10] = 0.01000140224955159;
  xx[16] = xx[10] * xx[3];
  xx[17] = 1.535616198867715e-6;
  xx[18] = xx[17] * xx[3];
  xx[3] = xx[5] * xx[17] - xx[10] * xx[9];
  xx[19] = xx[16];
  xx[20] = xx[18];
  xx[21] = xx[3];
  pm_math_Vector3_cross_ra(xx + 13, xx + 19, xx + 22);
  xx[5] = state[0] - xx[6] * (xx[22] - xx[16] * xx[4]) - xx[17];
  xx[9] = 0.5000000000000001;
  xx[13] = xx[5] * xx[9];
  xx[14] = state[1] - (xx[23] - xx[18] * xx[4]) * xx[6] + xx[10];
  xx[15] = 1.414213562373095;
  xx[16] = state[2] - (xx[24] - xx[3] * xx[4]) * xx[6];
  xx[3] = xx[15] * (xx[0] * xx[16] + xx[14] * xx[0]);
  xx[4] = 0.5;
  xx[18] = xx[4] * state[13];
  xx[19] = cos(xx[18]);
  xx[20] = sin(xx[18]);
  xx[18] = xx[2] * xx[19] + xx[1] * xx[20];
  xx[21] = 0.0;
  xx[22] = xx[2] * xx[20] - xx[1] * xx[19];
  xx[19] = 0.0420000244423599;
  xx[20] = 0.02895432697472309;
  xx[23] = xx[20] * xx[22];
  xx[24] = - (xx[19] + xx[6] * xx[18] * xx[23]);
  xx[25] = 1.559676967993742e-4;
  xx[26] = xx[25] - (xx[20] - xx[6] * xx[23] * xx[22]);
  xx[23] = 0.03000000000000002;
  xx[27] = - xx[23];
  xx[28] = xx[4] * state[15];
  xx[29] = cos(xx[28]);
  xx[30] = sin(xx[28]);
  xx[28] = 0.02284321658378476;
  xx[31] = xx[28] * xx[29];
  xx[32] = - (xx[6] * xx[31] * xx[30]);
  xx[33] = 0.02304567302527694;
  xx[34] = - (xx[33] + xx[6] * xx[29] * xx[31] - xx[28]);
  xx[31] = 0.013;
  xx[35] = 0.02299999999999999;
  xx[36] = xx[31] - ((xx[29] * xx[35] * xx[29] + xx[35] * xx[30] * xx[30]) * xx
                     [6] - xx[35]);
  xx[35] = xx[4] * state[17];
  xx[37] = cos(xx[35]);
  xx[38] = sin(xx[35]);
  xx[35] = xx[2] * xx[37] + xx[1] * xx[38];
  xx[39] = xx[2] * xx[38] - xx[1] * xx[37];
  xx[37] = 0.04200000799315259;
  xx[38] = xx[20] * xx[39];
  xx[40] = xx[37] - xx[6] * xx[35] * xx[38];
  xx[41] = 4.883471714082711e-5;
  xx[42] = - (xx[41] + xx[20] - xx[6] * xx[38] * xx[39]);
  xx[38] = - 0.03;
  xx[43] = xx[4] * state[19];
  xx[44] = cos(xx[43]);
  xx[45] = sin(xx[43]);
  xx[43] = 0.02284321658378478;
  xx[46] = xx[43] * xx[44];
  xx[47] = - (xx[6] * xx[46] * xx[45]);
  xx[48] = - (xx[33] + xx[6] * xx[44] * xx[46] - xx[43]);
  xx[33] = 0.023;
  xx[46] = xx[31] - ((xx[44] * xx[33] * xx[44] + xx[33] * xx[45] * xx[45]) * xx
                     [6] - xx[33]);
  xx[31] = xx[4] * state[21];
  xx[33] = cos(xx[31]);
  xx[49] = sin(xx[31]);
  xx[31] = xx[2] * xx[33] + xx[1] * xx[49];
  xx[50] = xx[2] * xx[49] - xx[1] * xx[33];
  xx[33] = 0.02895432697472306;
  xx[49] = xx[33] * xx[50];
  xx[51] = - (xx[19] + xx[6] * xx[31] * xx[49]);
  xx[19] = xx[25] - (xx[33] - xx[6] * xx[49] * xx[50]);
  xx[25] = 0.03000000000000003;
  xx[49] = xx[4] * state[23];
  xx[52] = cos(xx[49]);
  xx[53] = sin(xx[49]);
  xx[49] = 0.0228432165837848;
  xx[54] = xx[49] * xx[52];
  xx[55] = - (xx[6] * xx[54] * xx[53]);
  xx[56] = 0.02304567302527693;
  xx[57] = - (xx[56] + xx[6] * xx[52] * xx[54] - xx[49]);
  xx[54] = 0.013;
  xx[58] = 2.999999999999993e-3;
  xx[59] = xx[54] - ((xx[52] * xx[58] * xx[52] + xx[58] * xx[53] * xx[53]) * xx
                     [6] - xx[58]);
  xx[60] = xx[4] * state[25];
  xx[61] = cos(xx[60]);
  xx[62] = sin(xx[60]);
  xx[60] = xx[2] * xx[61] + xx[1] * xx[62];
  xx[63] = xx[2] * xx[62] - xx[1] * xx[61];
  xx[61] = 0.02895432697472308;
  xx[62] = xx[61] * xx[63];
  xx[64] = xx[37] - xx[6] * xx[60] * xx[62];
  xx[37] = - (xx[41] + xx[61] - xx[6] * xx[62] * xx[63]);
  xx[41] = xx[4] * state[27];
  xx[4] = cos(xx[41]);
  xx[62] = sin(xx[41]);
  xx[41] = 0.02284321658378479;
  xx[65] = xx[41] * xx[4];
  xx[66] = - (xx[6] * xx[65] * xx[62]);
  xx[67] = - (xx[56] + xx[6] * xx[4] * xx[65] - xx[41]);
  xx[56] = xx[54] - ((xx[4] * xx[58] * xx[4] + xx[58] * xx[62] * xx[62]) * xx[6]
                     - xx[58]);
  xx[54] = - state[32];
  xx[58] = - state[33];
  xx[65] = - state[34];
  xx[68] = - state[35];
  xx[69] = - state[45];
  xx[70] = - state[46];
  xx[71] = - state[47];
  xx[72] = - state[48];
  xx[73] = - state[58];
  xx[74] = - state[59];
  xx[75] = - state[60];
  xx[76] = - state[61];
  xx[77] = - state[71];
  xx[78] = - state[72];
  xx[79] = - state[73];
  xx[80] = - state[74];
  xx[81] = xx[1] * state[11];
  xx[82] = xx[1] * state[10];
  xx[83] = state[10] - (xx[2] * xx[81] + xx[1] * xx[82]) * xx[6];
  xx[84] = state[11] + xx[6] * (xx[2] * xx[82] - xx[1] * xx[81]);
  xx[85] = xx[7];
  xx[86] = xx[8];
  xx[87] = xx[11];
  xx[88] = xx[12];
  xx[1] = xx[9] * state[7];
  xx[2] = xx[15] * (xx[0] * state[9] + xx[0] * state[8]);
  xx[89] = state[7] - (xx[1] + xx[1]) * xx[6];
  xx[90] = state[8] - xx[2];
  xx[91] = state[9] - xx[2];
  pm_math_Quaternion_inverseXform_ra(xx + 85, xx + 89, xx + 0);
  xx[9] = xx[0] - xx[10] * state[12];
  xx[15] = xx[1] - xx[17] * state[12];
  xx[0] = xx[2] + xx[10] * xx[83] + xx[84] * xx[17];
  xx[1] = xx[84] * xx[22];
  xx[2] = xx[22] * xx[83];
  xx[10] = xx[83] - xx[6] * (xx[18] * xx[1] + xx[2] * xx[22]);
  xx[17] = xx[84] - (xx[1] * xx[22] - xx[18] * xx[2]) * xx[6];
  xx[1] = state[12] - state[14];
  xx[85] = xx[83];
  xx[86] = xx[84];
  xx[87] = state[12];
  xx[88] = xx[24];
  xx[89] = xx[26];
  xx[90] = xx[27];
  pm_math_Vector3_cross_ra(xx + 85, xx + 88, xx + 91);
  xx[2] = xx[91] + xx[9];
  xx[81] = xx[92] + xx[15];
  xx[82] = xx[81] * xx[22];
  xx[88] = xx[2] * xx[22];
  xx[89] = xx[2] - xx[6] * (xx[18] * xx[82] + xx[88] * xx[22]) - xx[20] * state
    [14];
  xx[2] = xx[81] - (xx[82] * xx[22] - xx[18] * xx[88]) * xx[6];
  xx[81] = xx[93] + xx[0];
  xx[82] = xx[29] * xx[17] + xx[10] * xx[30];
  xx[90] = xx[10];
  xx[91] = xx[17];
  xx[92] = xx[1];
  xx[93] = xx[32];
  xx[94] = xx[34];
  xx[95] = xx[36];
  pm_math_Vector3_cross_ra(xx + 90, xx + 93, xx + 96);
  xx[88] = xx[96] + xx[89];
  xx[90] = xx[97] + xx[2];
  xx[91] = xx[90] * xx[29] + xx[88] * xx[30];
  xx[92] = xx[98] + xx[81];
  xx[93] = xx[84] * xx[39];
  xx[94] = xx[39] * xx[83];
  xx[95] = xx[83] - xx[6] * (xx[35] * xx[93] + xx[94] * xx[39]);
  xx[96] = xx[84] - (xx[93] * xx[39] - xx[35] * xx[94]) * xx[6];
  xx[93] = state[12] - state[18];
  xx[97] = xx[40];
  xx[98] = xx[42];
  xx[99] = xx[38];
  pm_math_Vector3_cross_ra(xx + 85, xx + 97, xx + 100);
  xx[94] = xx[100] + xx[9];
  xx[97] = xx[101] + xx[15];
  xx[98] = xx[97] * xx[39];
  xx[99] = xx[94] * xx[39];
  xx[103] = xx[94] - xx[6] * (xx[35] * xx[98] + xx[99] * xx[39]) - xx[20] *
    state[18];
  xx[20] = xx[97] - (xx[98] * xx[39] - xx[35] * xx[99]) * xx[6];
  xx[94] = xx[102] + xx[0];
  xx[97] = xx[44] * xx[96] + xx[95] * xx[45];
  xx[98] = xx[95];
  xx[99] = xx[96];
  xx[100] = xx[93];
  xx[104] = xx[47];
  xx[105] = xx[48];
  xx[106] = xx[46];
  pm_math_Vector3_cross_ra(xx + 98, xx + 104, xx + 107);
  xx[98] = xx[107] + xx[103];
  xx[99] = xx[108] + xx[20];
  xx[100] = xx[99] * xx[44] + xx[98] * xx[45];
  xx[101] = xx[109] + xx[94];
  xx[102] = xx[84] * xx[50];
  xx[104] = xx[50] * xx[83];
  xx[105] = xx[83] - xx[6] * (xx[31] * xx[102] + xx[104] * xx[50]);
  xx[106] = xx[84] - (xx[102] * xx[50] - xx[31] * xx[104]) * xx[6];
  xx[102] = state[12] - state[22];
  xx[107] = xx[51];
  xx[108] = xx[19];
  xx[109] = xx[25];
  pm_math_Vector3_cross_ra(xx + 85, xx + 107, xx + 110);
  xx[104] = xx[110] + xx[9];
  xx[107] = xx[111] + xx[15];
  xx[108] = xx[107] * xx[50];
  xx[109] = xx[104] * xx[50];
  xx[113] = xx[104] - xx[6] * (xx[31] * xx[108] + xx[109] * xx[50]) - xx[33] *
    state[22];
  xx[33] = xx[107] - (xx[108] * xx[50] - xx[31] * xx[109]) * xx[6];
  xx[104] = xx[112] + xx[0];
  xx[107] = xx[52] * xx[106] + xx[105] * xx[53];
  xx[108] = xx[105];
  xx[109] = xx[106];
  xx[110] = xx[102];
  xx[114] = xx[55];
  xx[115] = xx[57];
  xx[116] = xx[59];
  pm_math_Vector3_cross_ra(xx + 108, xx + 114, xx + 117);
  xx[108] = xx[117] + xx[113];
  xx[109] = xx[118] + xx[33];
  xx[110] = xx[109] * xx[52] + xx[108] * xx[53];
  xx[111] = xx[119] + xx[104];
  xx[112] = xx[84] * xx[63];
  xx[114] = xx[63] * xx[83];
  xx[115] = xx[83] - xx[6] * (xx[60] * xx[112] + xx[114] * xx[63]);
  xx[116] = xx[84] - (xx[112] * xx[63] - xx[60] * xx[114]) * xx[6];
  xx[112] = state[12] - state[26];
  xx[117] = xx[64];
  xx[118] = xx[37];
  xx[119] = xx[23];
  pm_math_Vector3_cross_ra(xx + 85, xx + 117, xx + 120);
  xx[85] = xx[120] + xx[9];
  xx[86] = xx[121] + xx[15];
  xx[87] = xx[86] * xx[63];
  xx[114] = xx[85] * xx[63];
  xx[117] = xx[85] - xx[6] * (xx[60] * xx[87] + xx[114] * xx[63]) - xx[61] *
    state[26];
  xx[61] = xx[86] - (xx[87] * xx[63] - xx[60] * xx[114]) * xx[6];
  xx[85] = xx[122] + xx[0];
  xx[86] = xx[4] * xx[116] + xx[115] * xx[62];
  xx[118] = xx[115];
  xx[119] = xx[116];
  xx[120] = xx[112];
  xx[121] = xx[66];
  xx[122] = xx[67];
  xx[123] = xx[56];
  pm_math_Vector3_cross_ra(xx + 118, xx + 121, xx + 124);
  xx[87] = xx[124] + xx[117];
  xx[114] = xx[125] + xx[61];
  xx[118] = xx[114] * xx[4] + xx[87] * xx[62];
  xx[119] = xx[126] + xx[85];
  xx[120] = xx[54];
  xx[121] = xx[58];
  xx[122] = xx[65];
  xx[123] = xx[68];
  xx[124] = state[36];
  xx[125] = state[37];
  xx[126] = state[38];
  pm_math_Quaternion_inverseXform_ra(xx + 120, xx + 124, xx + 127);
  xx[120] = state[49];
  xx[121] = state[50];
  xx[122] = state[51];
  pm_math_Quaternion_inverseXform_ra(xx + 69, xx + 120, xx + 123);
  xx[120] = state[62];
  xx[121] = state[63];
  xx[122] = state[64];
  pm_math_Quaternion_inverseXform_ra(xx + 73, xx + 120, xx + 130);
  xx[120] = state[75];
  xx[121] = state[76];
  xx[122] = state[77];
  pm_math_Quaternion_inverseXform_ra(xx + 77, xx + 120, xx + 133);
  motionData[0] = xx[7];
  motionData[1] = xx[8];
  motionData[2] = xx[11];
  motionData[3] = xx[12];
  motionData[4] = xx[5] - (xx[13] + xx[13]) * xx[6] + 0.06370113964882761;
  motionData[5] = xx[14] - xx[3] + 0.02757152586923429;
  motionData[6] = xx[16] - xx[3] - 0.02944846882862407;
  motionData[7] = - xx[18];
  motionData[8] = xx[21];
  motionData[9] = xx[21];
  motionData[10] = xx[22];
  motionData[11] = xx[24];
  motionData[12] = xx[26];
  motionData[13] = xx[27];
  motionData[14] = xx[21];
  motionData[15] = - xx[29];
  motionData[16] = xx[30];
  motionData[17] = xx[21];
  motionData[18] = xx[32];
  motionData[19] = xx[34];
  motionData[20] = xx[36];
  motionData[21] = - xx[35];
  motionData[22] = xx[21];
  motionData[23] = xx[21];
  motionData[24] = xx[39];
  motionData[25] = xx[40];
  motionData[26] = xx[42];
  motionData[27] = xx[38];
  motionData[28] = xx[21];
  motionData[29] = - xx[44];
  motionData[30] = xx[45];
  motionData[31] = xx[21];
  motionData[32] = xx[47];
  motionData[33] = xx[48];
  motionData[34] = xx[46];
  motionData[35] = - xx[31];
  motionData[36] = xx[21];
  motionData[37] = xx[21];
  motionData[38] = xx[50];
  motionData[39] = xx[51];
  motionData[40] = xx[19];
  motionData[41] = xx[25];
  motionData[42] = xx[21];
  motionData[43] = - xx[52];
  motionData[44] = xx[53];
  motionData[45] = xx[21];
  motionData[46] = xx[55];
  motionData[47] = xx[57];
  motionData[48] = xx[59];
  motionData[49] = - xx[60];
  motionData[50] = xx[21];
  motionData[51] = xx[21];
  motionData[52] = xx[63];
  motionData[53] = xx[64];
  motionData[54] = xx[37];
  motionData[55] = xx[23];
  motionData[56] = xx[21];
  motionData[57] = - xx[4];
  motionData[58] = xx[62];
  motionData[59] = xx[21];
  motionData[60] = xx[66];
  motionData[61] = xx[67];
  motionData[62] = xx[56];
  motionData[63] = xx[54];
  motionData[64] = xx[58];
  motionData[65] = xx[65];
  motionData[66] = xx[68];
  motionData[67] = state[29];
  motionData[68] = state[30];
  motionData[69] = state[31];
  motionData[70] = xx[69];
  motionData[71] = xx[70];
  motionData[72] = xx[71];
  motionData[73] = xx[72];
  motionData[74] = state[42];
  motionData[75] = state[43];
  motionData[76] = state[44];
  motionData[77] = xx[73];
  motionData[78] = xx[74];
  motionData[79] = xx[75];
  motionData[80] = xx[76];
  motionData[81] = state[55];
  motionData[82] = state[56];
  motionData[83] = state[57];
  motionData[84] = xx[77];
  motionData[85] = xx[78];
  motionData[86] = xx[79];
  motionData[87] = xx[80];
  motionData[88] = state[68];
  motionData[89] = state[69];
  motionData[90] = state[70];
  motionData[91] = xx[83];
  motionData[92] = xx[84];
  motionData[93] = state[12];
  motionData[94] = xx[9];
  motionData[95] = xx[15];
  motionData[96] = xx[0];
  motionData[97] = xx[10];
  motionData[98] = xx[17];
  motionData[99] = xx[1];
  motionData[100] = xx[89];
  motionData[101] = xx[2];
  motionData[102] = xx[81];
  motionData[103] = xx[10] - xx[6] * xx[82] * xx[30];
  motionData[104] = xx[17] - xx[6] * xx[82] * xx[29];
  motionData[105] = xx[1] - (xx[29] * xx[29] * xx[1] + xx[30] * xx[1] * xx[30]) *
    xx[6] + state[16];
  motionData[106] = xx[88] - xx[6] * xx[91] * xx[30] - xx[28] * state[16];
  motionData[107] = xx[90] - xx[6] * xx[91] * xx[29];
  motionData[108] = xx[92] - (xx[29] * xx[92] * xx[29] + xx[92] * xx[30] * xx[30])
    * xx[6];
  motionData[109] = xx[95];
  motionData[110] = xx[96];
  motionData[111] = xx[93];
  motionData[112] = xx[103];
  motionData[113] = xx[20];
  motionData[114] = xx[94];
  motionData[115] = xx[95] - xx[6] * xx[97] * xx[45];
  motionData[116] = xx[96] - xx[6] * xx[97] * xx[44];
  motionData[117] = xx[93] - (xx[44] * xx[44] * xx[93] + xx[45] * xx[93] * xx[45])
    * xx[6] + state[20];
  motionData[118] = xx[98] - xx[6] * xx[100] * xx[45] - xx[43] * state[20];
  motionData[119] = xx[99] - xx[6] * xx[100] * xx[44];
  motionData[120] = xx[101] - (xx[44] * xx[101] * xx[44] + xx[101] * xx[45] *
    xx[45]) * xx[6];
  motionData[121] = xx[105];
  motionData[122] = xx[106];
  motionData[123] = xx[102];
  motionData[124] = xx[113];
  motionData[125] = xx[33];
  motionData[126] = xx[104];
  motionData[127] = xx[105] - xx[6] * xx[107] * xx[53];
  motionData[128] = xx[106] - xx[6] * xx[107] * xx[52];
  motionData[129] = xx[102] - (xx[52] * xx[52] * xx[102] + xx[53] * xx[102] *
    xx[53]) * xx[6] + state[24];
  motionData[130] = xx[108] - xx[6] * xx[110] * xx[53] - xx[49] * state[24];
  motionData[131] = xx[109] - xx[6] * xx[110] * xx[52];
  motionData[132] = xx[111] - (xx[52] * xx[111] * xx[52] + xx[111] * xx[53] *
    xx[53]) * xx[6];
  motionData[133] = xx[115];
  motionData[134] = xx[116];
  motionData[135] = xx[112];
  motionData[136] = xx[117];
  motionData[137] = xx[61];
  motionData[138] = xx[85];
  motionData[139] = xx[115] - xx[6] * xx[86] * xx[62];
  motionData[140] = xx[116] - xx[6] * xx[86] * xx[4];
  motionData[141] = xx[112] - (xx[4] * xx[4] * xx[112] + xx[62] * xx[112] * xx
    [62]) * xx[6] + state[28];
  motionData[142] = xx[87] - xx[6] * xx[118] * xx[62] - xx[41] * state[28];
  motionData[143] = xx[114] - xx[6] * xx[118] * xx[4];
  motionData[144] = xx[119] - (xx[4] * xx[119] * xx[4] + xx[119] * xx[62] * xx
    [62]) * xx[6];
  motionData[145] = state[39];
  motionData[146] = state[40];
  motionData[147] = state[41];
  motionData[148] = xx[127];
  motionData[149] = xx[128];
  motionData[150] = xx[129];
  motionData[151] = state[52];
  motionData[152] = state[53];
  motionData[153] = state[54];
  motionData[154] = xx[123];
  motionData[155] = xx[124];
  motionData[156] = xx[125];
  motionData[157] = state[65];
  motionData[158] = state[66];
  motionData[159] = state[67];
  motionData[160] = xx[130];
  motionData[161] = xx[131];
  motionData[162] = xx[132];
  motionData[163] = state[78];
  motionData[164] = state[79];
  motionData[165] = state[80];
  motionData[166] = xx[133];
  motionData[167] = xx[134];
  motionData[168] = xx[135];
}

size_t modeloMK4_funcional_4ef989e3_1_computeAssemblyError(const void *mech,
  const RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx, const int
  *modeVector, const double *motionData, double *error)
{
  (void) mech;
  (void)rtdv;
  (void) modeVector;
  (void) motionData;
  (void) error;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t modeloMK4_funcional_4ef989e3_1_computeAssemblyJacobian(const void *mech,
  const RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx, boolean_T
  forVelocitySatisfaction, const double *state, const int *modeVector, const
  double *motionData, double *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) modeVector;
  (void) forVelocitySatisfaction;
  (void) motionData;
  (void) J;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t modeloMK4_funcional_4ef989e3_1_computeFullAssemblyJacobian(const void
  *mech, const RuntimeDerivedValuesBundle *rtdv, const double *state, const int *
  modeVector, const double *motionData, double *J)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
  (void) modeVector;
  (void) motionData;
  (void) J;
  return 0;
}

boolean_T modeloMK4_funcional_4ef989e3_1_isInKinematicSingularity(const void
  *mech, const RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx, const int
  *modeVector, const double *motionData)
{
  (void) mech;
  (void) rtdv;
  (void) modeVector;
  (void) motionData;
  switch (constraintIdx)
  {
  }

  return 0;
}

void modeloMK4_funcional_4ef989e3_1_convertStateVector(const void *asmMech,
  const RuntimeDerivedValuesBundle *rtdv, const void *simMech, const double
  *asmState, const int *asmModeVector, const int *simModeVector, double
  *simState)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[31];
  (void) asmMech;
  (void) rtdvd;
  (void) rtdvi;
  (void) simMech;
  (void) asmModeVector;
  (void) simModeVector;
  xx[0] = - asmState[32];
  xx[1] = - asmState[33];
  xx[2] = - asmState[34];
  xx[3] = - asmState[35];
  xx[4] = asmState[36];
  xx[5] = asmState[37];
  xx[6] = asmState[38];
  pm_math_Quaternion_inverseXform_ra(xx + 0, xx + 4, xx + 7);
  pm_math_Quaternion_xform_ra(xx + 0, xx + 7, xx + 4);
  xx[7] = - asmState[45];
  xx[8] = - asmState[46];
  xx[9] = - asmState[47];
  xx[10] = - asmState[48];
  xx[11] = asmState[49];
  xx[12] = asmState[50];
  xx[13] = asmState[51];
  pm_math_Quaternion_inverseXform_ra(xx + 7, xx + 11, xx + 14);
  pm_math_Quaternion_xform_ra(xx + 7, xx + 14, xx + 11);
  xx[14] = - asmState[58];
  xx[15] = - asmState[59];
  xx[16] = - asmState[60];
  xx[17] = - asmState[61];
  xx[18] = asmState[62];
  xx[19] = asmState[63];
  xx[20] = asmState[64];
  pm_math_Quaternion_inverseXform_ra(xx + 14, xx + 18, xx + 21);
  pm_math_Quaternion_xform_ra(xx + 14, xx + 21, xx + 18);
  xx[21] = - asmState[71];
  xx[22] = - asmState[72];
  xx[23] = - asmState[73];
  xx[24] = - asmState[74];
  xx[25] = asmState[75];
  xx[26] = asmState[76];
  xx[27] = asmState[77];
  pm_math_Quaternion_inverseXform_ra(xx + 21, xx + 25, xx + 28);
  pm_math_Quaternion_xform_ra(xx + 21, xx + 28, xx + 25);
  simState[0] = asmState[0];
  simState[1] = asmState[1];
  simState[2] = asmState[2];
  simState[3] = asmState[3];
  simState[4] = asmState[4];
  simState[5] = asmState[5];
  simState[6] = asmState[6];
  simState[7] = asmState[7];
  simState[8] = asmState[8];
  simState[9] = asmState[9];
  simState[10] = asmState[10];
  simState[11] = asmState[11];
  simState[12] = asmState[12];
  simState[13] = asmState[13];
  simState[14] = asmState[14];
  simState[15] = asmState[15];
  simState[16] = asmState[16];
  simState[17] = asmState[17];
  simState[18] = asmState[18];
  simState[19] = asmState[19];
  simState[20] = asmState[20];
  simState[21] = asmState[21];
  simState[22] = asmState[22];
  simState[23] = asmState[23];
  simState[24] = asmState[24];
  simState[25] = asmState[25];
  simState[26] = asmState[26];
  simState[27] = asmState[27];
  simState[28] = asmState[28];
  simState[29] = asmState[29];
  simState[30] = asmState[30];
  simState[31] = asmState[31];
  simState[32] = xx[0];
  simState[33] = xx[1];
  simState[34] = xx[2];
  simState[35] = xx[3];
  simState[36] = xx[4];
  simState[37] = xx[5];
  simState[38] = xx[6];
  simState[39] = asmState[39];
  simState[40] = asmState[40];
  simState[41] = asmState[41];
  simState[42] = asmState[42];
  simState[43] = asmState[43];
  simState[44] = asmState[44];
  simState[45] = xx[7];
  simState[46] = xx[8];
  simState[47] = xx[9];
  simState[48] = xx[10];
  simState[49] = xx[11];
  simState[50] = xx[12];
  simState[51] = xx[13];
  simState[52] = asmState[52];
  simState[53] = asmState[53];
  simState[54] = asmState[54];
  simState[55] = asmState[55];
  simState[56] = asmState[56];
  simState[57] = asmState[57];
  simState[58] = xx[14];
  simState[59] = xx[15];
  simState[60] = xx[16];
  simState[61] = xx[17];
  simState[62] = xx[18];
  simState[63] = xx[19];
  simState[64] = xx[20];
  simState[65] = asmState[65];
  simState[66] = asmState[66];
  simState[67] = asmState[67];
  simState[68] = asmState[68];
  simState[69] = asmState[69];
  simState[70] = asmState[70];
  simState[71] = xx[21];
  simState[72] = xx[22];
  simState[73] = xx[23];
  simState[74] = xx[24];
  simState[75] = xx[25];
  simState[76] = xx[26];
  simState[77] = xx[27];
  simState[78] = asmState[78];
  simState[79] = asmState[79];
  simState[80] = asmState[80];
}
