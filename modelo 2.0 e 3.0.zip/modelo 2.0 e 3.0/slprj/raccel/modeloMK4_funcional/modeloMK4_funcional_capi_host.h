
    #ifndef RTW_HEADER_modeloMK4_funcional_cap_host_h__
    #define RTW_HEADER_modeloMK4_funcional_cap_host_h__

    #ifdef HOST_CAPI_BUILD

    #include "rtw_capi.h"
        #include "rtw_modelmap_simtarget.h"


    typedef struct  {
    rtwCAPI_ModelMappingInfo mmi;
    } modeloMK4_funcional_host_DataMapInfo_T;

    #ifdef __cplusplus
    extern "C" {
        #endif

        void modeloMK4_funcional_host_InitializeDataMapInfo(modeloMK4_funcional_host_DataMapInfo_T *dataMap, const char *path);

        #ifdef __cplusplus
    }
    #endif

    #endif /* HOST_CAPI_BUILD */

    #endif /* RTW_HEADER_modeloMK4_funcional_cap_host_h__ */

    /* EOF: modeloMK4_funcional_capi_host.h */
