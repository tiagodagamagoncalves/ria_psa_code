/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'modeloMK4_funcional/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

void modeloMK4_funcional_4ef989e3_1_computeRuntimeParameters(const real_T t0[],
  real_T out[])
{
  real_T t10[1];
  real_T t11[1];
  real_T t12[1];
  real_T t13[1];
  real_T t14[1];
  real_T t15[1];
  real_T t16[1];
  real_T t17[1];
  real_T t7[1];
  real_T t28;
  real_T t29;
  real_T t30;
  real_T t31;
  real_T t32;
  real_T t33;
  real_T t34;
  real_T t35;
  t12[0ULL] = t0[0ULL];
  t16[0ULL] = t0[1ULL];
  t17[0ULL] = t0[2ULL];
  t13[0ULL] = t0[3ULL];
  t15[0ULL] = t0[4ULL];
  t7[0ULL] = t0[5ULL];
  t11[0ULL] = t0[6ULL];
  t14[0ULL] = t0[7ULL];
  memcpy(&t10[0], &t11[0], 8U);
  memcpy(&t11[0], &t12[0], 8U);
  memcpy(&t12[0], &t13[0], 8U);
  memcpy(&t13[0], &t14[0], 8U);
  memcpy(&t14[0], &t15[0], 8U);
  memcpy(&t15[0], &t16[0], 8U);
  memcpy(&t16[0], &t17[0], 8U);
  memcpy(&t17[0], &t7[0], 8U);
  t28 = t10[0ULL];
  t29 = t11[0ULL];
  t30 = t12[0ULL];
  t31 = t13[0ULL];
  t32 = t14[0ULL];
  t33 = t15[0ULL];
  t34 = t16[0ULL];
  t35 = t17[0ULL];
  out[0] = t28;
  out[1] = t29;
  out[2] = t30;
  out[3] = t31;
  out[4] = t32;
  out[5] = t33;
  out[6] = t34;
  out[7] = t35;
}

void modeloMK4_funcional_4ef989e3_1_computeAsmRuntimeDerivedValuesDoubles(const
  double *rtp, double *rtdvd)
{
  (void) rtp;
  (void) rtdvd;
}

void modeloMK4_funcional_4ef989e3_1_computeAsmRuntimeDerivedValuesInts(const
  double *rtp, int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void modeloMK4_funcional_4ef989e3_1_computeAsmRuntimeDerivedValues(const double *
  rtp, RuntimeDerivedValuesBundle *rtdv)
{
  modeloMK4_funcional_4ef989e3_1_computeAsmRuntimeDerivedValuesDoubles(rtp,
    rtdv->mDoubles.mValues);
  modeloMK4_funcional_4ef989e3_1_computeAsmRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}

void modeloMK4_funcional_4ef989e3_1_computeSimRuntimeDerivedValuesDoubles(const
  double *rtp, double *rtdvd)
{
  (void) rtp;
  (void) rtdvd;
}

void modeloMK4_funcional_4ef989e3_1_computeSimRuntimeDerivedValuesInts(const
  double *rtp, int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void modeloMK4_funcional_4ef989e3_1_computeSimRuntimeDerivedValues(const double *
  rtp, RuntimeDerivedValuesBundle *rtdv)
{
  modeloMK4_funcional_4ef989e3_1_computeSimRuntimeDerivedValuesDoubles(rtp,
    rtdv->mDoubles.mValues);
  modeloMK4_funcional_4ef989e3_1_computeSimRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}
