/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'modeloMK4_funcional/Solver Configuration'.
 */

const sm_core_compiler_Brick *modeloMK4_funcional_4ef989e3_1_geometry_0(const
  RuntimeDerivedValuesBundle *rtdv);
const sm_core_compiler_Plane *modeloMK4_funcional_4ef989e3_1_geometry_1(const
  RuntimeDerivedValuesBundle *rtdv);
const sm_core_compiler_Sphere *modeloMK4_funcional_4ef989e3_1_geometry_2(const
  RuntimeDerivedValuesBundle *rtdv);
struct RuntimeDerivedValuesBundleTag;
void modeloMK4_funcional_4ef989e3_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
