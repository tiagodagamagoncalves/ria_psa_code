/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'modeloMK4_funcional/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "modeloMK4_funcional_4ef989e3_1_geometries.h"

PmfMessageId modeloMK4_funcional_4ef989e3_1_recordLog(const
  RuntimeDerivedValuesBundle *rtdv, const int *eqnEnableFlags, const double
  *state, const int *modeVector, const double *input, const double *inputDot,
  const double *inputDdot, double *logVector, double *errorResult,
  NeuDiagnosticManager *neDiagMgr)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  boolean_T bb[1];
  int ii[1];
  double xx[405];
  (void) rtdvd;
  (void) rtdvi;
  (void) eqnEnableFlags;
  (void) modeVector;
  (void) input;
  (void) inputDot;
  (void) neDiagMgr;
  xx[0] = 57.29577951308232;
  xx[1] = 0.7071067811865476;
  xx[2] = 0.9999999970531803;
  xx[3] = 7.677004418860416e-5;
  xx[4] = xx[2] * state[3] + xx[3] * state[6];
  xx[5] = xx[1] * xx[4];
  xx[6] = xx[3] * state[5] - xx[2] * state[4];
  xx[7] = xx[1] * xx[6];
  xx[8] = xx[5] + xx[7];
  xx[9] = xx[8] * xx[8];
  xx[10] = xx[5] - xx[7];
  xx[5] = xx[10] * xx[10];
  xx[7] = 2.0;
  xx[11] = 1.0;
  xx[12] = (xx[9] + xx[5]) * xx[7] - xx[11];
  xx[13] = xx[3] * state[3] - xx[2] * state[6];
  xx[14] = xx[1] * xx[13];
  xx[15] = xx[2] * state[5] + xx[3] * state[4];
  xx[16] = xx[15] * xx[1];
  xx[17] = xx[14] + xx[16];
  xx[18] = xx[17] * xx[10];
  xx[19] = xx[14] - xx[16];
  xx[14] = xx[19] * xx[8];
  xx[16] = (xx[18] + xx[14]) * xx[7];
  xx[20] = xx[8] * xx[17];
  xx[21] = xx[19] * xx[10];
  xx[22] = xx[7] * (xx[20] - xx[21]);
  xx[23] = xx[12];
  xx[24] = xx[16];
  xx[25] = xx[22];
  xx[26] = 0.1354557519189488;
  xx[27] = 0.01797123889803847;
  xx[28] = 0.01671460183660255;
  xx[29] = 0.5;
  xx[30] = xx[29] * state[27];
  xx[31] = cos(xx[30]);
  xx[32] = xx[7] * xx[31] * xx[31] - xx[11];
  xx[33] = xx[28] * xx[32];
  xx[34] = sin(xx[30]);
  xx[30] = xx[7] * xx[31] * xx[34];
  xx[35] = xx[28] * xx[30];
  xx[36] = xx[35] * xx[30];
  xx[37] = xx[33] * xx[32] + xx[36];
  xx[38] = xx[27] + xx[37];
  xx[39] = xx[29] * state[25];
  xx[40] = cos(xx[39]);
  xx[41] = sin(xx[39]);
  xx[39] = xx[2] * xx[40] + xx[3] * xx[41];
  xx[42] = xx[39] * xx[39];
  xx[43] = xx[7] * xx[42] - xx[11];
  xx[44] = xx[7] * xx[34] * xx[34] - xx[11];
  xx[45] = xx[28] * xx[44];
  xx[46] = xx[35] * xx[32] + xx[45] * xx[30];
  xx[47] = xx[2] * xx[41] - xx[3] * xx[40];
  xx[40] = xx[7] * xx[39] * xx[47];
  xx[41] = xx[38] * xx[43] - xx[46] * xx[40];
  xx[48] = xx[33] * xx[30] + xx[35] * xx[44];
  xx[33] = xx[36] + xx[45] * xx[44];
  xx[35] = xx[27] + xx[33];
  xx[36] = xx[48] * xx[43] - xx[35] * xx[40];
  xx[45] = xx[41] * xx[43] - xx[36] * xx[40];
  xx[49] = xx[29] * state[23];
  xx[50] = cos(xx[49]);
  xx[51] = xx[7] * xx[50] * xx[50] - xx[11];
  xx[52] = xx[28] * xx[51];
  xx[53] = sin(xx[49]);
  xx[49] = xx[7] * xx[50] * xx[53];
  xx[54] = xx[28] * xx[49];
  xx[55] = xx[54] * xx[49];
  xx[56] = xx[52] * xx[51] + xx[55];
  xx[57] = xx[27] + xx[56];
  xx[58] = xx[29] * state[21];
  xx[59] = cos(xx[58]);
  xx[60] = sin(xx[58]);
  xx[58] = xx[2] * xx[59] + xx[3] * xx[60];
  xx[61] = xx[58] * xx[58];
  xx[62] = xx[7] * xx[61] - xx[11];
  xx[63] = xx[7] * xx[53] * xx[53] - xx[11];
  xx[64] = xx[28] * xx[63];
  xx[65] = xx[54] * xx[51] + xx[64] * xx[49];
  xx[66] = xx[2] * xx[60] - xx[3] * xx[59];
  xx[59] = xx[7] * xx[58] * xx[66];
  xx[60] = xx[57] * xx[62] - xx[65] * xx[59];
  xx[67] = xx[52] * xx[49] + xx[54] * xx[63];
  xx[52] = xx[55] + xx[64] * xx[63];
  xx[54] = xx[27] + xx[52];
  xx[55] = xx[67] * xx[62] - xx[54] * xx[59];
  xx[64] = xx[60] * xx[62] - xx[55] * xx[59];
  xx[68] = xx[29] * state[19];
  xx[69] = cos(xx[68]);
  xx[70] = xx[7] * xx[69] * xx[69] - xx[11];
  xx[71] = xx[28] * xx[70];
  xx[72] = sin(xx[68]);
  xx[68] = xx[7] * xx[69] * xx[72];
  xx[73] = xx[28] * xx[68];
  xx[74] = xx[73] * xx[68];
  xx[75] = xx[71] * xx[70] + xx[74];
  xx[76] = xx[27] + xx[75];
  xx[77] = xx[29] * state[17];
  xx[78] = cos(xx[77]);
  xx[79] = sin(xx[77]);
  xx[77] = xx[2] * xx[78] + xx[3] * xx[79];
  xx[80] = xx[77] * xx[77];
  xx[81] = xx[7] * xx[80] - xx[11];
  xx[82] = xx[7] * xx[72] * xx[72] - xx[11];
  xx[83] = xx[28] * xx[82];
  xx[84] = xx[73] * xx[70] + xx[83] * xx[68];
  xx[85] = xx[2] * xx[79] - xx[3] * xx[78];
  xx[78] = xx[7] * xx[77] * xx[85];
  xx[79] = xx[76] * xx[81] - xx[84] * xx[78];
  xx[86] = xx[71] * xx[68] + xx[73] * xx[82];
  xx[71] = xx[74] + xx[83] * xx[82];
  xx[73] = xx[27] + xx[71];
  xx[74] = xx[86] * xx[81] - xx[73] * xx[78];
  xx[83] = xx[79] * xx[81] - xx[74] * xx[78];
  xx[87] = xx[29] * state[15];
  xx[88] = cos(xx[87]);
  xx[89] = xx[7] * xx[88] * xx[88] - xx[11];
  xx[90] = xx[28] * xx[89];
  xx[91] = sin(xx[87]);
  xx[87] = xx[7] * xx[88] * xx[91];
  xx[92] = xx[28] * xx[87];
  xx[93] = xx[92] * xx[87];
  xx[94] = xx[90] * xx[89] + xx[93];
  xx[95] = xx[27] + xx[94];
  xx[96] = xx[29] * state[13];
  xx[29] = cos(xx[96]);
  xx[97] = sin(xx[96]);
  xx[96] = xx[2] * xx[29] + xx[3] * xx[97];
  xx[98] = xx[96] * xx[96];
  xx[99] = xx[7] * xx[98] - xx[11];
  xx[100] = xx[7] * xx[91] * xx[91] - xx[11];
  xx[101] = xx[28] * xx[100];
  xx[102] = xx[92] * xx[89] + xx[101] * xx[87];
  xx[103] = xx[2] * xx[97] - xx[3] * xx[29];
  xx[29] = xx[7] * xx[96] * xx[103];
  xx[97] = xx[95] * xx[99] - xx[102] * xx[29];
  xx[104] = xx[90] * xx[87] + xx[92] * xx[100];
  xx[90] = xx[93] + xx[101] * xx[100];
  xx[92] = xx[27] + xx[90];
  xx[27] = xx[104] * xx[99] - xx[92] * xx[29];
  xx[93] = xx[97] * xx[99] - xx[27] * xx[29];
  xx[101] = xx[26] + xx[45] + xx[64] + xx[83] + xx[93];
  xx[105] = xx[35] * xx[43] + xx[48] * xx[40];
  xx[106] = xx[38] * xx[40] + xx[46] * xx[43];
  xx[107] = xx[40] * xx[105] - xx[106] * xx[43];
  xx[108] = xx[54] * xx[62] + xx[67] * xx[59];
  xx[109] = xx[57] * xx[59] + xx[65] * xx[62];
  xx[110] = xx[59] * xx[108] - xx[109] * xx[62];
  xx[111] = xx[73] * xx[81] + xx[86] * xx[78];
  xx[112] = xx[76] * xx[78] + xx[84] * xx[81];
  xx[113] = xx[78] * xx[111] - xx[112] * xx[81];
  xx[114] = xx[92] * xx[99] + xx[104] * xx[29];
  xx[115] = xx[95] * xx[29] + xx[102] * xx[99];
  xx[116] = xx[29] * xx[114] - xx[115] * xx[99];
  xx[117] = xx[107] + xx[110] + xx[113] + xx[116];
  xx[118] = xx[101] * xx[12] + xx[117] * xx[16];
  xx[119] = xx[40] * xx[106] + xx[105] * xx[43];
  xx[105] = xx[59] * xx[109] + xx[108] * xx[62];
  xx[106] = xx[78] * xx[112] + xx[111] * xx[81];
  xx[108] = xx[29] * xx[115] + xx[114] * xx[99];
  xx[109] = xx[26] + xx[119] + xx[105] + xx[106] + xx[108];
  xx[111] = xx[41] * xx[40] + xx[36] * xx[43];
  xx[36] = xx[60] * xx[59] + xx[55] * xx[62];
  xx[41] = xx[79] * xx[78] + xx[74] * xx[81];
  xx[55] = xx[97] * xx[29] + xx[27] * xx[99];
  xx[27] = xx[111] + xx[36] + xx[41] + xx[55];
  xx[60] = xx[109] * xx[16] - xx[27] * xx[12];
  xx[74] = 0.03468584073464102;
  xx[79] = (xx[42] + xx[47] * xx[47]) * xx[7] - xx[11];
  xx[42] = xx[74] * xx[79] * xx[79];
  xx[97] = (xx[61] + xx[66] * xx[66]) * xx[7] - xx[11];
  xx[61] = xx[74] * xx[97] * xx[97];
  xx[112] = (xx[80] + xx[85] * xx[85]) * xx[7] - xx[11];
  xx[80] = xx[74] * xx[112] * xx[112];
  xx[114] = (xx[98] + xx[103] * xx[103]) * xx[7] - xx[11];
  xx[98] = xx[74] * xx[114] * xx[114];
  xx[115] = xx[26] + xx[42] + xx[61] + xx[80] + xx[98];
  xx[26] = xx[115] * xx[22];
  xx[120] = xx[118];
  xx[121] = xx[60];
  xx[122] = xx[26];
  xx[123] = xx[8] * xx[10];
  xx[124] = xx[19] * xx[17];
  xx[125] = xx[7] * (xx[123] - xx[124]);
  xx[126] = (xx[20] + xx[21]) * xx[7];
  xx[20] = xx[117] * xx[125] - xx[101] * xx[126];
  xx[21] = xx[109] * xx[125] + xx[27] * xx[126];
  xx[127] = xx[19] * xx[19];
  xx[128] = (xx[127] + xx[9]) * xx[7] - xx[11];
  xx[9] = xx[115] * xx[128];
  xx[129] = xx[20];
  xx[130] = xx[21];
  xx[131] = xx[9];
  xx[132] = pm_math_Vector3_dot_ra(xx + 23, xx + 129);
  xx[133] = xx[7] * (xx[14] - xx[18]);
  xx[14] = (xx[5] + xx[127]) * xx[7] - xx[11];
  xx[5] = xx[101] * xx[133] + xx[117] * xx[14];
  xx[11] = xx[109] * xx[14] - xx[27] * xx[133];
  xx[18] = (xx[124] + xx[123]) * xx[7];
  xx[123] = xx[115] * xx[18];
  xx[134] = xx[5];
  xx[135] = xx[11];
  xx[136] = xx[123];
  xx[124] = pm_math_Vector3_dot_ra(xx + 23, xx + 134);
  xx[127] = 0.013;
  xx[137] = 2.999999999999993e-3;
  xx[138] = xx[127] - ((xx[31] * xx[137] * xx[31] + xx[137] * xx[34] * xx[34]) *
                       xx[7] - xx[137]);
  xx[139] = xx[46] * xx[138];
  xx[140] = xx[33] * xx[138];
  xx[141] = xx[139] * xx[43] - xx[140] * xx[40];
  xx[142] = xx[37] * xx[138];
  xx[143] = xx[48] * xx[138];
  xx[144] = xx[142] * xx[43] - xx[143] * xx[40];
  xx[145] = xx[141] * xx[43] + xx[144] * xx[40];
  xx[146] = 0.03000000000000002;
  xx[147] = xx[146] * xx[107];
  xx[148] = xx[127] - ((xx[50] * xx[137] * xx[50] + xx[137] * xx[53] * xx[53]) *
                       xx[7] - xx[137]);
  xx[127] = xx[65] * xx[148];
  xx[137] = xx[52] * xx[148];
  xx[149] = xx[127] * xx[62] - xx[137] * xx[59];
  xx[150] = xx[56] * xx[148];
  xx[151] = xx[67] * xx[148];
  xx[152] = xx[150] * xx[62] - xx[151] * xx[59];
  xx[153] = xx[149] * xx[62] + xx[152] * xx[59];
  xx[154] = 0.03000000000000003;
  xx[155] = xx[154] * xx[110];
  xx[156] = 0.013;
  xx[157] = 0.023;
  xx[158] = xx[156] - ((xx[69] * xx[157] * xx[69] + xx[157] * xx[72] * xx[72]) *
                       xx[7] - xx[157]);
  xx[157] = xx[84] * xx[158];
  xx[159] = xx[71] * xx[158];
  xx[160] = xx[157] * xx[81] - xx[159] * xx[78];
  xx[161] = xx[75] * xx[158];
  xx[162] = xx[86] * xx[158];
  xx[163] = xx[161] * xx[81] - xx[162] * xx[78];
  xx[164] = xx[160] * xx[81] + xx[163] * xx[78];
  xx[165] = 0.03;
  xx[166] = xx[165] * xx[113];
  xx[167] = 0.02299999999999999;
  xx[168] = xx[156] - ((xx[88] * xx[167] * xx[88] + xx[167] * xx[91] * xx[91]) *
                       xx[7] - xx[167]);
  xx[156] = xx[102] * xx[168];
  xx[167] = xx[90] * xx[168];
  xx[169] = xx[156] * xx[99] - xx[167] * xx[29];
  xx[170] = xx[94] * xx[168];
  xx[171] = xx[104] * xx[168];
  xx[172] = xx[170] * xx[99] - xx[171] * xx[29];
  xx[173] = xx[169] * xx[99] + xx[172] * xx[29];
  xx[174] = xx[146] * xx[116];
  xx[175] = xx[145] - xx[147] + xx[153] - xx[155] + xx[164] + xx[166] + xx[173]
    + xx[174];
  xx[176] = 0.9999999882127206;
  xx[177] = xx[144] * xx[43] - xx[141] * xx[40];
  xx[141] = xx[45] * xx[146];
  xx[144] = xx[152] * xx[62] - xx[149] * xx[59];
  xx[149] = xx[64] * xx[154];
  xx[152] = xx[163] * xx[81] - xx[160] * xx[78];
  xx[160] = xx[83] * xx[165];
  xx[163] = xx[172] * xx[99] - xx[169] * xx[29];
  xx[169] = xx[93] * xx[146];
  xx[172] = xx[177] + xx[141] + xx[144] + xx[149] + xx[152] - xx[160] + xx[163]
    - xx[169];
  xx[178] = 1.535400879247534e-4;
  xx[179] = xx[175] * xx[176] + xx[172] * xx[178];
  xx[180] = xx[106] * xx[165];
  xx[181] = xx[157] * xx[78] + xx[159] * xx[81];
  xx[182] = xx[161] * xx[78] + xx[162] * xx[81];
  xx[183] = xx[81] * xx[181] + xx[78] * xx[182];
  xx[184] = xx[139] * xx[40] + xx[140] * xx[43];
  xx[185] = xx[142] * xx[40] + xx[143] * xx[43];
  xx[186] = xx[43] * xx[184] + xx[40] * xx[185];
  xx[187] = xx[119] * xx[146];
  xx[188] = xx[127] * xx[59] + xx[137] * xx[62];
  xx[189] = xx[150] * xx[59] + xx[151] * xx[62];
  xx[190] = xx[62] * xx[188] + xx[59] * xx[189];
  xx[191] = xx[105] * xx[154];
  xx[192] = xx[108] * xx[146];
  xx[193] = xx[156] * xx[29] + xx[167] * xx[99];
  xx[194] = xx[170] * xx[29] + xx[171] * xx[99];
  xx[195] = xx[99] * xx[193] + xx[29] * xx[194];
  xx[196] = xx[180] - xx[183] - (xx[186] + xx[187] + xx[190] + xx[191]) + xx[192]
    - xx[195];
  xx[197] = xx[40] * xx[184] - xx[43] * xx[185];
  xx[184] = xx[146] * xx[111];
  xx[185] = xx[59] * xx[188] - xx[62] * xx[189];
  xx[188] = xx[154] * xx[36];
  xx[189] = xx[78] * xx[181] - xx[81] * xx[182];
  xx[181] = xx[165] * xx[41];
  xx[182] = xx[29] * xx[193] - xx[99] * xx[194];
  xx[193] = xx[146] * xx[55];
  xx[194] = xx[197] - xx[184] + xx[185] - xx[188] + xx[189] + xx[181] + xx[182]
    + xx[193];
  xx[198] = xx[196] * xx[176] + xx[194] * xx[178];
  xx[199] = 0.02284321658378479;
  xx[200] = xx[199] * xx[31];
  xx[201] = xx[7] * xx[200] * xx[34];
  xx[202] = xx[28] * xx[201];
  xx[203] = xx[202] * xx[79];
  xx[204] = 0.02304567302527693;
  xx[205] = xx[204] + xx[7] * xx[31] * xx[200] - xx[199];
  xx[200] = xx[28] * xx[205];
  xx[206] = xx[200] * xx[79];
  xx[207] = xx[40] * xx[203] - xx[206] * xx[43];
  xx[208] = 4.883471714082711e-5;
  xx[209] = 0.02895432697472308;
  xx[210] = xx[209] * xx[47];
  xx[211] = xx[208] + xx[209] - xx[7] * xx[210] * xx[47];
  xx[212] = xx[42] * xx[211];
  xx[213] = 0.0228432165837848;
  xx[214] = xx[213] * xx[50];
  xx[215] = xx[7] * xx[214] * xx[53];
  xx[216] = xx[28] * xx[215];
  xx[217] = xx[216] * xx[97];
  xx[218] = xx[204] + xx[7] * xx[50] * xx[214] - xx[213];
  xx[204] = xx[28] * xx[218];
  xx[214] = xx[204] * xx[97];
  xx[219] = xx[59] * xx[217] - xx[214] * xx[62];
  xx[220] = 1.559676967993742e-4;
  xx[221] = 0.02895432697472306;
  xx[222] = xx[221] * xx[66];
  xx[223] = xx[220] - (xx[221] - xx[7] * xx[222] * xx[66]);
  xx[224] = xx[61] * xx[223];
  xx[225] = 0.02284321658378478;
  xx[226] = xx[225] * xx[69];
  xx[227] = xx[7] * xx[226] * xx[72];
  xx[228] = xx[28] * xx[227];
  xx[229] = xx[228] * xx[112];
  xx[230] = 0.02304567302527694;
  xx[231] = xx[230] + xx[7] * xx[69] * xx[226] - xx[225];
  xx[226] = xx[28] * xx[231];
  xx[232] = xx[226] * xx[112];
  xx[233] = xx[78] * xx[229] - xx[232] * xx[81];
  xx[234] = 0.02895432697472309;
  xx[235] = xx[234] * xx[85];
  xx[236] = xx[208] + xx[234] - xx[7] * xx[235] * xx[85];
  xx[208] = xx[80] * xx[236];
  xx[237] = 0.02284321658378476;
  xx[238] = xx[237] * xx[88];
  xx[239] = xx[7] * xx[238] * xx[91];
  xx[240] = xx[28] * xx[239];
  xx[241] = xx[240] * xx[114];
  xx[242] = xx[230] + xx[7] * xx[88] * xx[238] - xx[237];
  xx[230] = xx[28] * xx[242];
  xx[238] = xx[230] * xx[114];
  xx[243] = xx[29] * xx[241] - xx[238] * xx[99];
  xx[244] = xx[234] * xx[103];
  xx[245] = xx[220] - (xx[234] - xx[7] * xx[244] * xx[103]);
  xx[220] = xx[98] * xx[245];
  xx[246] = xx[207] - xx[212] + xx[219] + xx[224] + xx[233] - xx[208] + xx[243]
    + xx[220];
  xx[247] = xx[40] * xx[206] + xx[203] * xx[43];
  xx[203] = 0.04200000799315259;
  xx[206] = xx[203] - xx[7] * xx[39] * xx[210];
  xx[210] = xx[206] * xx[42];
  xx[42] = xx[59] * xx[214] + xx[217] * xx[62];
  xx[214] = 0.0420000244423599;
  xx[217] = xx[214] + xx[7] * xx[58] * xx[222];
  xx[222] = xx[217] * xx[61];
  xx[61] = xx[78] * xx[232] + xx[229] * xx[81];
  xx[229] = xx[203] - xx[7] * xx[77] * xx[235];
  xx[203] = xx[229] * xx[80];
  xx[80] = xx[29] * xx[238] + xx[241] * xx[99];
  xx[232] = xx[214] + xx[7] * xx[96] * xx[244];
  xx[214] = xx[232] * xx[98];
  xx[98] = xx[247] - xx[210] + xx[42] + xx[222] + xx[61] - xx[203] + xx[80] +
    xx[214];
  xx[235] = 0.01000140236744092;
  xx[238] = xx[246] * xx[176] + xx[98] * xx[178] + xx[115] * xx[235];
  xx[248] = xx[179];
  xx[249] = xx[198];
  xx[250] = xx[238];
  xx[241] = pm_math_Vector3_dot_ra(xx + 23, xx + 248);
  xx[244] = xx[172] * xx[176] - xx[175] * xx[178];
  xx[251] = xx[194] * xx[176] - xx[196] * xx[178];
  xx[252] = xx[98] * xx[176] - xx[246] * xx[178];
  xx[253] = xx[244];
  xx[254] = xx[251];
  xx[255] = xx[252];
  xx[256] = pm_math_Vector3_dot_ra(xx + 23, xx + 253);
  xx[257] = 0.01000140224955159;
  xx[258] = 1.535616198867715e-6;
  xx[259] = xx[48] * xx[205] + xx[33] * xx[201];
  xx[33] = xx[37] * xx[205] + xx[46] * xx[201];
  xx[37] = (xx[259] * xx[43] + xx[33] * xx[40]) * xx[79];
  xx[260] = xx[111] * xx[211] - xx[206] * xx[119];
  xx[111] = xx[67] * xx[218] + xx[52] * xx[215];
  xx[52] = xx[56] * xx[218] + xx[65] * xx[215];
  xx[56] = (xx[111] * xx[62] + xx[52] * xx[59]) * xx[97];
  xx[119] = xx[105] * xx[217] - xx[223] * xx[36];
  xx[36] = xx[86] * xx[231] + xx[71] * xx[227];
  xx[71] = xx[75] * xx[231] + xx[84] * xx[227];
  xx[75] = (xx[36] * xx[81] + xx[71] * xx[78]) * xx[112];
  xx[105] = xx[41] * xx[236] - xx[229] * xx[106];
  xx[41] = xx[104] * xx[242] + xx[90] * xx[239];
  xx[90] = xx[94] * xx[242] + xx[102] * xx[239];
  xx[94] = (xx[41] * xx[99] + xx[90] * xx[29]) * xx[114];
  xx[106] = xx[108] * xx[232] - xx[245] * xx[55];
  xx[55] = xx[37] + xx[260] + xx[56] + xx[119] + xx[75] + xx[105] + xx[94] + xx
    [106];
  xx[108] = xx[27] * xx[257] - xx[109] * xx[258] - xx[55];
  xx[261] = (xx[259] * xx[40] - xx[33] * xx[43]) * xx[79];
  xx[262] = xx[45] * xx[211] + xx[206] * xx[107];
  xx[45] = (xx[111] * xx[59] - xx[52] * xx[62]) * xx[97];
  xx[107] = xx[64] * xx[223] + xx[217] * xx[110];
  xx[64] = (xx[36] * xx[78] - xx[71] * xx[81]) * xx[112];
  xx[110] = xx[83] * xx[236] + xx[229] * xx[113];
  xx[83] = (xx[41] * xx[29] - xx[90] * xx[99]) * xx[114];
  xx[113] = xx[93] * xx[245] + xx[232] * xx[116];
  xx[93] = xx[261] - xx[262] + xx[45] + xx[107] + xx[64] - xx[110] + xx[83] +
    xx[113];
  xx[116] = xx[101] * xx[257] + xx[117] * xx[258] + xx[93];
  xx[263] = xx[108] * xx[16] - xx[12] * xx[116];
  xx[264] = - xx[126];
  xx[265] = xx[125];
  xx[266] = xx[128];
  xx[267] = pm_math_Vector3_dot_ra(xx + 264, xx + 134);
  xx[268] = pm_math_Vector3_dot_ra(xx + 264, xx + 248);
  xx[269] = pm_math_Vector3_dot_ra(xx + 264, xx + 253);
  xx[270] = xx[108] * xx[125] + xx[126] * xx[116];
  xx[271] = xx[133];
  xx[272] = xx[14];
  xx[273] = xx[18];
  xx[274] = pm_math_Vector3_dot_ra(xx + 271, xx + 248);
  xx[248] = pm_math_Vector3_dot_ra(xx + 271, xx + 253);
  xx[249] = xx[108] * xx[14] - xx[133] * xx[116];
  xx[250] = 7.558260253012845e-6;
  xx[253] = 6.888775484766295e-6;
  xx[254] = xx[253] * xx[32];
  xx[255] = 1.045837943450455e-6;
  xx[275] = xx[255] * xx[30];
  xx[276] = xx[250] + xx[254] * xx[32] + xx[275] * xx[30] + xx[200] * xx[205] +
    xx[140] * xx[138];
  xx[277] = xx[253] * xx[30];
  xx[278] = xx[255] * xx[44];
  xx[279] = xx[277] * xx[32] + xx[278] * xx[30] + xx[202] * xx[205] - xx[143] *
    xx[138];
  xx[32] = xx[276] * xx[43] - xx[279] * xx[40];
  xx[280] = xx[254] * xx[30] + xx[275] * xx[44] + xx[200] * xx[201] - xx[139] *
    xx[138];
  xx[254] = 1.162181591388395e-6;
  xx[275] = xx[254] + xx[277] * xx[30] + xx[278] * xx[44] + xx[142] * xx[138] +
    xx[202] * xx[201];
  xx[30] = xx[280] * xx[43] - xx[275] * xx[40];
  xx[44] = xx[207] * xx[211] - xx[146] * xx[186];
  xx[277] = 6.888775484766298e-6;
  xx[278] = xx[277] * xx[51];
  xx[281] = xx[255] * xx[49];
  xx[282] = xx[250] + xx[278] * xx[51] + xx[281] * xx[49] + xx[204] * xx[218] +
    xx[137] * xx[148];
  xx[283] = xx[277] * xx[49];
  xx[284] = xx[255] * xx[63];
  xx[285] = xx[283] * xx[51] + xx[284] * xx[49] + xx[216] * xx[218] - xx[151] *
    xx[148];
  xx[51] = xx[282] * xx[62] - xx[285] * xx[59];
  xx[286] = xx[278] * xx[49] + xx[281] * xx[63] + xx[204] * xx[215] - xx[127] *
    xx[148];
  xx[278] = xx[254] + xx[283] * xx[49] + xx[284] * xx[63] + xx[150] * xx[148] +
    xx[216] * xx[215];
  xx[49] = xx[286] * xx[62] - xx[278] * xx[59];
  xx[63] = xx[154] * xx[190] + xx[219] * xx[223];
  xx[281] = 6.888775484766296e-6;
  xx[283] = xx[281] * xx[70];
  xx[284] = 1.045837943450455e-6;
  xx[287] = xx[284] * xx[68];
  xx[288] = xx[250] + xx[283] * xx[70] + xx[287] * xx[68] + xx[226] * xx[231] +
    xx[159] * xx[158];
  xx[289] = xx[281] * xx[68];
  xx[290] = xx[284] * xx[82];
  xx[291] = xx[289] * xx[70] + xx[290] * xx[68] + xx[228] * xx[231] - xx[162] *
    xx[158];
  xx[70] = xx[288] * xx[81] - xx[291] * xx[78];
  xx[292] = xx[283] * xx[68] + xx[287] * xx[82] + xx[226] * xx[227] - xx[157] *
    xx[158];
  xx[283] = xx[254] + xx[289] * xx[68] + xx[290] * xx[82] + xx[161] * xx[158] +
    xx[228] * xx[227];
  xx[68] = xx[292] * xx[81] - xx[283] * xx[78];
  xx[82] = xx[165] * xx[183] + xx[233] * xx[236];
  xx[287] = xx[281] * xx[89];
  xx[289] = xx[284] * xx[87];
  xx[290] = xx[250] + xx[287] * xx[89] + xx[289] * xx[87] + xx[230] * xx[242] +
    xx[167] * xx[168];
  xx[293] = xx[281] * xx[87];
  xx[294] = xx[284] * xx[100];
  xx[295] = xx[293] * xx[89] + xx[294] * xx[87] + xx[240] * xx[242] - xx[171] *
    xx[168];
  xx[89] = xx[290] * xx[99] - xx[295] * xx[29];
  xx[296] = xx[287] * xx[87] + xx[289] * xx[100] + xx[230] * xx[239] - xx[156] *
    xx[168];
  xx[287] = xx[254] + xx[293] * xx[87] + xx[294] * xx[100] + xx[170] * xx[168] +
    xx[240] * xx[239];
  xx[87] = xx[296] * xx[99] - xx[287] * xx[29];
  xx[100] = xx[146] * xx[195] - xx[243] * xx[245];
  xx[289] = 3.197120586509093e-5;
  xx[293] = xx[32] * xx[43] - xx[30] * xx[40] - xx[44] - xx[44] + xx[212] * xx
    [211] + xx[146] * xx[187] + xx[51] * xx[62] - xx[49] * xx[59] + xx[63] + xx
    [63] + xx[224] * xx[223] + xx[154] * xx[191] + xx[70] * xx[81] - xx[68] *
    xx[78] - xx[82] - xx[82] + xx[208] * xx[236] + xx[165] * xx[180] + xx[89] *
    xx[99] - xx[87] * xx[29] - xx[100] - xx[100] + xx[220] * xx[245] + xx[146] *
    xx[192] + xx[289];
  xx[44] = xx[275] * xx[43] + xx[280] * xx[40];
  xx[63] = xx[276] * xx[40] + xx[279] * xx[43];
  xx[82] = xx[206] * xx[207] - xx[146] * xx[145];
  xx[100] = xx[197] * xx[146] + xx[247] * xx[211];
  xx[207] = xx[278] * xx[62] + xx[286] * xx[59];
  xx[294] = xx[282] * xx[59] + xx[285] * xx[62];
  xx[297] = xx[219] * xx[217] + xx[154] * xx[153];
  xx[219] = xx[185] * xx[154] - xx[223] * xx[42];
  xx[298] = xx[283] * xx[81] + xx[292] * xx[78];
  xx[299] = xx[288] * xx[78] + xx[291] * xx[81];
  xx[300] = xx[229] * xx[233] + xx[165] * xx[164];
  xx[233] = xx[61] * xx[236] - xx[189] * xx[165];
  xx[301] = xx[287] * xx[99] + xx[296] * xx[29];
  xx[302] = xx[290] * xx[29] + xx[295] * xx[99];
  xx[303] = xx[146] * xx[173] - xx[243] * xx[232];
  xx[243] = xx[182] * xx[146] + xx[245] * xx[80];
  xx[304] = xx[40] * xx[44] - xx[63] * xx[43] - xx[82] - xx[100] + xx[210] * xx
    [211] + xx[146] * xx[184] + xx[59] * xx[207] - xx[294] * xx[62] + xx[297] -
    xx[219] + xx[222] * xx[223] + xx[154] * xx[188] + xx[78] * xx[298] - xx[299]
    * xx[81] - xx[300] - xx[233] + xx[203] * xx[236] + xx[165] * xx[181] + xx[29]
    * xx[301] - xx[302] * xx[99] - xx[303] + xx[243] + xx[214] * xx[245] + xx
    [146] * xx[193];
  xx[305] = xx[293] * xx[176] + xx[304] * xx[178] + xx[246] * xx[235];
  xx[306] = xx[297] - (xx[51] * xx[59] + xx[49] * xx[62] + xx[219]) - (xx[154] *
    xx[155] - xx[217] * xx[224]) - (xx[32] * xx[40] + xx[30] * xx[43] + xx[100]
    + xx[82] + xx[146] * xx[147] - xx[206] * xx[212]) - (xx[70] * xx[78] + xx[68]
    * xx[81] + xx[233] + xx[300] + xx[165] * xx[166] - xx[229] * xx[208]) + xx
    [243] - (xx[89] * xx[29] + xx[87] * xx[99]) - xx[303] - (xx[146] * xx[174] -
    xx[232] * xx[220]);
  xx[30] = xx[206] * xx[247] - xx[177] * xx[146];
  xx[32] = xx[217] * xx[42] + xx[144] * xx[154];
  xx[42] = xx[229] * xx[61] + xx[152] * xx[165];
  xx[49] = xx[163] * xx[146] - xx[232] * xx[80];
  xx[51] = 1.348671059813626e-4;
  xx[61] = xx[40] * xx[63] + xx[44] * xx[43] - xx[30] - xx[30] + xx[146] * xx
    [141] + xx[206] * xx[210] + xx[59] * xx[294] + xx[207] * xx[62] + xx[32] +
    xx[32] + xx[154] * xx[149] + xx[217] * xx[222] + xx[78] * xx[299] + xx[298] *
    xx[81] - xx[42] - xx[42] + xx[165] * xx[160] + xx[229] * xx[203] + xx[29] *
    xx[302] + xx[301] * xx[99] - xx[49] - xx[49] + xx[146] * xx[169] + xx[232] *
    xx[214] + xx[51];
  xx[30] = xx[306] * xx[176] + xx[61] * xx[178] + xx[98] * xx[235];
  xx[32] = xx[304] * xx[176] - xx[293] * xx[178];
  xx[42] = xx[61] * xx[176] - xx[306] * xx[178];
  xx[44] = xx[32] * xx[176] + xx[42] * xx[178] + xx[252] * xx[235];
  xx[49] = xx[33] * xx[138];
  xx[61] = xx[49] * xx[79];
  xx[63] = xx[259] * xx[138];
  xx[68] = xx[63] * xx[79];
  xx[70] = xx[206] * xx[186] - xx[145] * xx[211];
  xx[80] = xx[146] * xx[37];
  xx[82] = xx[52] * xx[148];
  xx[87] = xx[82] * xx[97];
  xx[89] = xx[111] * xx[148];
  xx[100] = xx[89] * xx[97];
  xx[145] = xx[223] * xx[153] - xx[217] * xx[190];
  xx[153] = xx[154] * xx[56];
  xx[186] = xx[71] * xx[158];
  xx[190] = xx[186] * xx[112];
  xx[203] = xx[36] * xx[158];
  xx[207] = xx[203] * xx[112];
  xx[208] = xx[229] * xx[183] - xx[164] * xx[236];
  xx[164] = xx[165] * xx[75];
  xx[183] = xx[90] * xx[168];
  xx[210] = xx[183] * xx[114];
  xx[212] = xx[41] * xx[168];
  xx[214] = xx[212] * xx[114];
  xx[219] = xx[245] * xx[173] - xx[232] * xx[195];
  xx[173] = xx[146] * xx[94];
  xx[195] = xx[40] * xx[61] + xx[68] * xx[43] - xx[70] + xx[80] + xx[146] * xx
    [260] + xx[59] * xx[87] + xx[100] * xx[62] - xx[145] + xx[153] + xx[154] *
    xx[119] + xx[78] * xx[190] + xx[207] * xx[81] - xx[208] - xx[164] - xx[165] *
    xx[105] + xx[29] * xx[210] + xx[214] * xx[99] - xx[219] - xx[173] - xx[146] *
    xx[106] - (xx[175] * xx[257] + xx[196] * xx[258]);
  xx[220] = xx[177] * xx[211] + xx[206] * xx[197];
  xx[177] = xx[146] * xx[261];
  xx[197] = xx[144] * xx[223] + xx[185] * xx[217];
  xx[144] = xx[154] * xx[45];
  xx[185] = xx[152] * xx[236] + xx[229] * xx[189];
  xx[152] = xx[165] * xx[64];
  xx[189] = xx[163] * xx[245] + xx[182] * xx[232];
  xx[163] = xx[146] * xx[83];
  xx[182] = xx[172] * xx[257] + xx[194] * xx[258] + xx[40] * xx[68] - xx[61] *
    xx[43] - xx[220] + xx[177] - xx[146] * xx[262] + xx[59] * xx[100] - xx[87] *
    xx[62] + xx[197] + xx[144] + xx[154] * xx[107] + xx[78] * xx[207] - xx[190] *
    xx[81] - xx[185] - xx[152] + xx[165] * xx[110] + xx[29] * xx[214] - xx[210] *
    xx[99] + xx[189] - xx[163] - xx[146] * xx[113];
  xx[61] = xx[195] * xx[176] - xx[178] * xx[182];
  xx[68] = - (xx[195] * xx[178] + xx[176] * xx[182]);
  xx[87] = 8.224885814516596e-6;
  xx[100] = 7.656036730940041e-6;
  xx[190] = xx[87] + xx[100] + xx[259] * xx[201] + xx[33] * xx[205];
  xx[207] = xx[261] * xx[211] + xx[206] * xx[37];
  xx[37] = 7.656036730940044e-6;
  xx[210] = xx[87] + xx[37] + xx[111] * xx[215] + xx[52] * xx[218];
  xx[214] = xx[45] * xx[223] + xx[217] * xx[56];
  xx[45] = xx[87] + xx[100] + xx[36] * xx[227] + xx[71] * xx[231];
  xx[56] = xx[64] * xx[236] + xx[229] * xx[75];
  xx[64] = xx[87] + xx[100] + xx[41] * xx[239] + xx[90] * xx[242];
  xx[75] = xx[83] * xx[245] + xx[232] * xx[94];
  xx[83] = 1.101391944042172e-4;
  xx[94] = xx[190] * xx[79] * xx[79] - xx[207] - xx[207] - (xx[206] * xx[260] -
    xx[262] * xx[211]) + xx[210] * xx[97] * xx[97] + xx[214] + xx[214] + xx[217]
    * xx[119] + xx[223] * xx[107] + xx[45] * xx[112] * xx[112] - xx[56] - xx[56]
    - (xx[229] * xx[105] - xx[110] * xx[236]) + xx[64] * xx[114] * xx[114] + xx
    [75] + xx[75] + xx[232] * xx[106] + xx[245] * xx[113] + xx[83] + xx[55] *
    xx[258] + xx[93] * xx[257];
  xx[306] = pm_math_Vector3_dot_ra(xx + 23, xx + 120);
  xx[307] = xx[132];
  xx[308] = xx[124];
  xx[309] = xx[241];
  xx[310] = xx[256];
  xx[311] = xx[263];
  xx[312] = xx[132];
  xx[313] = pm_math_Vector3_dot_ra(xx + 264, xx + 129);
  xx[314] = xx[267];
  xx[315] = xx[268];
  xx[316] = xx[269];
  xx[317] = xx[270];
  xx[318] = xx[124];
  xx[319] = xx[267];
  xx[320] = pm_math_Vector3_dot_ra(xx + 271, xx + 134);
  xx[321] = xx[274];
  xx[322] = xx[248];
  xx[323] = xx[249];
  xx[324] = xx[241];
  xx[325] = xx[268];
  xx[326] = xx[274];
  xx[327] = xx[305] * xx[176] + xx[30] * xx[178] + xx[238] * xx[235];
  xx[328] = xx[44];
  xx[329] = xx[61];
  xx[330] = xx[256];
  xx[331] = xx[269];
  xx[332] = xx[248];
  xx[333] = xx[44];
  xx[334] = xx[42] * xx[176] - xx[32] * xx[178];
  xx[335] = xx[68];
  xx[336] = xx[263];
  xx[337] = xx[270];
  xx[338] = xx[249];
  xx[339] = xx[61];
  xx[340] = xx[68];
  xx[341] = xx[94] + xx[257] * xx[116] - xx[108] * xx[258];
  ii[0] = factorSymmetricPosDef(xx + 306, 6, xx + 297);
  if (ii[0] != 0) {
    return sm_ssci_recordRunTimeError(
      "physmod:sm:core:compiler:mechanism:mechanism:degenerateMassFoll",
      "'modeloMK4_funcional/6-DOF Joint' has a degenerate mass distribution on its follower side.",
      neDiagMgr);
  }

  xx[44] = xx[3] * state[11];
  xx[56] = xx[3] * state[10];
  xx[61] = state[10] - (xx[2] * xx[44] + xx[3] * xx[56]) * xx[7];
  xx[68] = state[11] + xx[7] * (xx[2] * xx[56] - xx[3] * xx[44]);
  xx[44] = xx[68] * xx[47];
  xx[56] = xx[47] * xx[61];
  xx[75] = xx[61] - xx[7] * (xx[39] * xx[44] + xx[56] * xx[47]);
  xx[105] = xx[68] - (xx[44] * xx[47] - xx[39] * xx[56]) * xx[7];
  xx[44] = state[12] - state[26];
  xx[119] = xx[75];
  xx[120] = xx[105];
  xx[121] = xx[44];
  xx[129] = - xx[201];
  xx[130] = - xx[205];
  xx[131] = xx[138];
  pm_math_Vector3_cross_ra(xx + 119, xx + 129, xx + 134);
  pm_math_Vector3_cross_ra(xx + 119, xx + 134, xx + 247);
  xx[56] = xx[31] * xx[248] + xx[247] * xx[34];
  xx[106] = (xx[247] - xx[7] * xx[56] * xx[34] - xx[199] * inputDdot[3]) * xx[28];
  xx[107] = xx[44] - (xx[31] * xx[31] * xx[44] + xx[34] * xx[44] * xx[34]) * xx
    [7];
  xx[110] = xx[107] + state[28];
  xx[113] = xx[199] * state[28];
  xx[122] = (xx[248] - xx[7] * xx[56] * xx[31] - (xx[107] + xx[110]) * xx[113]) *
    xx[28];
  xx[56] = xx[31] * xx[122] + xx[106] * xx[34];
  xx[107] = xx[106] - xx[7] * xx[56] * xx[34];
  xx[106] = xx[75] * state[26];
  xx[124] = xx[105] * state[26];
  xx[134] = xx[61];
  xx[135] = xx[68];
  xx[136] = state[12];
  xx[260] = xx[206];
  xx[261] = - xx[211];
  xx[262] = xx[146];
  pm_math_Vector3_cross_ra(xx + 134, xx + 260, xx + 267);
  pm_math_Vector3_cross_ra(xx + 134, xx + 267, xx + 297);
  xx[132] = xx[298] * xx[47];
  xx[138] = xx[297] * xx[47];
  xx[199] = xx[297] - xx[7] * (xx[39] * xx[132] + xx[138] * xx[47]) - xx[209] *
    inputDdot[6];
  xx[207] = xx[209] * state[26];
  xx[209] = xx[298] - (xx[132] * xx[47] - xx[39] * xx[138]) * xx[7] - (state[12]
    + xx[44]) * xx[207];
  xx[132] = xx[107] + xx[142] * xx[106] - xx[139] * xx[124] - xx[33] *
    inputDdot[6] + xx[199] * xx[38] - xx[46] * xx[209];
  xx[38] = xx[132] * xx[47];
  xx[46] = xx[122] - xx[7] * xx[56] * xx[31];
  xx[56] = xx[46] + xx[140] * xx[124] - xx[143] * xx[106] + xx[259] * inputDdot
    [6] + xx[35] * xx[209] - xx[199] * xx[48];
  xx[35] = xx[56] * xx[47];
  xx[48] = xx[132] - (xx[38] * xx[47] - xx[39] * xx[35]) * xx[7];
  xx[122] = 0.0;
  xx[342] = xx[1];
  xx[343] = xx[122];
  xx[344] = xx[122];
  xx[345] = xx[1];
  xx[346] = xx[122];
  xx[347] = xx[122];
  xx[348] = - 0.18;
  xx[132] = 2.153196201808899e-10;
  xx[138] = 1.402367424384834e-6;
  xx[214] = xx[138] * xx[10];
  xx[222] = - xx[8];
  xx[267] = xx[19];
  xx[268] = xx[222];
  xx[269] = xx[10];
  xx[224] = xx[132] * xx[10];
  xx[233] = xx[8] * xx[132] - xx[19] * xx[138];
  xx[300] = xx[214];
  xx[301] = xx[224];
  xx[302] = xx[233];
  pm_math_Vector3_cross_ra(xx + 267, xx + 300, xx + 349);
  xx[267] = xx[6];
  xx[268] = - xx[15];
  xx[269] = xx[13];
  xx[241] = xx[257] * xx[13];
  xx[243] = xx[258] * xx[13];
  xx[13] = xx[15] * xx[258] - xx[257] * xx[6];
  xx[300] = xx[241];
  xx[301] = xx[243];
  xx[302] = xx[13];
  pm_math_Vector3_cross_ra(xx + 267, xx + 300, xx + 352);
  xx[6] = state[0] - xx[7] * (xx[352] - xx[241] * xx[4]) - xx[258];
  xx[15] = 0.5000000000000001;
  xx[241] = xx[6] * xx[15];
  xx[256] = state[1] - (xx[353] - xx[243] * xx[4]) * xx[7] + xx[257];
  xx[243] = 1.414213562373095;
  xx[263] = state[2] - (xx[354] - xx[13] * xx[4]) * xx[7];
  xx[4] = xx[243] * (xx[1] * xx[263] + xx[256] * xx[1]);
  xx[352] = - (xx[3] * xx[10] - xx[2] * xx[17]);
  xx[353] = xx[19] * xx[2] - xx[8] * xx[3];
  xx[354] = - (xx[8] * xx[2] + xx[19] * xx[3]);
  xx[355] = xx[2] * xx[10] + xx[3] * xx[17];
  xx[356] = xx[132] + (xx[214] * xx[17] + xx[349]) * xx[7] + xx[6] - (xx[241] +
    xx[241]) * xx[7] + 0.06370113964882761;
  xx[357] = xx[7] * (xx[350] + xx[224] * xx[17]) - xx[138] + xx[256] - xx[4] +
    0.02757152586923429;
  xx[358] = xx[7] * (xx[351] + xx[233] * xx[17]) + xx[263] - xx[4] -
    0.02944846882862407;
  bb[0] = sm_core_compiler_computeProximityInfoPlaneBrick(
    modeloMK4_funcional_4ef989e3_1_geometry_1(NULL),
    modeloMK4_funcional_4ef989e3_1_geometry_0(NULL), (pm_math_Transform3 *)(xx +
    342), (pm_math_Transform3 *)(xx + 352), xx + 4, (pm_math_Vector3 *)(xx + 267),
    (pm_math_Vector3 *)(xx + 300), (pm_math_Vector3 *)(xx + 349),
    (pm_math_Vector3 *)(xx + 359));
  xx[362] = xx[2];
  xx[363] = xx[122];
  xx[364] = xx[122];
  xx[365] = xx[3];
  xx[366] = xx[132];
  xx[367] = - xx[138];
  xx[368] = xx[122];
  xx[369] = xx[17];
  xx[370] = xx[19];
  xx[371] = xx[222];
  xx[372] = xx[10];
  xx[2] = xx[15] * state[7];
  xx[3] = xx[243] * (xx[1] * state[9] + xx[1] * state[8]);
  xx[373] = state[7] - (xx[2] + xx[2]) * xx[7];
  xx[374] = state[8] - xx[3];
  xx[375] = state[9] - xx[3];
  pm_math_Quaternion_inverseXform_ra(xx + 369, xx + 373, xx + 1);
  xx[6] = xx[1] - xx[257] * state[12];
  xx[13] = xx[2] - xx[258] * state[12];
  xx[15] = xx[3] + xx[257] * xx[61] + xx[68] * xx[258];
  xx[369] = xx[61];
  xx[370] = xx[68];
  xx[371] = state[12];
  xx[372] = xx[6];
  xx[373] = xx[13];
  xx[374] = xx[15];
  sm_core_compiler_computeSpatialContactWrenches(
    0, 1, bb[0], xx + 4, (const pm_math_Vector3 *)(xx + 267), (const
    pm_math_Vector3 *)(xx + 300), (const pm_math_Vector3 *)(xx + 349), (const
    pm_math_Vector3 *)(xx + 359),
    (const pm_math_Transform3 *)(xx + 342), (const pm_math_Transform3 *)(xx +
    362), (const pm_math_Transform3 *)(xx + 342), (const pm_math_Transform3 *)
    (xx + 352), NULL, (const pm_math_SpatialVector *)(xx + 369),
    0, 1, 1.0e6, 1000.0, 1.0e-4, 0.3, 0.2119573811760597, 9.126024771145405e-4,
    NULL, NULL,
    NULL, (pm_math_SpatialVector *)(xx + 375));
  xx[4] = xx[68] * xx[66];
  xx[132] = xx[66] * xx[61];
  xx[138] = xx[61] - xx[7] * (xx[58] * xx[4] + xx[132] * xx[66]);
  xx[214] = xx[68] - (xx[4] * xx[66] - xx[58] * xx[132]) * xx[7];
  xx[4] = state[12] - state[22];
  xx[267] = xx[138];
  xx[268] = xx[214];
  xx[269] = xx[4];
  xx[300] = - xx[215];
  xx[301] = - xx[218];
  xx[302] = xx[148];
  pm_math_Vector3_cross_ra(xx + 267, xx + 300, xx + 342);
  pm_math_Vector3_cross_ra(xx + 267, xx + 342, xx + 345);
  xx[132] = xx[50] * xx[346] + xx[345] * xx[53];
  xx[148] = (xx[345] - xx[7] * xx[132] * xx[53] - xx[213] * inputDdot[2]) * xx
    [28];
  xx[222] = xx[4] - (xx[50] * xx[50] * xx[4] + xx[53] * xx[4] * xx[53]) * xx[7];
  xx[224] = xx[222] + state[24];
  xx[233] = xx[213] * state[24];
  xx[213] = (xx[346] - xx[7] * xx[132] * xx[50] - (xx[222] + xx[224]) * xx[233])
    * xx[28];
  xx[132] = xx[50] * xx[213] + xx[148] * xx[53];
  xx[222] = xx[148] - xx[7] * xx[132] * xx[53];
  xx[148] = xx[138] * state[22];
  xx[241] = xx[214] * state[22];
  xx[342] = - xx[217];
  xx[343] = xx[223];
  xx[344] = xx[154];
  pm_math_Vector3_cross_ra(xx + 134, xx + 342, xx + 348);
  pm_math_Vector3_cross_ra(xx + 134, xx + 348, xx + 351);
  xx[154] = xx[352] * xx[66];
  xx[243] = xx[351] * xx[66];
  xx[256] = xx[351] - xx[7] * (xx[58] * xx[154] + xx[243] * xx[66]) - xx[221] *
    inputDdot[4];
  xx[263] = xx[221] * state[22];
  xx[221] = xx[352] - (xx[154] * xx[66] - xx[58] * xx[243]) * xx[7] - (state[12]
    + xx[4]) * xx[263];
  xx[154] = xx[222] + xx[150] * xx[148] - xx[127] * xx[241] - xx[52] *
    inputDdot[4] + xx[256] * xx[57] - xx[65] * xx[221];
  xx[57] = xx[154] * xx[66];
  xx[65] = xx[213] - xx[7] * xx[132] * xx[50];
  xx[132] = xx[65] + xx[137] * xx[241] - xx[151] * xx[148] + xx[111] *
    inputDdot[4] + xx[54] * xx[221] - xx[256] * xx[67];
  xx[54] = xx[132] * xx[66];
  xx[67] = xx[154] - (xx[57] * xx[66] - xx[58] * xx[54]) * xx[7];
  xx[154] = xx[68] * xx[85];
  xx[213] = xx[85] * xx[61];
  xx[243] = xx[61] - xx[7] * (xx[77] * xx[154] + xx[213] * xx[85]);
  xx[270] = xx[68] - (xx[154] * xx[85] - xx[77] * xx[213]) * xx[7];
  xx[154] = state[12] - state[18];
  xx[348] = xx[243];
  xx[349] = xx[270];
  xx[350] = xx[154];
  xx[354] = - xx[227];
  xx[355] = - xx[231];
  xx[356] = xx[158];
  pm_math_Vector3_cross_ra(xx + 348, xx + 354, xx + 357);
  pm_math_Vector3_cross_ra(xx + 348, xx + 357, xx + 360);
  xx[158] = xx[69] * xx[361] + xx[360] * xx[72];
  xx[213] = (xx[360] - xx[7] * xx[158] * xx[72] - xx[225] * inputDdot[1]) * xx
    [28];
  xx[274] = xx[154] - (xx[69] * xx[69] * xx[154] + xx[72] * xx[154] * xx[72]) *
    xx[7];
  xx[293] = xx[274] + state[20];
  xx[294] = xx[225] * state[20];
  xx[225] = (xx[361] - xx[7] * xx[158] * xx[69] - (xx[274] + xx[293]) * xx[294])
    * xx[28];
  xx[158] = xx[69] * xx[225] + xx[213] * xx[72];
  xx[274] = xx[213] - xx[7] * xx[158] * xx[72];
  xx[213] = xx[243] * state[18];
  xx[303] = xx[270] * state[18];
  xx[357] = xx[229];
  xx[358] = - xx[236];
  xx[359] = - xx[165];
  pm_math_Vector3_cross_ra(xx + 134, xx + 357, xx + 363);
  pm_math_Vector3_cross_ra(xx + 134, xx + 363, xx + 366);
  xx[165] = xx[367] * xx[85];
  xx[304] = xx[366] * xx[85];
  xx[363] = xx[366] - xx[7] * (xx[77] * xx[165] + xx[304] * xx[85]) - xx[234] *
    inputDdot[7];
  xx[364] = xx[234] * state[18];
  xx[365] = xx[367] - (xx[165] * xx[85] - xx[77] * xx[304]) * xx[7] - (state[12]
    + xx[154]) * xx[364];
  xx[165] = xx[274] + xx[161] * xx[213] - xx[157] * xx[303] - xx[71] *
    inputDdot[7] + xx[363] * xx[76] - xx[84] * xx[365];
  xx[76] = xx[165] * xx[85];
  xx[84] = xx[225] - xx[7] * xx[158] * xx[69];
  xx[158] = xx[84] + xx[159] * xx[303] - xx[162] * xx[213] + xx[36] * inputDdot
    [7] + xx[73] * xx[365] - xx[363] * xx[86];
  xx[73] = xx[158] * xx[85];
  xx[86] = xx[165] - (xx[76] * xx[85] - xx[77] * xx[73]) * xx[7];
  xx[165] = xx[68] * xx[103];
  xx[225] = xx[103] * xx[61];
  xx[304] = xx[61] - xx[7] * (xx[96] * xx[165] + xx[225] * xx[103]);
  xx[369] = xx[68] - (xx[165] * xx[103] - xx[96] * xx[225]) * xx[7];
  xx[165] = state[12] - state[14];
  xx[370] = xx[304];
  xx[371] = xx[369];
  xx[372] = xx[165];
  xx[381] = - xx[239];
  xx[382] = - xx[242];
  xx[383] = xx[168];
  pm_math_Vector3_cross_ra(xx + 370, xx + 381, xx + 384);
  pm_math_Vector3_cross_ra(xx + 370, xx + 384, xx + 387);
  xx[168] = xx[88] * xx[388] + xx[387] * xx[91];
  xx[225] = (xx[387] - xx[7] * xx[168] * xx[91] - xx[237] * inputDdot[0]) * xx
    [28];
  xx[373] = xx[165] - (xx[88] * xx[88] * xx[165] + xx[91] * xx[165] * xx[91]) *
    xx[7];
  xx[374] = xx[373] + state[16];
  xx[384] = xx[237] * state[16];
  xx[237] = (xx[388] - xx[7] * xx[168] * xx[88] - (xx[373] + xx[374]) * xx[384])
    * xx[28];
  xx[168] = xx[88] * xx[237] + xx[225] * xx[91];
  xx[373] = xx[225] - xx[7] * xx[168] * xx[91];
  xx[225] = xx[304] * state[14];
  xx[385] = xx[369] * state[14];
  xx[390] = - xx[232];
  xx[391] = xx[245];
  xx[392] = - xx[146];
  pm_math_Vector3_cross_ra(xx + 134, xx + 390, xx + 393);
  pm_math_Vector3_cross_ra(xx + 134, xx + 393, xx + 396);
  xx[146] = xx[397] * xx[103];
  xx[386] = xx[396] * xx[103];
  xx[393] = xx[396] - xx[7] * (xx[96] * xx[146] + xx[386] * xx[103]) - xx[234] *
    inputDdot[5];
  xx[394] = xx[234] * state[14];
  xx[234] = xx[397] - (xx[146] * xx[103] - xx[96] * xx[386]) * xx[7] - (state[12]
    + xx[165]) * xx[394];
  xx[146] = xx[373] + xx[170] * xx[225] - xx[156] * xx[385] - xx[90] *
    inputDdot[5] + xx[393] * xx[95] - xx[102] * xx[234];
  xx[95] = xx[146] * xx[103];
  xx[102] = xx[237] - xx[7] * xx[168] * xx[88];
  xx[168] = xx[102] + xx[167] * xx[385] - xx[171] * xx[225] + xx[41] *
    inputDdot[5] + xx[92] * xx[234] - xx[393] * xx[104];
  xx[92] = xx[168] * xx[103];
  xx[104] = xx[146] - (xx[95] * xx[103] - xx[96] * xx[92]) * xx[7];
  xx[399] = xx[6];
  xx[400] = xx[13];
  xx[401] = xx[15];
  pm_math_Vector3_cross_ra(xx + 134, xx + 399, xx + 402);
  xx[399] = - xx[1];
  xx[400] = - xx[2];
  xx[401] = - xx[3];
  pm_math_Vector3_cross_ra(xx + 134, xx + 399, xx + 1);
  xx[6] = xx[402] + xx[1];
  xx[13] = xx[403] + xx[2];
  xx[15] = xx[48] - xx[378] + xx[67] + xx[86] + xx[104] + xx[101] * xx[6] + xx
    [117] * xx[13];
  xx[101] = xx[56] - xx[7] * (xx[39] * xx[38] + xx[35] * xx[47]);
  xx[35] = xx[132] - xx[7] * (xx[58] * xx[57] + xx[54] * xx[66]);
  xx[38] = xx[158] - xx[7] * (xx[77] * xx[76] + xx[73] * xx[85]);
  xx[54] = xx[168] - xx[7] * (xx[96] * xx[95] + xx[92] * xx[103]);
  xx[56] = xx[101] - xx[379] + xx[35] + xx[38] + xx[54] + xx[109] * xx[13] - xx
    [27] * xx[6];
  xx[27] = xx[31] * xx[105] + xx[75] * xx[34];
  xx[57] = xx[105] - xx[7] * xx[27] * xx[31];
  xx[73] = xx[28] * (xx[249] - (xx[31] * xx[31] * xx[249] + xx[249] * xx[34] *
    xx[34]) * xx[7] + (xx[57] + xx[57]) * xx[113]);
  xx[76] = xx[73] - (xx[31] * xx[31] * xx[73] + xx[73] * xx[34] * xx[34]) * xx[7];
  xx[73] = xx[299] + (xx[105] + xx[105]) * xx[207];
  xx[92] = xx[76] + xx[74] * xx[73] + xx[200] * xx[124] + xx[106] * xx[202];
  xx[95] = xx[50] * xx[214] + xx[138] * xx[53];
  xx[109] = xx[214] - xx[7] * xx[95] * xx[50];
  xx[113] = xx[28] * (xx[347] - (xx[50] * xx[50] * xx[347] + xx[347] * xx[53] *
    xx[53]) * xx[7] + (xx[109] + xx[109]) * xx[233]);
  xx[117] = xx[113] - (xx[50] * xx[50] * xx[113] + xx[113] * xx[53] * xx[53]) *
    xx[7];
  xx[113] = xx[353] + (xx[214] + xx[214]) * xx[263];
  xx[132] = xx[117] + xx[74] * xx[113] + xx[204] * xx[241] + xx[148] * xx[216];
  xx[146] = xx[69] * xx[270] + xx[243] * xx[72];
  xx[158] = xx[270] - xx[7] * xx[146] * xx[69];
  xx[168] = xx[28] * (xx[362] - (xx[69] * xx[69] * xx[362] + xx[362] * xx[72] *
    xx[72]) * xx[7] + (xx[158] + xx[158]) * xx[294]);
  xx[207] = xx[168] - (xx[69] * xx[69] * xx[168] + xx[168] * xx[72] * xx[72]) *
    xx[7];
  xx[168] = xx[368] + (xx[270] + xx[270]) * xx[364];
  xx[233] = xx[207] + xx[74] * xx[168] + xx[226] * xx[303] + xx[213] * xx[228];
  xx[237] = xx[88] * xx[369] + xx[304] * xx[91];
  xx[247] = xx[369] - xx[7] * xx[237] * xx[88];
  xx[248] = xx[28] * (xx[389] - (xx[88] * xx[88] * xx[389] + xx[389] * xx[91] *
    xx[91]) * xx[7] + (xx[247] + xx[247]) * xx[384]);
  xx[28] = xx[248] - (xx[88] * xx[88] * xx[248] + xx[248] * xx[91] * xx[91]) *
    xx[7];
  xx[248] = xx[398] + (xx[369] + xx[369]) * xx[394];
  xx[249] = xx[28] + xx[74] * xx[248] + xx[230] * xx[385] + xx[225] * xx[240];
  xx[1] = xx[404] + xx[3];
  xx[2] = xx[92] - xx[380] + xx[132] + xx[233] + xx[249] + xx[115] * xx[1];
  xx[297] = xx[15];
  xx[298] = xx[56];
  xx[299] = xx[2];
  xx[345] = xx[289] * xx[61];
  xx[346] = xx[68] * xx[51];
  xx[347] = xx[83] * state[12];
  pm_math_Vector3_cross_ra(xx + 134, xx + 345, xx + 351);
  xx[134] = xx[75] * xx[250];
  xx[135] = xx[254] * xx[105];
  xx[136] = xx[87] * xx[44];
  pm_math_Vector3_cross_ra(xx + 119, xx + 134, xx + 345);
  xx[3] = xx[75] - xx[7] * xx[27] * xx[34];
  xx[119] = xx[3];
  xx[120] = xx[57];
  xx[121] = xx[110];
  xx[134] = xx[253] * xx[3];
  xx[135] = xx[255] * xx[57];
  xx[136] = xx[110] * xx[100];
  pm_math_Vector3_cross_ra(xx + 119, xx + 134, xx + 360);
  xx[27] = xx[360] + xx[253] * xx[57] * state[28];
  xx[44] = xx[361] - xx[255] * xx[3] * state[28];
  xx[3] = xx[31] * xx[44] + xx[27] * xx[34];
  xx[119] = xx[107];
  xx[120] = xx[46];
  xx[121] = xx[76];
  pm_math_Vector3_cross_ra(xx + 129, xx + 119, xx + 74);
  xx[46] = xx[140] * xx[201] + xx[139] * xx[205];
  xx[51] = xx[143] * xx[201] + xx[142] * xx[205];
  xx[394] = xx[276];
  xx[395] = - xx[279];
  xx[396] = xx[63];
  xx[397] = - xx[280];
  xx[398] = xx[275];
  xx[399] = xx[49];
  xx[400] = xx[46];
  xx[401] = xx[51];
  xx[402] = xx[190];
  xx[119] = - xx[124];
  xx[120] = xx[106];
  xx[121] = - inputDdot[6];
  pm_math_Matrix3x3_xform_ra(xx + 394, xx + 119, xx + 105);
  xx[49] = xx[345] + xx[27] - xx[7] * xx[3] * xx[34] + xx[74] + xx[105] + xx[199]
    * xx[139] - xx[209] * xx[140] - xx[200] * xx[73];
  xx[27] = xx[49] * xx[47];
  xx[57] = xx[346] + xx[44] - xx[7] * xx[3] * xx[31] + xx[75] + xx[106] + xx[199]
    * xx[142] - xx[209] * xx[143] + xx[202] * xx[73];
  xx[3] = xx[57] * xx[47];
  xx[119] = xx[48];
  xx[120] = xx[101];
  xx[121] = xx[92];
  pm_math_Vector3_cross_ra(xx + 260, xx + 119, xx + 129);
  xx[119] = xx[138] * xx[250];
  xx[120] = xx[254] * xx[214];
  xx[121] = xx[87] * xx[4];
  pm_math_Vector3_cross_ra(xx + 267, xx + 119, xx + 134);
  xx[4] = xx[138] - xx[7] * xx[95] * xx[53];
  xx[119] = xx[4];
  xx[120] = xx[109];
  xx[121] = xx[224];
  xx[138] = xx[277] * xx[4];
  xx[139] = xx[255] * xx[109];
  xx[140] = xx[224] * xx[37];
  pm_math_Vector3_cross_ra(xx + 119, xx + 138, xx + 200);
  xx[44] = xx[200] + xx[277] * xx[109] * state[24];
  xx[48] = xx[201] - xx[255] * xx[4] * state[24];
  xx[4] = xx[50] * xx[48] + xx[44] * xx[53];
  xx[119] = xx[222];
  xx[120] = xx[65];
  xx[121] = xx[117];
  pm_math_Vector3_cross_ra(xx + 300, xx + 119, xx + 138);
  xx[61] = xx[137] * xx[215] + xx[127] * xx[218];
  xx[63] = xx[151] * xx[215] + xx[150] * xx[218];
  xx[394] = xx[282];
  xx[395] = - xx[285];
  xx[396] = xx[89];
  xx[397] = - xx[286];
  xx[398] = xx[278];
  xx[399] = xx[82];
  xx[400] = xx[61];
  xx[401] = xx[63];
  xx[402] = xx[210];
  xx[119] = - xx[241];
  xx[120] = xx[148];
  xx[121] = - inputDdot[4];
  pm_math_Matrix3x3_xform_ra(xx + 394, xx + 119, xx + 260);
  xx[65] = xx[134] + xx[44] - xx[7] * xx[4] * xx[53] + xx[138] + xx[260] + xx
    [256] * xx[127] - xx[221] * xx[137] - xx[204] * xx[113];
  xx[44] = xx[65] * xx[66];
  xx[68] = xx[135] + xx[48] - xx[7] * xx[4] * xx[50] + xx[139] + xx[261] + xx
    [256] * xx[150] - xx[221] * xx[151] + xx[216] * xx[113];
  xx[4] = xx[68] * xx[66];
  xx[119] = xx[67];
  xx[120] = xx[35];
  xx[121] = xx[132];
  pm_math_Vector3_cross_ra(xx + 342, xx + 119, xx + 214);
  xx[119] = xx[243] * xx[250];
  xx[120] = xx[254] * xx[270];
  xx[121] = xx[87] * xx[154];
  pm_math_Vector3_cross_ra(xx + 348, xx + 119, xx + 267);
  xx[35] = xx[243] - xx[7] * xx[146] * xx[72];
  xx[119] = xx[35];
  xx[120] = xx[158];
  xx[121] = xx[293];
  xx[275] = xx[281] * xx[35];
  xx[276] = xx[284] * xx[158];
  xx[277] = xx[293] * xx[100];
  pm_math_Vector3_cross_ra(xx + 119, xx + 275, xx + 278);
  xx[48] = xx[278] + xx[281] * xx[158] * state[20];
  xx[67] = xx[279] - xx[284] * xx[35] * state[20];
  xx[35] = xx[69] * xx[67] + xx[48] * xx[72];
  xx[119] = xx[274];
  xx[120] = xx[84];
  xx[121] = xx[207];
  pm_math_Vector3_cross_ra(xx + 354, xx + 119, xx + 82);
  xx[73] = xx[159] * xx[227] + xx[157] * xx[231];
  xx[89] = xx[162] * xx[227] + xx[161] * xx[231];
  xx[394] = xx[288];
  xx[395] = - xx[291];
  xx[396] = xx[203];
  xx[397] = - xx[292];
  xx[398] = xx[283];
  xx[399] = xx[186];
  xx[400] = xx[73];
  xx[401] = xx[89];
  xx[402] = xx[45];
  xx[119] = - xx[303];
  xx[120] = xx[213];
  xx[121] = - inputDdot[7];
  pm_math_Matrix3x3_xform_ra(xx + 394, xx + 119, xx + 203);
  xx[45] = xx[267] + xx[48] - xx[7] * xx[35] * xx[72] + xx[82] + xx[203] + xx
    [363] * xx[157] - xx[365] * xx[159] - xx[226] * xx[168];
  xx[48] = xx[45] * xx[85];
  xx[92] = xx[268] + xx[67] - xx[7] * xx[35] * xx[69] + xx[83] + xx[204] + xx
    [363] * xx[161] - xx[365] * xx[162] + xx[228] * xx[168];
  xx[35] = xx[92] * xx[85];
  xx[119] = xx[86];
  xx[120] = xx[38];
  xx[121] = xx[233];
  pm_math_Vector3_cross_ra(xx + 357, xx + 119, xx + 157);
  xx[119] = xx[304] * xx[250];
  xx[120] = xx[254] * xx[369];
  xx[121] = xx[87] * xx[165];
  pm_math_Vector3_cross_ra(xx + 370, xx + 119, xx + 226);
  xx[38] = xx[304] - xx[7] * xx[237] * xx[91];
  xx[119] = xx[38];
  xx[120] = xx[247];
  xx[121] = xx[374];
  xx[253] = xx[281] * xx[38];
  xx[254] = xx[284] * xx[247];
  xx[255] = xx[374] * xx[100];
  pm_math_Vector3_cross_ra(xx + 119, xx + 253, xx + 274);
  xx[67] = xx[274] + xx[281] * xx[247] * state[16];
  xx[86] = xx[275] - xx[284] * xx[38] * state[16];
  xx[38] = xx[88] * xx[86] + xx[67] * xx[91];
  xx[119] = xx[373];
  xx[120] = xx[102];
  xx[121] = xx[28];
  pm_math_Vector3_cross_ra(xx + 381, xx + 119, xx + 253);
  xx[28] = xx[167] * xx[239] + xx[156] * xx[242];
  xx[87] = xx[171] * xx[239] + xx[170] * xx[242];
  xx[366] = xx[290];
  xx[367] = - xx[295];
  xx[368] = xx[212];
  xx[369] = - xx[296];
  xx[370] = xx[287];
  xx[371] = xx[183];
  xx[372] = xx[28];
  xx[373] = xx[87];
  xx[374] = xx[64];
  xx[119] = - xx[385];
  xx[120] = xx[225];
  xx[121] = - inputDdot[5];
  pm_math_Matrix3x3_xform_ra(xx + 366, xx + 119, xx + 241);
  xx[64] = xx[226] + xx[67] - xx[7] * xx[38] * xx[91] + xx[253] + xx[241] + xx
    [393] * xx[156] - xx[234] * xx[167] - xx[230] * xx[248];
  xx[67] = xx[64] * xx[103];
  xx[95] = xx[227] + xx[86] - xx[7] * xx[38] * xx[88] + xx[254] + xx[242] + xx
    [393] * xx[170] - xx[234] * xx[171] + xx[240] * xx[248];
  xx[38] = xx[95] * xx[103];
  xx[119] = xx[104];
  xx[120] = xx[54];
  xx[121] = xx[249];
  pm_math_Vector3_cross_ra(xx + 390, xx + 119, xx + 247);
  xx[54] = xx[351] - xx[375] + xx[49] - (xx[27] * xx[47] - xx[39] * xx[3]) * xx
    [7] + xx[129] + xx[65] - (xx[44] * xx[66] - xx[58] * xx[4]) * xx[7] + xx[214]
    + xx[45] - (xx[48] * xx[85] - xx[77] * xx[35]) * xx[7] + xx[157] + xx[64] -
    (xx[67] * xx[103] - xx[96] * xx[38]) * xx[7] + xx[247] + xx[175] * xx[6] +
    xx[196] * xx[13] + xx[246] * xx[1];
  xx[45] = xx[352] - xx[376] + xx[57] - xx[7] * (xx[39] * xx[27] + xx[3] * xx[47])
    + xx[130] + xx[68] - xx[7] * (xx[58] * xx[44] + xx[4] * xx[66]) + xx[215] +
    xx[92] - xx[7] * (xx[77] * xx[48] + xx[35] * xx[85]) + xx[158] + xx[95] -
    xx[7] * (xx[96] * xx[67] + xx[38] * xx[103]) + xx[248] + xx[172] * xx[6] +
    xx[194] * xx[13] + xx[98] * xx[1];
  xx[1] = xx[362] + xx[100] * inputDdot[3];
  xx[3] = xx[202] + xx[37] * inputDdot[2];
  xx[4] = xx[280] + xx[100] * inputDdot[1];
  xx[27] = xx[276] + xx[100] * inputDdot[0];
  xx[100] = - pm_math_Vector3_dot_ra(xx + 23, xx + 297);
  xx[101] = - pm_math_Vector3_dot_ra(xx + 264, xx + 297);
  xx[102] = - pm_math_Vector3_dot_ra(xx + 271, xx + 297);
  xx[103] = - (xx[54] * xx[176] + xx[45] * xx[178] + xx[2] * xx[235]);
  xx[104] = - (xx[45] * xx[176] - xx[54] * xx[178]);
  xx[105] = - (xx[353] - xx[377] + xx[347] + xx[1] - (xx[31] * xx[1] * xx[31] +
    xx[1] * xx[34] * xx[34]) * xx[7] + xx[76] + xx[107] + xx[199] * xx[33] - xx
               [259] * xx[209] + xx[131] + xx[136] + xx[3] - (xx[50] * xx[3] *
    xx[50] + xx[3] * xx[53] * xx[53]) * xx[7] + xx[140] + xx[262] + xx[256] *
               xx[52] - xx[111] * xx[221] + xx[216] + xx[269] + xx[4] - (xx[69] *
    xx[4] * xx[69] + xx[4] * xx[72] * xx[72]) * xx[7] + xx[84] + xx[205] + xx
               [363] * xx[71] - xx[36] * xx[365] + xx[159] + xx[228] + xx[27] -
               (xx[88] * xx[27] * xx[88] + xx[27] * xx[91] * xx[91]) * xx[7] +
               xx[255] + xx[243] + xx[393] * xx[90] - xx[41] * xx[234] + xx[249]
               - (xx[55] * xx[13] + xx[93] * xx[6]) - (xx[15] * xx[257] + xx[56]
    * xx[258]));
  solveSymmetricPosDef(xx + 306, xx + 100, 6, 1, xx + 33, xx + 64);
  xx[1] = xx[79] * (xx[51] * xx[40] + xx[46] * xx[43]) + xx[80] - xx[70] - (xx
    [206] * xx[187] + xx[147] * xx[211]) + xx[97] * (xx[63] * xx[59] + xx[61] *
    xx[62]) + xx[153] - xx[145] + xx[217] * xx[191] + xx[155] * xx[223] + xx[112]
    * (xx[89] * xx[78] + xx[73] * xx[81]) - xx[164] - xx[208] + xx[229] * xx[180]
    + xx[166] * xx[236] + xx[114] * (xx[87] * xx[29] + xx[28] * xx[99]) - xx[173]
    - xx[219] - (xx[232] * xx[192] + xx[174] * xx[245]);
  xx[2] = (xx[46] * xx[40] - xx[51] * xx[43]) * xx[79] + xx[177] - xx[220] + xx
    [206] * xx[184] - xx[141] * xx[211] + (xx[61] * xx[59] - xx[63] * xx[62]) *
    xx[97] + xx[144] + xx[197] + xx[149] * xx[223] - xx[217] * xx[188] + (xx[73]
    * xx[78] - xx[89] * xx[81]) * xx[112] - xx[152] - xx[185] + xx[160] * xx[236]
    - xx[229] * xx[181] + (xx[28] * xx[29] - xx[87] * xx[99]) * xx[114] - xx[163]
    + xx[189] + xx[232] * xx[193] - xx[169] * xx[245];
  xx[134] = xx[175] * xx[12] + xx[196] * xx[16] + xx[246] * xx[22];
  xx[135] = xx[196] * xx[125] - xx[175] * xx[126] + xx[246] * xx[128];
  xx[136] = xx[175] * xx[133] + xx[196] * xx[14] + xx[246] * xx[18];
  xx[137] = xx[305];
  xx[138] = xx[32];
  xx[139] = xx[195];
  xx[140] = xx[172] * xx[12] + xx[194] * xx[16] + xx[98] * xx[22];
  xx[141] = xx[194] * xx[125] - xx[172] * xx[126] + xx[98] * xx[128];
  xx[142] = xx[172] * xx[133] + xx[194] * xx[14] + xx[98] * xx[18];
  xx[143] = xx[30];
  xx[144] = xx[42];
  xx[145] = - xx[182];
  xx[146] = - (xx[93] * xx[12] + xx[55] * xx[16]);
  xx[147] = xx[93] * xx[126] - xx[55] * xx[125];
  xx[148] = - (xx[55] * xx[14] + xx[93] * xx[133]);
  xx[149] = xx[1] * xx[176] - xx[2] * xx[178];
  xx[150] = - (xx[1] * xx[178] + xx[2] * xx[176]);
  xx[151] = xx[94];
  xx[152] = xx[118];
  xx[153] = xx[20];
  xx[154] = xx[5];
  xx[155] = xx[179];
  xx[156] = xx[244];
  xx[157] = - xx[116];
  xx[158] = xx[60];
  xx[159] = xx[21];
  xx[160] = xx[11];
  xx[161] = xx[198];
  xx[162] = xx[251];
  xx[163] = xx[108];
  xx[164] = xx[26];
  xx[165] = xx[9];
  xx[166] = xx[123];
  xx[167] = xx[238];
  xx[168] = xx[252];
  xx[169] = xx[122];
  solveSymmetricPosDef(xx + 306, xx + 134, 6, 6, xx + 39, xx + 1);
  xx[1] = xx[57];
  xx[2] = xx[63];
  xx[3] = xx[69];
  xx[4] = 9.806649999999999;
  xx[5] = xx[8] * xx[4];
  xx[6] = xx[19] * xx[4];
  xx[11] = (xx[5] * xx[17] + xx[6] * xx[10]) * xx[7];
  xx[12] = xx[7] * (xx[6] * xx[17] - xx[5] * xx[10]);
  xx[13] = xx[4] - (xx[19] * xx[6] + xx[8] * xx[5]) * xx[7];
  xx[4] = xx[58];
  xx[5] = xx[64];
  xx[6] = xx[70];
  xx[7] = xx[59];
  xx[8] = xx[65];
  xx[9] = xx[71];
  xx[14] = xx[60];
  xx[15] = xx[66];
  xx[16] = xx[72];
  xx[17] = xx[61];
  xx[18] = xx[67];
  xx[19] = xx[73];
  xx[20] = xx[62];
  xx[21] = xx[68];
  xx[22] = xx[74];
  logVector[0] = state[0];
  logVector[1] = state[1];
  logVector[2] = state[2];
  logVector[3] = state[3];
  logVector[4] = state[4];
  logVector[5] = state[5];
  logVector[6] = state[6];
  logVector[7] = state[7];
  logVector[8] = state[8];
  logVector[9] = state[9];
  logVector[10] = xx[0] * state[10];
  logVector[11] = xx[0] * state[11];
  logVector[12] = xx[0] * state[12];
  logVector[13] = xx[0] * state[13];
  logVector[14] = xx[0] * state[14];
  logVector[15] = xx[0] * state[15];
  logVector[16] = xx[0] * state[16];
  logVector[17] = xx[0] * state[17];
  logVector[18] = xx[0] * state[18];
  logVector[19] = xx[0] * state[19];
  logVector[20] = xx[0] * state[20];
  logVector[21] = xx[0] * state[21];
  logVector[22] = xx[0] * state[22];
  logVector[23] = xx[0] * state[23];
  logVector[24] = xx[0] * state[24];
  logVector[25] = xx[0] * state[25];
  logVector[26] = xx[0] * state[26];
  logVector[27] = xx[0] * state[27];
  logVector[28] = xx[0] * state[28];
  logVector[29] = xx[33] - pm_math_Vector3_dot_ra(xx + 1, xx + 11);
  logVector[30] = xx[34] - pm_math_Vector3_dot_ra(xx + 4, xx + 11);
  logVector[31] = xx[35] - pm_math_Vector3_dot_ra(xx + 7, xx + 11);
  logVector[32] = xx[0] * (xx[36] - pm_math_Vector3_dot_ra(xx + 14, xx + 11));
  logVector[33] = xx[0] * (xx[37] - pm_math_Vector3_dot_ra(xx + 17, xx + 11));
  logVector[34] = xx[0] * (xx[38] - pm_math_Vector3_dot_ra(xx + 20, xx + 11));
  logVector[35] = xx[0] * inputDdot[5];
  logVector[36] = xx[0] * inputDdot[0];
  logVector[37] = xx[0] * inputDdot[7];
  logVector[38] = xx[0] * inputDdot[1];
  logVector[39] = xx[0] * inputDdot[4];
  logVector[40] = xx[0] * inputDdot[2];
  logVector[41] = xx[0] * inputDdot[6];
  logVector[42] = xx[0] * inputDdot[3];
  errorResult[0] = xx[122];
  return NULL;
}
